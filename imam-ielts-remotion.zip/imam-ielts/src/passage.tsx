import React, { useLayoutEffect, useRef, useState } from "react";
import { continueRender, delayRender, interpolate, spring, useVideoConfig } from "remotion";
import { COLORS, SPR } from "./theme";
import { Hl, HlKind, useG, useS } from "./ui";

export type ParaId = "A" | "B" | "C" | "D" | "E" | "F" | "G";
export type Seg = { t: string; id?: string };
export type FocusEv = { at: number; para: ParaId };
export type Mark = { ids: string[]; at: number; until?: number; kind: HlKind };
export const LETTERS: ParaId[] = ["A", "B", "C", "D", "E", "F", "G"];

// A, B, C = ইউজারের স্ক্রিনশট থেকে হুবহু (C-র শেষ অংশ স্ক্রিনশটে কাটা)।
// D, E, G = শুধু SRT-তে পড়া/উদ্ধৃত বাক্য ("…" দিয়ে)। F = SRT-র সারাংশ। কিছু বানানো নয়।
export const PARAS: { id: ParaId; segs: Seg[]; note?: boolean }[] = [
  { id: "A", segs: [
    { t: "Mapungubwe, which was one of the first states in southern Africa, was formed by Bantu-speaking peoples who were farmers. The area controlled by the rulers of Mapungubwe had at its heart a large sandstone plateau, which was easily defended due to its inaccessibility. As with other kingdoms in the region of southern Africa, " },
    { t: "cattle herding and other types of ", id: "a1" },
    { t: "farming brought plenty of food", id: "a2" },
    { t: " and ", id: "a2b" },
    { t: "a surplus that ", id: "a3" },
    { t: "could be traded", id: "a4" },
    { t: " for ", id: "a5" },
    { t: "needed goods", id: "a6" },
    { t: ". Archaeology has revealed extensive layers of bones and manure, which indicate that from the 9th century CE there were large cattle herds, the traditional source of political power in southern African communities. The archaeological record for the 10th century shows a marked increase in the number of domesticated cattle in the area as well as cotton cultivation and weaving, as indicated by abundant finds of spindle whorls." },
  ] },
  { id: "B", segs: [
    { t: "The ", id: "b0" }, { t: "total population", id: "b1" }, { t: " of Mapungubwe ", id: "b0" }, { t: "at its peak", id: "b2" },
    { t: " in the mid-13th century was ", id: "b0" }, { t: "around", id: "b3" }, { t: " 5,000 people", id: "b4" },
    { t: ". The chief or king of Mapungubwe was likely the wealthiest individual in the society, and would have owned more cattle and precious materials than anyone else. " },
    { t: "The king and his advisers dwelt in a stone enclosure", id: "b5" },
    { t: " composed of stone walls and housing built on the highest level of the community's territory, a natural sandstone hill which is some 30 metres high and 100 metres in length. Occupation on the hill dates from the 11th century and the entire complex was surrounded by a wooden palisade*, as indicated by postholes made in the rock. The rest of the community lived in mud and thatch housing spread out below the hill, although there is one stone structure here. This settlement, known as Babandyanalo, covers around 5 hectares (12.3 acres) and predates the hilltop structures." },
  ] },
  { id: "C", segs: [
    { t: "The kings of Mapungubwe were buried at the top of the hill site in a demarcated area away from the dwellings, while other members of the community were buried at the surrounding valley level. A wooden staircase connected the two levels, the sockets for the steps being clearly visible in the sandstone cliff face. There were some " },
    { t: "grander residences", id: "c1" }, { t: " dotted around the ", id: "c2" }, { t: "outskirts of Babandyanalo", id: "c3" }, { t: ", and ", id: "c2b" },
    { t: "these probably belonged", id: "c4" }, { t: " to ", id: "c5" }, { t: "male relatives of the king", id: "c6" },
    { t: ". There are many other smaller but still impressive sites across the Mapungubwe plateau, which are located anywhere …" },
  ] },
  { id: "D", segs: [{ t: "… " }, { t: "Merchants", id: "d1" }, { t: " travelling from India ", id: "d2" }, { t: "by sea", id: "d3" }, { t: ". …", id: "d4" }] },
  { id: "E", segs: [{ t: "… " }, { t: "Their ", id: "e0" }, { t: "precise function", id: "e1" }, { t: " is not known", id: "e2" }, { t: ".", id: "e3" }, { t: " …" }] },
  { id: "F", note: true, segs: [{ t: "Gold (সোনা) ও বিভিন্ন মূল্যবান সামগ্রী — প্রত্নতাত্ত্বিক নিদর্শনের Information" }] },
  { id: "G", segs: [
    { t: "… " }, { t: "The kingdom of Mapungubwe was already in decline by the late 13th century.", id: "g1" }, { t: " … " },
    { t: "Overpopulation placed too much stress on local resources.", id: "g2" }, { t: " " },
    { t: "A situation that may have been ", id: "g3" }, { t: "brought to a crisis point", id: "g4" }, { t: " by ", id: "g3" },
    { t: "a series of droughts", id: "g5" }, { t: ".", id: "g3" }, { t: " …" },
  ] },
];

export const PassagePane: React.FC<{ focus: FocusEv[]; marks: Mark[]; width: number; height: number }> = ({ focus, marks, width, height }) => {
  const { S } = useS();
  const g = useG();
  const { fps } = useVideoConfig();
  const refs = useRef<Record<string, HTMLDivElement | null>>({});
  const [off, setOff] = useState<Record<string, number>>({});
  const [handle] = useState(() => delayRender("passage layout"));
  useLayoutEffect(() => {
    const o: Record<string, number> = {};
    for (const p of PARAS) o[p.id] = refs.current[p.id]?.offsetTop ?? 0;
    setOff(o);
    continueRender(handle);
  }, [handle]);

  let idx = -1;
  focus.forEach((e, i) => { if (e.at <= g) idx = i; });
  const cur = focus[Math.max(idx, 0)] ?? { at: 0, para: "A" as ParaId };
  const prev = focus[Math.max(idx - 1, 0)] ?? cur;
  const p = idx > 0 ? spring({ frame: Math.max(0, g - cur.at), fps, config: SPR.soft }) : 1;
  const y = (off[prev.para] ?? 0) * (1 - p) + (off[cur.para] ?? 0) * p - 18;

  const markOf = (id: string | undefined): { at: number; kind: HlKind } | null => {
    if (!id) return null;
    let best: { at: number; kind: HlKind } | null = null;
    for (const m of marks) {
      if (!m.ids.includes(id) || m.at > g + 30) continue;
      if (m.until != null && g >= m.until) continue;
      if (!best || m.at >= best.at) best = { at: m.at, kind: m.kind };
    }
    return best;
  };

  return (
    <div style={{ width, height, background: S.card, color: S.cardFg, borderRadius: 28, overflow: "hidden", display: "flex", flexDirection: "column", boxSizing: "border-box" }}>
      <div style={{ height: 84, flex: "none", display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 30px", borderBottom: `3px solid ${COLORS.dark}` }}>
        <div>
          <div style={{ fontSize: 36, fontWeight: 700, lineHeight: 1.1 }}>Mapungubwe</div>
          <div style={{ fontSize: 22, fontWeight: 600, lineHeight: 1.2, whiteSpace: "nowrap" }}>Cambridge IELTS 21 · Test 2 · Passage 2</div>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          {LETTERS.map((L) => (
            <div key={L} style={{ width: 46, height: 46, borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 28, fontWeight: 700, background: L === cur.para ? COLORS.red : "transparent", color: L === cur.para ? COLORS.white : COLORS.dark, border: `3px solid ${L === cur.para ? COLORS.red : COLORS.dark}` }}>{L}</div>
          ))}
        </div>
      </div>
      <div style={{ position: "relative", flex: 1, overflow: "hidden" }}>
        <div id="pcol" style={{ position: "relative", padding: `20px 34px ${height}px`, transform: `translateY(${-y}px)` }}>
          {PARAS.map((P) => {
            const focused = P.id === cur.para;
            return (
              <div key={P.id} id={`para-${P.id}`} ref={(el) => { refs.current[P.id] = el; }} style={{ display: "flex", gap: 20, marginBottom: 36, opacity: focused ? 1 : 0.3 }}>
                <div style={{ flex: "none", width: 44, fontSize: 40, fontWeight: 700, lineHeight: 1.4, color: COLORS.red }}>{P.id}</div>
                <div style={{ fontSize: 31, lineHeight: 1.55, fontWeight: 400, fontStyle: P.note ? "italic" : "normal" }}>
                  {P.segs.map((s, i) => {
                    const m = markOf(s.id);
                    return m ? <Hl key={i} at={m.at} kind={m.kind}>{s.t}</Hl> : <span key={i}>{s.t}</span>;
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
