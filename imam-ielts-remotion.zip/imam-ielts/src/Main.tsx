import React from "react";
import { AbsoluteFill, Sequence } from "remotion";
import "./fonts";
import { cueFrame, TOTAL } from "./lib/cues";
import { Analyze, Example, DefineMI, Hook, Keywords, Mapping, MIvsMH, Promise2, Source, StepRead } from "./scenes1";
import { Advice, Answers, ContextScene, Mistakes, OrderScene, Outro, Overview, PairsScene, Recap, ReuseScene, Scanning, Steps5, Steps8, TimeScene, Trap } from "./scenes2";
import { W_END_CUE, W_START_CUE, WALK_START_CUE, WalkScene, Workspace } from "./workspace";
import { COLORS, BgName } from "./theme";
import { FontGate, PreviewAudio, SceneCtx, Shell } from "./ui";

type Plan = { cue: number; bg: BgName; tag: string; node: React.ReactNode };
// bg ক্রম: পরপর একই রঙ আসে না (নিচের assert দেখুন)
export const PLAN: Plan[] = [
  { cue: 1, bg: "dark", tag: "IELTS Reading", node: <Hook /> },
  { cue: 5, bg: "cream", tag: "আজকের ক্লাস", node: <Promise2 /> },
  { cue: 13, bg: "red", tag: "Practice Material", node: <Source /> },
  { cue: 19, bg: "dark", tag: "Question Number", node: <Mapping /> },
  { cue: 28, bg: "cream", tag: "Basics", node: <DefineMI /> },
  { cue: 41, bg: "red", tag: "Basics", node: <MIvsMH /> },
  { cue: 46, bg: "dark", tag: "Basics", node: <Example /> },
  { cue: 65, bg: "cream", tag: "Strategy · Step 1", node: <StepRead /> },
  { cue: 69, bg: "red", tag: "Question Analysis", node: <Analyze /> },
  { cue: 86, bg: "dark", tag: "Keywords", node: <Keywords /> },
  { cue: 105, bg: "cream", tag: "Paraphrasing", node: <PairsScene /> },
  { cue: 128, bg: "red", tag: "Scanning", node: <Scanning /> },
  { cue: 138, bg: "dark", tag: "Context", node: <ContextScene /> },
  { cue: 148, bg: "cream", tag: "Common Mistake", node: <Trap /> },
  { cue: 160, bg: "red", tag: "মনে রাখবে", node: <OrderScene /> },
  { cue: 167, bg: "dark", tag: "মনে রাখবে", node: <ReuseScene /> },
  { cue: 175, bg: "cream", tag: "Practice", node: <Overview /> },
  { cue: WALK_START_CUE, bg: "dark", tag: "Practice · Paragraph A–G", node: <WalkScene /> },
  { cue: 263, bg: "cream", tag: "Method", node: <Steps5 /> },
  { cue: W_START_CUE, bg: "dark", tag: "Questions 14–19", node: <Workspace /> },
  { cue: W_END_CUE, bg: "red", tag: "Answers", node: <Answers /> },
  { cue: 544, bg: "dark", tag: "Strategy Recap", node: <Steps8 /> },
  { cue: 565, bg: "cream", tag: "Mistakes", node: <Mistakes /> },
  { cue: 590, bg: "red", tag: "Time Management", node: <TimeScene /> },
  { cue: 606, bg: "dark", tag: "Recap", node: <Recap /> },
  { cue: 616, bg: "cream", tag: "Advice", node: <Advice /> },
  { cue: 625, bg: "red", tag: "IMAM IELTS", node: <Outro /> },
];
PLAN.forEach((p, i) => { if (i && PLAN[i - 1].bg === p.bg) throw new Error(`পরপর একই ব্যাকগ্রাউন্ড: scene ${i}`); });

const LEAD_IN = 6, TAIL = 8;
export const Main: React.FC = () => (
  <FontGate>
    <AbsoluteFill style={{ background: COLORS.dark }}>
      <PreviewAudio />
      {PLAN.map((s, i) => {
        const start = i === 0 ? 0 : cueFrame(s.cue);
        const from = i === 0 ? 0 : start - LEAD_IN;
        const end = i === PLAN.length - 1 ? TOTAL : cueFrame(PLAN[i + 1].cue) + TAIL;
        return (
          <Sequence key={i} from={from} durationInFrames={end - from}>
            <SceneCtx.Provider value={{ from, bg: s.bg }}>
              <Shell tag={s.tag} first={i === 0}>{s.node}</Shell>
            </SceneCtx.Provider>
          </Sequence>
        );
      })}
    </AbsoluteFill>
  </FontGate>
);
