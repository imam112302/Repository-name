import React from "react";
import { Sequence, interpolate, useCurrentFrame } from "remotion";
import { Finder, cueFrame } from "./lib/cues";
import { FocusEv, LETTERS, Mark, ParaId, PassagePane } from "./passage";
import { COLORS, EASE, SPR } from "./theme";
import { Check, Chip, Hl, Rise, SceneCtx, Sfx, clamp, useG, useS } from "./ui";
import { useContext } from "react";

// ═══════════════ প্রশ্ন সমাধানের ডেটা (সব টাইমিং SRT থেকে খুঁজে নেওয়া) ═══════════════
type QSeg = { t: string; k?: number };
type Row = { kw: string; seg: number; at: number; bn?: { t: string; at: number }; syns: { t: string; at: number }[]; match?: { t: string; at: number } };
export type RQ = {
  n: number; book: number; start: number; end: number; bookAt: number; qSegs: QSeg[]; textAt: number;
  meaning: { t: string; at: number }; rows: Row[]; notes: { t: string; at: number }[]; answer: { letter: ParaId; at: number };
};
type Shared = { focus: FocusEv[]; marks: Mark[] };

export const W_START_CUE = 270;
export const W_END_CUE = 528; // এই cue থেকে "উত্তর সারসংক্ষেপ" সিন

function build(): { qs: RQ[]; shared: Shared } {
  const f = new Finder(W_START_CUE);
  const focus: FocusEv[] = [{ at: cueFrame(W_START_CUE), para: "A" }];
  const marks: Mark[] = [];
  const qs: RQ[] = [];
  const M = (ids: string[], at: number, kind: Mark["kind"]) => marks.push({ ids, at, kind });

  // ── Q1 ──
  {
    const start = f.at("Question Number 1"), bookAt = f.at("Question 14"), textAt = f.at("A mention of the uncertainty");
    const meaning = { t: "কিছু নির্দিষ্ট বস্তুর উদ্দেশ্য বা ব্যবহার সম্পর্কে অনিশ্চয়তার কথা কোথায়?", at: f.at("কিছু নির্দিষ্ট বস্তুর উদ্দেশ্য") };
    const k = [f.at("Uncertainty."), f.at("Purpose."), f.at("Certain Objects.")];
    const s1 = [f.at("Not Known."), f.at("Unknown."), f.at("Unclear.")];
    const s2 = [f.at("Function."), f.at("Use.")];
    focus.push({ at: f.at("Paragraph E-তে আমরা"), para: "E" });
    M(["e0", "e1", "e2", "e3"], f.at("Their precise function is not known."), "ev");
    const m = [f.at("Question-এর Uncertainty বোঝানো হয়েছে"), f.at("Question-এর Purpose বোঝানো হয়েছে"), f.at("Certain Objects-এর সঙ্গে Passage-এর Figures")];
    M(["e2"], m[0], "strong"); M(["e1"], m[1], "strong");
    const ans = f.at("Paragraph E.");
    qs.push({ n: 1, book: 14, start, end: 0, bookAt, textAt, meaning,
      qSegs: [{ t: "A mention of the " }, { t: "uncertainty", k: 0 }, { t: " regarding the " }, { t: "purpose", k: 1 }, { t: " of " }, { t: "certain objects", k: 2 }, { t: "." }],
      rows: [
        { kw: "Uncertainty", seg: 0, at: k[0], syns: [{ t: "Not known", at: s1[0] }, { t: "Unknown", at: s1[1] }, { t: "Unclear", at: s1[2] }], match: { t: "not known", at: m[0] } },
        { kw: "Purpose", seg: 1, at: k[1], syns: [{ t: "Function", at: s2[0] }, { t: "Use", at: s2[1] }], match: { t: "function", at: m[1] } },
        { kw: "Certain Objects", seg: 2, at: k[2], syns: [], match: { t: "Figures", at: m[2] } },
      ],
      notes: [], answer: { letter: "E", at: ans } });
  }
  // ── Q2 ──
  {
    const start = f.at("এবার Question Number 2"), bookAt = f.at("Question 15"), textAt = f.at("The likelihood that a climatic factor");
    const meaning = { t: "কোনো জলবায়ুগত বিষয় সমস্যাকে আরও বাড়িয়েছিল কি না — তার সম্ভাবনা কোথায় বলা হয়েছে?", at: f.at("Mapungubwe যে সমস্যার মুখোমুখি") };
    const k = [f.at("Likelihood."), f.at("Climatic Factor."), f.at("Increased the Problems."), f.at("Mapungubwe Faced.")];
    const bn = [f.at("Likelihood অর্থ সম্ভাবনা"), f.at("Climatic Factor অর্থ জলবায়ুগত"), f.at("Increased the Problems অর্থ")];
    const s = [f.at("Drought."), f.at("Rainfall."), f.at("Extreme Weather.")];
    focus.push({ at: f.at("Paragraph G-তে আমরা"), para: "G" });
    M(["g5"], f.at("A series of droughts."), "ev");
    M(["g2"], f.at("Overpopulation placed too much stress"), "ev");
    M(["g3", "g4", "g5"], f.at("A situation that may have been brought"), "ev");
    f.at("Question-এ Climatic Factor বলা হয়েছে");
    const m1 = f.at("Passage-এ Droughts বলা হয়েছে"); M(["g5"], m1, "strong");
    f.at("Question-এ Increased the Problems");
    const m2 = f.at("Passage-এ Brought to a Crisis Point"); M(["g4"], m2, "strong");
    const ans = f.at("Paragraph G.");
    const note = f.at("Droughts কীভাবে সমস্যাকে");
    qs.push({ n: 2, book: 15, start, end: 0, bookAt, textAt, meaning,
      qSegs: [{ t: "The " }, { t: "likelihood", k: 0 }, { t: " that a " }, { t: "climatic factor", k: 1 }, { t: " " }, { t: "increased the problems", k: 2 }, { t: " " }, { t: "Mapungubwe faced", k: 3 }, { t: "." }],
      rows: [
        { kw: "Likelihood", seg: 0, at: k[0], bn: { t: "সম্ভাবনা", at: bn[0] }, syns: [] },
        { kw: "Climatic Factor", seg: 1, at: k[1], bn: { t: "জলবায়ুগত কারণ", at: bn[1] }, syns: [{ t: "Drought", at: s[0] }, { t: "Rainfall", at: s[1] }, { t: "Extreme Weather", at: s[2] }], match: { t: "droughts", at: m1 } },
        { kw: "Increased the Problems", seg: 2, at: k[2], bn: { t: "সমস্যা আরও বাড়ানো", at: bn[2] }, syns: [], match: { t: "brought to a crisis point", at: m2 } },
        { kw: "Mapungubwe Faced", seg: 3, at: k[3], syns: [] },
      ],
      notes: [{ t: "Droughts কীভাবে সমস্যা বাড়াল — এটাই Context Matching", at: note }], answer: { letter: "G", at: ans } });
  }
  // ── Q3 ──
  {
    const start = f.at("এবার Question Number 3"), bookAt = f.at("Question 16"), textAt = f.at("A mention of the location");
    const meaning = { t: "রাজার পরিবারের সদস্যরা কোথায় বসবাস করতেন বলে ধারণা করা হয়?", at: f.at("রাজার পরিবারের সদস্যরা কোথায় বসবাস") };
    const k = [f.at("Location."), f.at("King's Family."), f.at("Thought to Have Lived.")];
    const bn = [f.at("Location অর্থ জায়গা"), f.at("King's Family অর্থ"), f.at("Thought to Have Lived অর্থ")];
    focus.push({ at: f.at("চলো, Paragraph C দেখি"), para: "C" });
    M(["c1", "c2", "c3"], f.at("There were some grander residences"), "ev");
    M(["c2b", "c4", "c5", "c6"], f.at("These probably belonged to male relatives"), "ev");
    f.at("Members of the King's Family.");
    const m1 = f.at("Male Relatives of the King."); M(["c6"], m1, "strong");
    const m2 = f.at("Probably Belonged to."); M(["c4"], m2, "strong");
    const m3 = f.at("The Outskirts of Babandyanalo."); M(["c3"], m3, "strong");
    const ans = f.at("Paragraph C.");
    const trap = f.at("গুরুত্বপূর্ণ Trap রয়েছে");
    focus.push({ at: f.at("Paragraph B দেখে ভুল"), para: "B" });
    M(["b5"], f.at("Paragraph B-তে রাজার বসবাসের জায়গা"), "bad");
    focus.push({ at: f.at("রাজার পরিবারের সদস্যদের বাসস্থান"), para: "C" });
    const n2 = f.at("Question-এর সম্পূর্ণ Meaning Match");
    qs.push({ n: 3, book: 16, start, end: 0, bookAt, textAt, meaning,
      qSegs: [{ t: "A mention of the " }, { t: "location", k: 0 }, { t: " where members of the " }, { t: "king's family", k: 1 }, { t: " are " }, { t: "thought to have lived", k: 2 }, { t: "." }],
      rows: [
        { kw: "Location", seg: 0, at: k[0], bn: { t: "জায়গা", at: bn[0] }, syns: [], match: { t: "outskirts of Babandyanalo", at: m3 } },
        { kw: "King's Family", seg: 1, at: k[1], bn: { t: "রাজার পরিবারের সদস্য", at: bn[1] }, syns: [], match: { t: "male relatives of the king", at: m1 } },
        { kw: "Thought to Have Lived", seg: 2, at: k[2], bn: { t: "বসবাস করতেন বলে ধারণা", at: bn[2] }, syns: [], match: { t: "probably belonged", at: m2 } },
      ],
      notes: [{ t: "Trap: শুধু King দেখে B নয় — King-এর Family চাই", at: trap }, { t: "পুরো Meaning Match করবে", at: n2 }], answer: { letter: "C", at: ans } });
  }
  // ── Q4 ──
  {
    const start = f.at("এবার Question Number 4"), bookAt = f.at("Question 17"), textAt = f.at("A reference to people who");
    const meaning = { t: "যারা জাহাজে করে পণ্য নিয়ে এসেছিল, এমন মানুষের কথা কোথায়?", at: f.at("এমন কিছু মানুষের কথা") };
    const k = [f.at("People."), f.at("Brought Goods."), f.at("By Ship.")];
    const s1 = [f.at("Merchants."), f.at("Traders.")];
    const s3 = [f.at("By Sea."), f.at("Sea Travel.")];
    focus.push({ at: f.at("Paragraph D দেখি"), para: "D" });
    M(["d1", "d2", "d3"], f.at("Merchants travelling from India by sea."), "ev");
    f.at("Question-এ People বলা হয়েছে");
    const m1 = f.at("Passage-এ Merchants বলা হয়েছে"); M(["d1"], m1, "strong");
    f.at("Question-এ By Ship বলা হয়েছে");
    const m3 = f.at("Passage-এ By Sea বলা হয়েছে"); M(["d3"], m3, "strong");
    const m2 = f.at("Context-এ বাণিজ্য এবং পণ্য"); M(["d2"], m2, "strong");
    const ans = f.at("Paragraph D.");
    const note = f.at("By Ship এবং By Sea সব সময়");
    qs.push({ n: 4, book: 17, start, end: 0, bookAt, textAt, meaning,
      qSegs: [{ t: "A reference to " }, { t: "people", k: 0 }, { t: " who " }, { t: "brought goods", k: 1 }, { t: " by " }, { t: "ship", k: 2 }, { t: "." }],
      rows: [
        { kw: "People", seg: 0, at: k[0], syns: [{ t: "Merchants", at: s1[0] }, { t: "Traders", at: s1[1] }], match: { t: "merchants", at: m1 } },
        { kw: "Brought Goods", seg: 1, at: k[1], syns: [], match: { t: "বাণিজ্য ও পণ্য (Context)", at: m2 } },
        { kw: "By Ship", seg: 2, at: k[2], syns: [{ t: "By Sea", at: s3[0] }, { t: "Sea Travel", at: s3[1] }], match: { t: "by sea", at: m3 } },
      ],
      notes: [{ t: "By Ship / By Sea — একই বাক্যে নাও থাকতে পারে: Meaning বোঝো", at: note }], answer: { letter: "D", at: ans } });
  }
  // ── Q5 ──
  {
    const start = f.at("এবার Question Number 5"), bookAt = f.at("Question 18"), textAt = f.at("An estimate of the size to which the");
    const meaning = { t: "Mapungubwe-এর জনগোষ্ঠী সর্বোচ্চ কত বড় হয়েছিল — তার আনুমানিক হিসাব কোথায়?", at: f.at("Mapungubwe-এর জনগোষ্ঠী সর্বোচ্চ") };
    const k = [f.at("Estimate."), f.at("Size."), f.at("Community."), f.at("Grew.")];
    const bn = [f.at("Estimate অর্থ আনুমানিক"), f.at("Size অর্থ আকার"), f.at("Community অর্থ জনগোষ্ঠী"), f.at("Grew অর্থ বৃদ্ধি")];
    focus.push({ at: f.at("চলো, Paragraph B দেখি"), para: "B" });
    M(["b0", "b1", "b2", "b3", "b4"], f.at("The total population of Mapungubwe at its peak"), "ev");
    f.at("Question-এ Estimate বলা হয়েছে");
    const m1 = f.at("Passage-এ Around বলা হয়েছে"); M(["b3"], m1, "strong");
    f.at("Question-এ Size of the Community");
    const m2 = f.at("Passage-এ Total Population বলা হয়েছে"); M(["b1"], m2, "strong");
    f.at("Question-এ Grew বলা হয়েছে");
    const m3 = f.at("Passage-এ At Its Peak বলা হয়েছে"); M(["b2"], m3, "strong");
    const ans = f.at("Paragraph B.");
    const note = f.at("Size of the Community দিয়ে");
    qs.push({ n: 5, book: 18, start, end: 0, bookAt, textAt, meaning,
      qSegs: [{ t: "An " }, { t: "estimate", k: 0 }, { t: " of the " }, { t: "size", k: 1 }, { t: " to which the Mapungubwe " }, { t: "community", k: 2 }, { t: " " }, { t: "grew", k: 3 }, { t: "." }],
      rows: [
        { kw: "Estimate", seg: 0, at: k[0], bn: { t: "আনুমানিক হিসাব", at: bn[0] }, syns: [], match: { t: "around", at: m1 } },
        { kw: "Size", seg: 1, at: k[1], bn: { t: "আকার বা পরিমাণ", at: bn[1] }, syns: [], match: { t: "total population", at: m2 } },
        { kw: "Community", seg: 2, at: k[2], bn: { t: "জনগোষ্ঠী", at: bn[2] }, syns: [] },
        { kw: "Grew", seg: 3, at: k[3], bn: { t: "বৃদ্ধি পাওয়া", at: bn[3] }, syns: [], match: { t: "at its peak", at: m3 } },
      ],
      notes: [{ t: "Size of the Community = জনসংখ্যা → এটাই Paraphrasing", at: note }], answer: { letter: "B", at: ans } });
  }
  // ── Q6 ──
  {
    const start = f.at("এবার আমাদের শেষ Question"), bookAt = f.at("Question 19"), textAt = f.at("A mention of agricultural produce");
    const meaning = { t: "কৃষিজ উৎপাদন অন্য প্রয়োজনীয় জিনিসের বিনিময়ে দেওয়া হতো — এমন Information কোথায়?", at: f.at("কৃষি থেকে উৎপাদিত পণ্য অন্য") };
    const k = [f.at("Agricultural Produce."), f.at("Exchanged."), f.at("Other Items.")];
    const bn = [f.at("Agricultural Produce অর্থ"), f.at("Exchanged অর্থ"), f.at("Other Items অর্থ")];
    focus.push({ at: f.at("চলো, Paragraph A দেখি"), para: "A" });
    M(["a1", "a2", "a2b", "a3", "a4", "a5", "a6"], f.at("Cattle herding and other types of farming"), "ev");
    f.at("Question-এ Agricultural Produce বলা হয়েছে");
    const m1 = f.at("Passage-এ Farming থেকে"); M(["a2"], m1, "strong");
    f.at("Question-এ Exchanged বলা হয়েছে");
    const m2 = f.at("Passage-এ Traded বলা হয়েছে"); M(["a4"], m2, "strong");
    f.at("Question-এ Other Items বলা হয়েছে");
    const m3 = f.at("Passage-এ Needed Goods বলা হয়েছে"); M(["a6"], m3, "strong");
    const ans = f.at("Paragraph A.");
    const note = f.at("কৃষিকাজ থেকে কী উৎপাদিত");
    qs.push({ n: 6, book: 19, start, end: 0, bookAt, textAt, meaning,
      qSegs: [{ t: "A mention of " }, { t: "agricultural produce", k: 0 }, { t: " being " }, { t: "exchanged", k: 1 }, { t: " for " }, { t: "other items", k: 2 }, { t: "." }],
      rows: [
        { kw: "Agricultural Produce", seg: 0, at: k[0], bn: { t: "কৃষিজ উৎপাদন", at: bn[0] }, syns: [], match: { t: "farming → food", at: m1 } },
        { kw: "Exchanged", seg: 1, at: k[1], bn: { t: "বিনিময় করা", at: bn[1] }, syns: [], match: { t: "traded", at: m2 } },
        { kw: "Other Items", seg: 2, at: k[2], bn: { t: "অন্যান্য জিনিস", at: bn[2] }, syns: [], match: { t: "needed goods", at: m3 } },
      ],
      notes: [{ t: "শুধু Agricultural নয় — কী উৎপাদিত হলো, তা দিয়ে কী করা হলো", at: note }], answer: { letter: "A", at: ans } });
  }
  const wEnd = cueFrame(W_END_CUE);
  qs.forEach((q, i) => { q.end = i < qs.length - 1 ? qs[i + 1].start : wEnd; });
  marks.forEach((m) => { if (m.until == null) { const q = qs.find((x) => m.at >= x.start && m.at < x.end); m.until = q ? q.end : wEnd; } });
  return { qs, shared: { focus, marks } };
}
export const WS = build();

// ═══════════════ প্যানেল বদলের wipe (একই স্ক্রিন, ডান পাশের কনটেন্ট বদলায়) ═══════════════
export const SwapPanel: React.FC<{ start: number; end: number; children: React.ReactNode; style?: React.CSSProperties }> = ({ start, end, children, style }) => {
  const { from, bg } = useContext(SceneCtx);
  return (
    <Sequence from={start - from} durationInFrames={end - start + 10}>
      <SceneCtx.Provider value={{ from: start, bg }}><WipeBox style={style}>{children}</WipeBox></SceneCtx.Provider>
    </Sequence>
  );
};
const WipeBox: React.FC<{ children: React.ReactNode; style?: React.CSSProperties }> = ({ children, style }) => {
  const { S } = useS();
  const f = useCurrentFrame();
  const p = interpolate(f, [0, 10], [0, 1], { easing: EASE.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return <div style={{ position: "absolute", inset: 0, background: S.bg, clipPath: `inset(0 ${(1 - p) * 100}% 0 0)`, ...style }}>{children}</div>;
};

// ═══════════════ প্রশ্নের ডান প্যানেল ═══════════════
const QPanel: React.FC<{ q: RQ }> = ({ q }) => {
  const g = useG();
  const done = g >= q.answer.at;
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", gap: 12 }}>
      {/* header */}
      <Rise at={q.start} dy={20} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", height: 66 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
          <div style={{ fontSize: 50, fontWeight: 700, color: COLORS.white, lineHeight: 1 }}>Question {q.n}</div>
          <Rise at={q.bookAt} dy={10}><Chip bg={COLORS.cream} fg={COLORS.dark} size={28}>বইয়ে Q{q.book}</Chip></Rise>
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} style={{ width: 24, height: 24, borderRadius: 12, background: i < q.n || (i === q.n && done) ? COLORS.red : i === q.n ? COLORS.white : "transparent", border: `3px solid ${i <= q.n ? (i < q.n || done ? COLORS.red : COLORS.white) : COLORS.mute}` }} />
          ))}
        </div>
      </Rise>
      {/* question card */}
      <Rise at={q.textAt} sfx="pop" vol={0.22}>
        <div style={{ background: COLORS.cream, color: COLORS.dark, borderRadius: 24, padding: "22px 28px", fontSize: 43, lineHeight: 1.36, fontWeight: 600 }}>
          {q.qSegs.map((s, i) => s.k == null ? <span key={i}>{s.t}</span> : <Hl key={i} at={q.rows[s.k].at} kind="kw">{s.t}</Hl>)}
        </div>
      </Rise>
      {/* meaning */}
      <Rise at={q.meaning.at} dy={14} style={{ minHeight: 78, display: "flex", gap: 14, alignItems: "flex-start" }}>
        <Chip bg="transparent" fg={COLORS.mute} border={COLORS.mute} size={22} style={{ marginTop: 4 }}>অর্থ</Chip>
        <div style={{ fontSize: 31, lineHeight: 1.38, color: COLORS.white, fontWeight: 400 }}>{q.meaning.t}</div>
      </Rise>
      {/* rows */}
      <div style={{ display: "flex", flexDirection: "column", gap: 10, flex: 1, minHeight: 0 }}>
        {q.rows.map((r, i) => (
          <Rise key={i} at={r.at} dy={18} sfx="tick" vol={0.2} rate={0.96 + i * 0.04} style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: 10, columnGap: 12 }}>
            <Chip bg={COLORS.red} fg={COLORS.white} size={34}>{r.kw}</Chip>
            {r.bn ? <Rise at={r.bn.at} dy={8} style={{ fontSize: 30, color: COLORS.mute, fontWeight: 600 }}>= {r.bn.t}</Rise> : null}
            {r.syns.map((s, j) => (
              <Rise key={j} at={s.at} dy={10} s={0.85}><Chip bg="transparent" fg={COLORS.cream} border={COLORS.mute} size={30}>{s.t}</Chip></Rise>
            ))}
            {r.match ? (
              <Rise at={r.match.at} dy={12} s={0.8} cfg={SPR.pop} sfx="click" vol={0.24} breathe>
                <Chip bg={COLORS.white} fg={COLORS.dark} size={31} border={COLORS.red}><Check size={30} color={COLORS.red} />{r.match.t}</Chip>
              </Rise>
            ) : null}
          </Rise>
        ))}
      </div>
      {/* note */}
      <div style={{ height: 70, position: "relative" }}>
        {q.notes.map((n, i) => {
          const next = q.notes[i + 1];
          if (g < n.at - 2 || (next && g >= next.at - 2)) return null;
          return <Rise key={i} at={n.at} dy={14} style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center" }}><div style={{ background: COLORS.white, color: COLORS.dark, borderRadius: 16, padding: "10px 20px", fontSize: 30, fontWeight: 700, lineHeight: 1.25, borderLeft: `10px solid ${COLORS.red}` }}>{n.t}</div></Rise>;
        })}
      </div>
      {/* answer bar */}
      <div style={{ height: 92, display: "flex", alignItems: "center", gap: 14 }}>
        <div style={{ fontSize: 30, fontWeight: 700, color: COLORS.mute, width: 96 }}>উত্তর</div>
        {LETTERS.map((L) => {
          const sel = L === q.answer.letter;
          return (
            <Rise key={L} at={sel ? q.answer.at : q.start + 10} dy={sel ? 0 : 10} s={sel ? 0.7 : 0.95} cfg={sel ? SPR.pop : SPR.snap} sfx={sel ? "chime" : undefined} vol={0.3}>
              <div style={{ width: 76, height: 76, borderRadius: 18, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 40, fontWeight: 700, background: sel && done ? COLORS.red : "transparent", color: sel && done ? COLORS.white : COLORS.mute, border: `3px solid ${sel && done ? COLORS.red : COLORS.mute}`, opacity: done && !sel ? 0.35 : 1 }}>{L}</div>
            </Rise>
          );
        })}
      </div>
    </div>
  );
};

export const WORK_H = 918;
export const Workspace: React.FC = () => (
  <div style={{ position: "relative", display: "flex", gap: 30, height: WORK_H }}>
    <PassagePane focus={WS.shared.focus} marks={WS.shared.marks} width={980} height={WORK_H} />
    <div style={{ position: "relative", width: 790, height: WORK_H }}>
      {WS.qs.map((q) => (
        <SwapPanel key={q.n} start={q.start} end={q.end}><QPanel q={q} /></SwapPanel>
      ))}
    </div>
  </div>
);

// ═══════════════ Paragraph Walkthrough (Practice পর্ব) ═══════════════
type Walk = {
  para: ParaId; sub: string; start: number; end: number;
  bullets: { t: string; at: number }[]; keys: { t: string; at: number }[]; gloss: { en: string; bn: string; at: number }[];
};
export const WALK_START_CUE = 189;
export const WALK_END_CUE = 263;
function buildWalk(): { walks: Walk[]; shared: Shared } {
  const f = new Finder(WALK_START_CUE);
  const focus: FocusEv[] = [{ at: cueFrame(WALK_START_CUE), para: "A" }];
  const marks: Mark[] = [];
  const walks: Walk[] = [];
  const M = (ids: string[], at: number, kind: Mark["kind"] = "ev") => marks.push({ ids, at, kind });
  // A
  { const start = f.at("Paragraph A-তে Mapungubwe-এর প্রাথমিক");
    const b = [f.at("কৃষিকাজ করত"), f.at("পশুপালন করত"), f.at("প্রচুর খাদ্য উৎপাদিত"), f.at("প্রয়োজনের চেয়েও বেশি খাদ্য"), f.at("Trade করা যেত")];
    const key = f.at("A surplus that could be traded for needed goods."); M(["a3", "a4", "a5", "a6"], key);
    const gl = [f.at("Surplus অর্থ"), f.at("Traded অর্থ"), f.at("Needed Goods অর্থ")];
    walks.push({ para: "A", sub: "Mapungubwe-এর প্রাথমিক পরিচয়", start, end: 0,
      bullets: [{ t: "মানুষেরা কৃষিকাজ করত", at: b[0] }, { t: "তারা পশুপালন করত", at: b[1] }, { t: "প্রচুর খাদ্য উৎপাদিত হতো", at: b[2] }, { t: "প্রয়োজনের বেশি খাদ্য → Trade", at: b[3] }],
      keys: [{ t: "A surplus that could be traded for needed goods.", at: key }],
      gloss: [{ en: "Surplus", bn: "অতিরিক্ত উৎপাদন", at: gl[0] }, { en: "Traded", bn: "বিনিময় বা বাণিজ্য করা", at: gl[1] }, { en: "Needed Goods", bn: "প্রয়োজনীয় পণ্য", at: gl[2] }] }); }
  // B
  { const start = f.at("এবার Paragraph B-তে আসি"); focus.push({ at: start, para: "B" });
    const b = f.at("জনসংখ্যা সম্পর্কে বলা হয়েছে");
    const key = f.at("The total population of Mapungubwe at its peak"); M(["b0", "b1", "b2", "b3", "b4"], key);
    const gl = [f.at("Around 5,000 People বলা হয়েছে"), f.at("ত্রয়োদশ শতাব্দীর মাঝামাঝি"), f.at("Population এবং Around শব্দ দুটি")];
    walks.push({ para: "B", sub: "Mapungubwe-এর জনসংখ্যা", start, end: 0,
      bullets: [{ t: "জনসংখ্যা নিয়ে Information", at: b }],
      keys: [{ t: "The total population of Mapungubwe at its peak in the mid-13th century was around 5,000 people.", at: key }],
      gloss: [{ en: "Around 5,000 People", bn: "আনুমানিক পাঁচ হাজার মানুষ", at: gl[0] }, { en: "Mid-13th century", bn: "ত্রয়োদশ শতাব্দীর মাঝামাঝি", at: gl[1] }, { en: "Population + Around", bn: "আনুমানিক জনসংখ্যা", at: gl[2] }] }); }
  // C
  { const start = f.at("এবার Paragraph C।"); focus.push({ at: start, para: "C" });
    const b = f.at("রাজা এবং রাজপরিবারের সদস্যদের");
    const key = f.at("There were some grander residences"); M(["c1", "c2", "c3", "c2b", "c4", "c5", "c6"], key);
    const gl = [f.at("Grander Residences বলতে"), f.at("Outskirts অর্থ"), f.at("Male Relatives of the King অর্থ")];
    walks.push({ para: "C", sub: "রাজা ও রাজপরিবারের বসবাসের জায়গা", start, end: 0,
      bullets: [{ t: "রাজপরিবারের সদস্যদের বাসস্থান", at: b }],
      keys: [{ t: "There were some grander residences dotted around the outskirts of Babandyanalo, and these probably belonged to male relatives of the king.", at: key }],
      gloss: [{ en: "Grander Residences", bn: "বড় ও উন্নত বাসস্থান", at: gl[0] }, { en: "Outskirts", bn: "এলাকার বাইরের অংশ", at: gl[1] }, { en: "Male Relatives of the King", bn: "রাজার পুরুষ আত্মীয়", at: gl[2] }] }); }
  // D
  { const start = f.at("এবার Paragraph D"); focus.push({ at: start, para: "D" });
    const b0 = f.at("বিভিন্ন জায়গা থেকে আসা পণ্য");
    const key = f.at("Merchants travelling from India by sea."); M(["d1", "d2", "d3"], key);
    const gl = [f.at("Merchants অর্থ ব্যবসায়ী"), f.at("Travelling by Sea অর্থ")];
    const b1 = f.at("Question-এ হয়তো Ship শব্দটি");
    walks.push({ para: "D", sub: "বাণিজ্য — পণ্য ও সমুদ্রপথ", start, end: 0,
      bullets: [{ t: "বিভিন্ন জায়গা থেকে আসা পণ্য", at: b0 }, { t: "Question-এ Ship → Passage-এ By Sea", at: b1 }],
      keys: [{ t: "Merchants travelling from India by sea.", at: key }],
      gloss: [{ en: "Merchants", bn: "ব্যবসায়ী", at: gl[0] }, { en: "Travelling by Sea", bn: "সমুদ্রপথে যাতায়াত", at: gl[1] }] }); }
  // E
  { const start = f.at("এবার Paragraph E-তে আসি"); focus.push({ at: start, para: "E" });
    const b = [f.at("Archaeological Discoveries"), f.at("Figures বা মূর্তি")];
    const key = f.at("Their precise function is not known."); M(["e0", "e1", "e2", "e3"], key);
    const gl = [f.at("Precise Function অর্থ"), f.at("Not Known অর্থ")];
    const b3 = f.at("কিছু মূর্তির প্রকৃত ব্যবহার");
    walks.push({ para: "E", sub: "প্রত্নতাত্ত্বিক আবিষ্কার ও Figures", start, end: 0,
      bullets: [{ t: "Archaeological Discoveries (প্রত্নতাত্ত্বিক আবিষ্কার)", at: b[0] }, { t: "Figures বা মূর্তি", at: b[1] }, { t: "মূর্তির প্রকৃত ব্যবহার নিশ্চিত নয়", at: b3 }],
      keys: [{ t: "Their precise function is not known.", at: key }],
      gloss: [{ en: "Precise Function", bn: "সঠিক ব্যবহার বা উদ্দেশ্য", at: gl[0] }, { en: "Not Known", bn: "জানা নেই", at: gl[1] }] }); }
  // F
  { const start = f.at("Paragraph F-তে Mapungubwe-এর Gold"); focus.push({ at: start, para: "F" });
    const c = f.id("Gold বা সোনা");
    const b = [f.atId(c, 0.3), f.atId(c, 0.62), f.at("প্রত্নতাত্ত্বিক নিদর্শনের Information")];
    walks.push({ para: "F", sub: "Gold ও মূল্যবান সামগ্রী", start, end: 0,
      bullets: [{ t: "Gold বা সোনা", at: b[0] }, { t: "বিভিন্ন মূল্যবান সামগ্রী", at: b[1] }, { t: "প্রত্নতাত্ত্বিক নিদর্শনের Information", at: b[2] }],
      keys: [], gloss: [] }); }
  // G
  { const start = f.at("সবশেষে Paragraph G"); focus.push({ at: start, para: "G" });
    const b0 = f.at("পতনের কারণ সম্পর্কে");
    const k1 = f.at("The kingdom of Mapungubwe was already in decline"); M(["g1"], k1);
    const b1 = f.at("ত্রয়োদশ শতাব্দীর শেষ দিকে");
    const b2 = f.at("Overpopulation বা অতিরিক্ত জনসংখ্যা"); M(["g2"], b2);
    const b3 = f.at("স্থানীয় সম্পদের ওপর অতিরিক্ত চাপ");
    const k2 = f.at("A situation that may have been brought"); M(["g3", "g4", "g5"], k2);
    const gl = f.at("Droughts অর্থ খরা");
    const b4 = f.at("একাধিক খরা পরিস্থিতিকে");
    walks.push({ para: "G", sub: "Mapungubwe-এর পতনের কারণ", start, end: 0,
      bullets: [{ t: "ত্রয়োদশ শতাব্দীর শেষ দিকে Kingdom দুর্বল", at: b1 }, { t: "সম্ভাব্য কারণ: Overpopulation", at: b2 }, { t: "স্থানীয় সম্পদের ওপর অতিরিক্ত চাপ", at: b3 }, { t: "একাধিক খরা → আরও সংকট", at: b4 }],
      keys: [{ t: "The kingdom of Mapungubwe was already in decline by the late 13th century.", at: k1 }, { t: "A situation that may have been brought to a crisis point by a series of droughts.", at: k2 }],
      gloss: [{ en: "Droughts", bn: "খরা", at: gl }] });
    void b0;
  }
  const wEnd = cueFrame(WALK_END_CUE);
  walks.forEach((w, i) => { w.end = i < walks.length - 1 ? walks[i + 1].start : wEnd; });
  marks.forEach((m) => { const w = walks.find((x) => m.at >= x.start - 2 && m.at < x.end); m.until = w ? w.end : wEnd; });
  return { walks, shared: { focus, marks } };
}
export const WK = buildWalk();

const WalkPanel: React.FC<{ w: Walk }> = ({ w }) => {
  const g = useG();
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", gap: 14 }}>
      <Rise at={w.start} dy={20} style={{ display: "flex", alignItems: "center", gap: 22 }}>
        <div style={{ width: 112, height: 112, borderRadius: 24, background: COLORS.red, color: COLORS.white, fontSize: 78, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center", flex: "none" }}>{w.para}</div>
        <div>
          <div style={{ fontSize: 30, color: COLORS.mute, fontWeight: 600 }}>Paragraph {w.para}</div>
          <div style={{ fontSize: 46, color: COLORS.white, fontWeight: 700, lineHeight: 1.15 }}>{w.sub}</div>
        </div>
      </Rise>
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {w.bullets.map((b, i) => (
          <Rise key={i} at={b.at} dy={16} style={{ display: "flex", gap: 16, alignItems: "flex-start", fontSize: 38, color: COLORS.white, lineHeight: 1.25, fontWeight: 400 }}>
            <div style={{ width: 14, height: 14, borderRadius: 7, background: COLORS.red, marginTop: 14, flex: "none" }} />{b.t}
          </Rise>
        ))}
      </div>
      <div style={{ position: "relative", minHeight: 0 }}>
        {w.keys.map((k, i) => {
          const next = w.keys[i + 1];
          if (g < k.at - 2 || (next && g >= next.at - 2)) return null;
          return (
            <Rise key={i} at={k.at} dy={20} sfx="pop" vol={0.22}>
              <div style={{ background: COLORS.cream, color: COLORS.dark, borderRadius: 22, padding: "16px 24px 20px", borderLeft: `12px solid ${COLORS.red}` }}>
                <div style={{ fontSize: 23, fontWeight: 700, color: COLORS.red, marginBottom: 4 }}>KEY SENTENCE</div>
                <div style={{ fontSize: 37, fontWeight: 600, lineHeight: 1.3 }}>{k.t}</div>
              </div>
            </Rise>
          );
        })}
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {w.gloss.map((x, i) => (
          <Rise key={i} at={x.at} dy={14} sfx="tick" vol={0.18} rate={0.95 + i * 0.05} style={{ display: "flex", alignItems: "baseline", flexWrap: "wrap", columnGap: 14, fontSize: 36 }}>
            <span style={{ fontWeight: 700, color: COLORS.white }}>{x.en}</span>
            <span style={{ color: COLORS.red, fontWeight: 700 }}>=</span>
            <span style={{ color: COLORS.mute, fontWeight: 600 }}>{x.bn}</span>
          </Rise>
        ))}
      </div>
    </div>
  );
};
export const WalkScene: React.FC = () => (
  <div style={{ position: "relative", display: "flex", gap: 30, height: WORK_H }}>
    <PassagePane focus={WK.shared.focus} marks={WK.shared.marks} width={980} height={WORK_H} />
    <div style={{ position: "relative", width: 790, height: WORK_H }}>
      {WK.walks.map((w) => (<SwapPanel key={w.para} start={w.start} end={w.end}><WalkPanel w={w} /></SwapPanel>))}
    </div>
  </div>
);
void clamp; void Sfx; void EASE;
