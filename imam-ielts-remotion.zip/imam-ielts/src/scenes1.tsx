import React from "react";
import { interpolate } from "remotion";
import { Finder } from "./lib/cues";
import { LETTERS } from "./passage";
import { SwapPanel } from "./workspace";
import { COLORS, EASE, SPR } from "./theme";
import { ArrowR, Card, CardBox, Check, Chip, Cross, Hl, Mag, Rise, Words, clamp, useG, useS } from "./ui";

const FULL: React.CSSProperties = { display: "flex", height: "100%" };

// ───────── ParaGrid: Paragraph A–G কার্ড (হুক, সংজ্ঞা ইত্যাদিতে ব্যবহৃত) ─────────
export const ParaGrid: React.FC<{ at: number; w: number; h: number; cols: number; active?: number; gap?: number }> = ({ at, w, h, cols, active = -1, gap = 22 }) => (
  <div style={{ display: "flex", flexWrap: "wrap", gap, width: cols * w + (cols - 1) * gap }}>
    {LETTERS.map((L, i) => (
      <Rise key={L} at={at + i * 4} dy={40} s={0.88} sfx={i === 0 ? "pop" : undefined}>
        <CardBox style={{ width: w, height: h, padding: 18, display: "flex", alignItems: "center", gap: 20, border: i === active ? `6px solid ${COLORS.red}` : "6px solid transparent", ...(i === active ? { background: COLORS.white } : {}) }}>
          <div style={{ fontSize: Math.round(h * 0.5), fontWeight: 700, color: COLORS.red, width: Math.round(h * 0.5) }}>{L}</div>
          <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 12 }}>
            {[100, 84, 58].map((x, j) => (<div key={j} style={{ height: 14, width: `${x}%`, borderRadius: 7, background: i === active && j === 1 ? COLORS.red : COLORS.dark }} />))}
          </div>
        </CardBox>
      </Rise>
    ))}
  </div>
);

// ═══════════ S1 — Hook ═══════════
const B1 = (() => { const f = new Finder(1); return { a: f.at("IELTS Reading-এ Matching"), b: f.at("Passage পড়েও সঠিক"), c: f.at("Keywords খোঁজে"), d: f.at("শব্দ না থাকলে বিভ্রান্ত") }; })();
export const Hook: React.FC = () => {
  const g = useG();
  const scan = g >= B1.c && g < B1.d + 20 ? Math.floor((g - B1.c) / 5) % 7 : -1;
  return (
    <div style={{ ...FULL, alignItems: "center", gap: 50 }}>
      <div style={{ width: 960, display: "flex", flexDirection: "column", gap: 30 }}>
        <Rise at={Math.max(2, B1.a)} sfx="thud" vol={0.25}><Chip bg={COLORS.red} fg={COLORS.white} size={36}>IELTS Reading</Chip></Rise>
        <Words text="Matching Information" at={Math.max(4, B1.a + 4)} size={132} accent={["Matching"]} accentColor={COLORS.red} lh={1.05} />
        <Words text="Passage পড়েও উত্তর মেলে না?" at={B1.b} size={60} weight={600} accent={["মেলে", "না?"]} />
        <Rise at={B1.c} style={{ display: "flex", alignItems: "center", gap: 16, fontSize: 46, color: COLORS.white, fontWeight: 600 }}>
          <Mag size={56} color={COLORS.red} /> Question-এর Keywords খোঁজা
        </Rise>
        <Rise at={B1.d} style={{ fontSize: 46, color: COLORS.mute, fontWeight: 600 }}>Passage-এ সেই শব্দ নেই → বিভ্রান্তি</Rise>
      </div>
      <div style={{ position: "relative", flex: 1, display: "flex", justifyContent: "center", paddingTop: 10 }}>
        <ParaGrid at={B1.a + 10} w={420} h={170} cols={2} active={scan} />
        <Rise at={B1.d} cfg={SPR.pop} s={0.3} breathe style={{ position: "absolute", left: 560, top: 330 }}>
          <div style={{ width: 230, height: 230, borderRadius: 115, background: COLORS.red, color: COLORS.white, fontSize: 170, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center", border: `10px solid ${COLORS.dark}` }}>?</div>
        </Rise>
      </div>
    </div>
  );
};

// ═══════════ S2 — আজ কী শিখবে ═══════════
const B2 = (() => {
  const f = new Finder(5);
  const t = f.at("আজকের ক্লাসে আমরা শিখব");
  const i1 = f.at("সম্পূর্ণ Strategy"); const i2 = f.at("বাস্তব IELTS Reading Passage"); const i3 = f.at("Question Analysis");
  const c = f.id("Keywords খুঁজতে"); const i4 = f.atId(c, 0.1); const i5 = f.atId(c, 0.5);
  const i6 = f.at("Paragraph নির্বাচন"); const go = f.at("চলো, শুরু করা যাক");
  return { t, items: [["Matching Information-এর সম্পূর্ণ Strategy", i1], ["প্রতিটি Strategy বাস্তব Passage-এ", i2], ["Question Analysis", i3], ["Keywords খোঁজা", i4], ["Paraphrase চেনা", i5], ["সঠিক Paragraph নির্বাচন", i6]] as [string, number][], go };
})();
export const Promise2: React.FC = () => (
  <div style={{ ...FULL, alignItems: "center", gap: 60 }}>
    <div style={{ width: 640, display: "flex", flexDirection: "column", gap: 28 }}>
      <Words text="আজ কী শিখবে?" at={B2.t} size={104} lh={1.1} accent={["শিখবে?"]} />
      <Rise at={B2.t + 14} style={{ fontSize: 40, fontWeight: 600 }}>Matching Information · IELTS Reading</Rise>
      <Rise at={B2.go} cfg={SPR.pop} sfx="chime" vol={0.25}><Chip bg={COLORS.red} fg={COLORS.white} size={44}>চলো, শুরু করা যাক <ArrowR size={44} /></Chip></Rise>
    </div>
    <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 16 }}>
      {B2.items.map(([t, at], i) => (
        <Card key={i} at={at} sfx={i === 0 || i === 2 ? "pop" : undefined} vol={0.22} style={{ padding: "20px 30px", display: "flex", alignItems: "center", gap: 24, fontSize: 44, fontWeight: 600 }}>
          <div style={{ width: 62, height: 62, borderRadius: 31, background: COLORS.red, color: COLORS.white, display: "flex", alignItems: "center", justifyContent: "center", flex: "none" }}><Check size={38} /></div>
          {t}
        </Card>
      ))}
    </div>
  </div>
);

// ═══════════ S3 — Practice Material কোথা থেকে ═══════════
const B3 = (() => {
  const f = new Finder(13);
  const a = f.at("Practice Material কোথা থেকে"); const b = f.at("Cambridge IELTS 21, Test 2"); const c = f.at("Passage-এর নাম Mapungubwe");
  const d = f.at("মোট সাতটি Paragraph"); const e = f.id("Paragraph A থেকে Paragraph G"); const q = f.at("Questions 14 থেকে 19");
  return { a, b, c, d, e, q };
})();
export const Source: React.FC = () => (
  <div style={{ ...FULL, alignItems: "center", gap: 70 }}>
    <div style={{ display: "flex", flexDirection: "column", gap: 24, width: 640 }}>
      <Rise at={B3.a}><Chip bg={COLORS.cream} fg={COLORS.dark} size={36}>আজকের Practice Material</Chip></Rise>
      <Rise at={B3.b} dy={50} s={0.9} sfx="pop" vol={0.25}>
        <div style={{ background: COLORS.dark, borderRadius: 30, padding: "44px 48px", color: COLORS.white }}>
          <div style={{ fontSize: 38, fontWeight: 600, color: COLORS.mute }}>CAMBRIDGE</div>
          <div style={{ fontSize: 118, fontWeight: 700, lineHeight: 1, whiteSpace: "nowrap" }}>IELTS 21</div>
          <div style={{ height: 6, background: COLORS.red, width: 160, margin: "20px 0" }} />
          <div style={{ fontSize: 42, fontWeight: 700, lineHeight: 1.2 }}>Test 2<br />Reading Passage 2</div>
        </div>
      </Rise>
    </div>
    <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 30 }}>
      <Words text="Mapungubwe" at={B3.c} size={150} lh={1} />
      <Rise at={B3.d} style={{ fontSize: 46, fontWeight: 600 }}>মোট ৭টি Paragraph</Rise>
      <div style={{ display: "flex", gap: 14 }}>
        {LETTERS.map((L, i) => (
          <Rise key={L} at={B3.e + Math.round(i * 5)} s={0.7} cfg={SPR.pop}><div style={{ width: 100, height: 100, borderRadius: 22, background: COLORS.cream, color: COLORS.dark, fontSize: 64, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center" }}>{L}</div></Rise>
        ))}
      </div>
      <Rise at={B3.q} cfg={SPR.pop} sfx="chime" vol={0.25}><Chip bg={COLORS.dark} fg={COLORS.white} size={56}>Questions 14 – 19</Chip></Rise>
    </div>
  </div>
);

// ═══════════ S4 — Online নম্বর vs মূল বইয়ের নম্বর ═══════════
const B4 = (() => {
  const f = new Finder(19);
  const t = f.at("বিশেষভাবে মনে রাখবে"); const l = f.at("Online Practice Website-এ"); const r = f.at("মূল বইয়ে এই");
  const r1 = f.at("Question 1 হলো মূল বইয়ের Question 14"); const r2 = f.at("Question 2 হলো মূল বইয়ের Question 15");
  const c = f.id("এভাবে Question 6 হলো");
  const rows = [r1, r2, f.atId(c, 0), f.atId(c, 0.12), f.atId(c, 0.24), f.atId(c, 0.5)];
  const n1 = f.at("এটি কোনো ভুল প্রশ্ন নয়"); const n2 = f.at("নতুন করে সাজানো");
  return { t, l, r, rows, n1, n2 };
})();
export const Mapping: React.FC = () => (
  <div style={{ display: "flex", flexDirection: "column", height: "100%", gap: 24, justifyContent: "center" }}>
    <Words text="Online ≠ মূল বই — নম্বর আলাদা" at={B4.t} size={64} accent={["আলাদা"]} />
    <div style={{ display: "flex", alignItems: "center", gap: 26 }}>
      <Card at={B4.l} outer={{ flex: 1 }} style={{ padding: "16px 30px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ fontSize: 32, fontWeight: 600 }}>Online Practice Website</div><div style={{ fontSize: 56, fontWeight: 700, color: COLORS.red }}>1 – 6</div>
      </Card>
      <Rise at={B4.r}><ArrowR size={64} color={COLORS.red} /></Rise>
      <Card at={B4.r} sfx="pop" vol={0.22} outer={{ flex: 1 }} style={{ padding: "16px 30px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ fontSize: 32, fontWeight: 600 }}>Cambridge IELTS 21 (মূল বই)</div><div style={{ fontSize: 56, fontWeight: 700, color: COLORS.red }}>14 – 19</div>
      </Card>
    </div>
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      {B4.rows.map((at, i) => (
        <Rise key={i} at={at} dy={22} sfx="tick" vol={0.2} rate={0.95 + i * 0.03} style={{ display: "flex", alignItems: "center", gap: 26 }}>
          <div style={{ flex: 1, borderRadius: 20, border: `3px solid ${COLORS.mute}`, color: COLORS.white, padding: "12px 30px", fontSize: 48, fontWeight: 600 }}>Question {i + 1}</div>
          <ArrowR size={52} color={COLORS.red} />
          <div style={{ flex: 1, borderRadius: 20, background: COLORS.red, color: COLORS.white, padding: "12px 30px", fontSize: 48, fontWeight: 700 }}>Question {i + 14}</div>
        </Rise>
      ))}
    </div>
    <div style={{ display: "flex", gap: 20, marginTop: 4 }}>
      <Rise at={B4.n1}><Chip bg="transparent" fg={COLORS.white} border={COLORS.mute} size={40}><Cross size={34} color={COLORS.red} /> ভুল প্রশ্ন নয়</Chip></Rise>
      <Rise at={B4.n2} cfg={SPR.pop}><Chip bg={COLORS.cream} fg={COLORS.dark} size={40}>শুধু Question Number নতুন করে সাজানো</Chip></Rise>
    </div>
  </div>
);

// ═══════════ S5a — Matching Information কী ═══════════
const B5 = (() => {
  const f = new Finder(28);
  const t = f.at("Matching Information আসলে কী"); const d = f.at("নির্দিষ্ট একটি"); const n = f.at("সাতটি Paragraph");
  const c = f.id("A, B, C, D, E, F এবং G"); const chips = LETTERS.map((_, i) => f.atId(c, i * 0.12));
  const info = f.at("কয়েকটি Information"); const find = f.at("প্রতিটি Information কোন");
  const no = f.at("Main Idea বের করতে হবে না"); const yes = f.at("নির্দিষ্ট একটি Information খুঁজতে");
  return { t, d, n, chips, info, find, no, yes };
})();
export const DefineMI: React.FC = () => (
  <div style={{ display: "flex", flexDirection: "column", height: "100%", gap: 34, justifyContent: "center" }}>
    <Words text="Matching Information কী?" at={B5.t} size={96} accent={["কী?"]} />
    <Card at={B5.d} sfx="pop" vol={0.22} style={{ padding: "24px 34px", fontSize: 48, fontWeight: 600 }}>Passage-এর কোন <b style={{ color: COLORS.red }}>Paragraph</b>-এ নির্দিষ্ট একটি <b style={{ color: COLORS.red }}>Information</b> আছে — সেটি খুঁজে বের করা</Card>
    <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
      <Rise at={B5.n} style={{ fontSize: 36, fontWeight: 700, width: 250 }}>৭টি Paragraph</Rise>
      {LETTERS.map((L, i) => (
        <Rise key={L} at={B5.chips[i]} s={0.7} cfg={SPR.pop}><div style={{ width: 140, height: 140, borderRadius: 28, background: COLORS.dark, color: COLORS.white, fontSize: 88, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center" }}>{L}</div></Rise>
      ))}
    </div>
    <div style={{ display: "flex", gap: 20 }}>
      {[1, 2, 3].map((n, i) => (
        <Card key={n} at={B5.info + i * 5} sfx={i === 0 ? "pop" : undefined} outer={{ flex: 1 }} style={{ padding: "24px 26px", display: "flex", alignItems: "center", justifyContent: "space-between", fontSize: 40, fontWeight: 700 }}>
          <span>Information {n}</span>
          <Rise at={B5.find + i * 6} cfg={SPR.pop} s={0.4} breathe><ArrowR size={44} color={COLORS.red} /></Rise>
          <Rise at={B5.find + i * 6 + 4} cfg={SPR.pop} s={0.4}><div style={{ width: 70, height: 70, borderRadius: 18, background: COLORS.red, color: COLORS.white, fontSize: 50, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center" }}>?</div></Rise>
        </Card>
      ))}
    </div>
    <div style={{ display: "flex", gap: 24 }}>
      <Rise at={B5.no}><Chip bg="transparent" fg={COLORS.dark} border={COLORS.dark} size={42}><Cross size={36} color={COLORS.red} /> পুরো Paragraph-এর Main Idea নয়</Chip></Rise>
      <Rise at={B5.yes} cfg={SPR.pop} sfx="click" vol={0.25}><Chip bg={COLORS.red} fg={COLORS.white} size={42}><Check size={36} /> নির্দিষ্ট একটি Information</Chip></Rise>
    </div>
  </div>
);

// ═══════════ S5b — Matching Information vs Headings ═══════════
const B5b = (() => {
  const f = new Finder(41);
  const t = f.at("এক জিনিস নয়"); const a = f.at("Matching Headings-এ আমরা"); const b = f.at("Matching Information-এ আমরা");
  const c = f.at("অনেক ধরনের"); const d = f.at("Question-এ চাওয়া Information");
  return { t, a, b, c, d };
})();
const Lines: React.FC<{ hot: number[]; all?: boolean }> = ({ hot, all }) => (
  <div style={{ display: "flex", flexDirection: "column", gap: 14, marginTop: 20 }}>
    {Array.from({ length: 7 }).map((_, i) => (<div key={i} style={{ height: 22, width: i === 6 ? "62%" : "100%", borderRadius: 11, background: all || hot.includes(i) ? COLORS.red : COLORS.mute }} />))}
  </div>
);
export const MIvsMH: React.FC = () => (
  <div style={{ display: "flex", flexDirection: "column", height: "100%", gap: 34, justifyContent: "center" }}>
    <Words text="দুটো Question Type এক নয়" at={B5b.t} size={72} />
    <div style={{ display: "flex", gap: 36, alignItems: "stretch" }}>
      <Card at={B5b.a} sfx="pop" vol={0.22} outer={{ flex: 1 }} style={{ padding: "30px 36px", height: 560, boxSizing: "border-box" }}>
        <div style={{ fontSize: 52, fontWeight: 700 }}>Matching Headings</div>
        <div style={{ fontSize: 38, fontWeight: 600, marginTop: 10 }}>পুরো Paragraph-এর <b style={{ color: COLORS.red }}>Main Idea</b></div>
        <Lines hot={[]} all />
      </Card>
      <Card at={B5b.b} sfx="pop" vol={0.22} outer={{ flex: 1 }} style={{ padding: "30px 36px", height: 560, boxSizing: "border-box" }}>
        <div style={{ fontSize: 52, fontWeight: 700 }}>Matching Information</div>
        <div style={{ fontSize: 38, fontWeight: 600, marginTop: 10 }}>Paragraph-এর <b style={{ color: COLORS.red }}>নির্দিষ্ট Information</b></div>
        <Lines hot={[3]} />
      </Card>
    </div>
    <div style={{ display: "flex", gap: 24, alignItems: "center" }}>
      <Rise at={B5b.c}><Chip bg={COLORS.dark} fg={COLORS.white} size={42}>এক Paragraph-এ অনেক ধরনের Information</Chip></Rise>
      <Rise at={B5b.d} cfg={SPR.pop}><ArrowR size={56} color={COLORS.white} /></Rise>
      <Rise at={B5b.d + 4} cfg={SPR.pop}><Chip bg={COLORS.cream} fg={COLORS.dark} size={42}>চাওয়া Information-টি খুঁজে বের করো</Chip></Rise>
    </div>
  </div>
);

// ═══════════ S6 — Exact word vs Paraphrasing (একই কার্ড জোড়া, লেখা বদলায়) ═══════════
const B6 = (() => {
  const f = new Finder(46);
  const t = f.at("ছোট উদাহরণ"); const p1 = f.at("The population of the city reached"); const q1 = f.at("An estimate of the city's population.");
  const l1 = f.at("Question-এ Population শব্দটি"); const l2 = f.at("Passage-এও Population"); const easy = f.at("খুঁজে পাওয়া সহজ");
  const no = f.at("সব সময় এভাবে সরাসরি"); const para = f.at("Paraphrasing");
  const s2 = f.at("যেমন:"); const q2 = f.at("Question: The number of people increased."); const p2 = f.at("Passage: The population grew.");
  const diff = f.at("শব্দ আলাদা"); const same = f.at("অর্থ একই"); const vocab = f.at("Vocabulary জানলেই"); const mean = f.at("Meaning বুঝতে হবে");
  return { t, p1, q1, l1, l2, easy, no, para, s2, q2, p2, diff, same, vocab, mean };
})();
const PairCard: React.FC<{ label: string; at: number; children: React.ReactNode }> = ({ label, at, children }) => (
  <Card at={at} sfx="pop" vol={0.22} style={{ padding: "22px 34px", display: "flex", alignItems: "center", gap: 28 }}>
    <Chip bg={COLORS.dark} fg={COLORS.white} size={28}>{label}</Chip>
    <div style={{ fontSize: 76, fontWeight: 600, lineHeight: 1.25 }}>{children}</div>
  </Card>
);
const Ex1: React.FC = () => (
  <div style={{ display: "flex", flexDirection: "column", height: "100%", gap: 34, justifyContent: "center" }}>
    <Rise at={B6.t}><Chip bg={COLORS.red} fg={COLORS.white} size={40}>উদাহরণ ১ — একই শব্দ</Chip></Rise>
    <PairCard label="Passage" at={B6.p1}>The <Hl at={B6.l2}>population</Hl> of the city reached 50,000 people.</PairCard>
    <PairCard label="Question" at={B6.q1}>An estimate of the city's <Hl at={B6.l1}>population</Hl>.</PairCard>
    <div style={{ display: "flex", gap: 24, alignItems: "center" }}>
      <Rise at={B6.easy} cfg={SPR.pop}><Chip bg={COLORS.cream} fg={COLORS.dark} size={40}><Check size={36} color={COLORS.red} /> শব্দ মিলছে → খোঁজা সহজ</Chip></Rise>
      <Rise at={B6.no}><Chip bg="transparent" fg={COLORS.white} border={COLORS.mute} size={40}><Cross size={36} color={COLORS.red} /> কিন্তু IELTS-এ সব সময় নয়</Chip></Rise>
    </div>
  </div>
);
const Ex2: React.FC = () => (
  <div style={{ display: "flex", flexDirection: "column", height: "100%", gap: 34, justifyContent: "center" }}>
    <Rise at={B6.s2}><Chip bg={COLORS.red} fg={COLORS.white} size={40}>উদাহরণ ২ — Paraphrasing</Chip></Rise>
    <PairCard label="Question" at={B6.q2}>The <Hl at={B6.same}>number of people</Hl> <Hl at={B6.same + 10}>increased</Hl>.</PairCard>
    <PairCard label="Passage" at={B6.p2}>The <Hl at={B6.same}>population</Hl> <Hl at={B6.same + 10}>grew</Hl>.</PairCard>
    <div style={{ display: "flex", gap: 24, alignItems: "center" }}>
      <Rise at={B6.diff}><Chip bg="transparent" fg={COLORS.white} border={COLORS.mute} size={40}>শব্দ আলাদা</Chip></Rise>
      <Rise at={B6.same} cfg={SPR.pop} sfx="click" vol={0.25}><Chip bg={COLORS.red} fg={COLORS.white} size={40}><Check size={36} /> অর্থ একই</Chip></Rise>
      <Rise at={B6.vocab}><Chip bg={COLORS.cream} fg={COLORS.dark} size={40}>Vocabulary নয় — Meaning বোঝো</Chip></Rise>
    </div>
  </div>
);
export const Example: React.FC = () => (
  <div style={{ position: "relative", height: "100%" }}>
    <SwapPanel start={B6.t - 8} end={B6.s2 - 4} style={{}}><Ex1 /></SwapPanel>
    <SwapPanel start={B6.s2 - 4} end={B6.mean + 600} style={{}}><Ex2 /></SwapPanel>
    <Rise at={B6.para} cfg={SPR.pop} sfx="chime" vol={0.25} style={{ position: "absolute", right: 0, top: 0 }}><Chip bg={COLORS.cream} fg={COLORS.dark} size={46}>Paraphrasing</Chip></Rise>
  </div>
);

// ═══════════ S7a — Step 1: আগে Questions ═══════════
const B7 = (() => {
  const f = new Finder(65);
  const t = f.at("সম্পূর্ণ Strategy"); const a = f.at("Passage পড়তে যাবে না"); const b = f.at("আগে Questions পড়বে"); const c = f.at("Questions না বুঝে");
  return { t, a, b, c };
})();
export const StepRead: React.FC = () => (
  <div style={{ display: "flex", flexDirection: "column", height: "100%", gap: 30 }}>
    <Rise at={B7.t}><Chip bg={COLORS.red} fg={COLORS.white} size={40}>Strategy · Step 1</Chip></Rise>
    <div style={{ display: "flex", gap: 40, flex: 1, alignItems: "stretch" }}>
      <Rise at={B7.a} style={{ flex: 1, display: "flex" }}>
        <CardBox style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", gap: 20, opacity: 0.75 }}>
          <div style={{ fontSize: 110, fontWeight: 700 }}>Passage</div>
          <Chip bg={COLORS.dark} fg={COLORS.white} size={42}><Cross size={36} color={COLORS.red} /> প্রথমে নয়</Chip>
        </CardBox>
      </Rise>
      <Rise at={B7.b} sfx="pop" vol={0.25} style={{ flex: 1, display: "flex" }}>
        <CardBox style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", gap: 20, border: `8px solid ${COLORS.red}` }}>
          <div style={{ fontSize: 110, fontWeight: 700, color: COLORS.red }}>Questions</div>
          <Chip bg={COLORS.red} fg={COLORS.white} size={42}><Check size={36} /> আগে এটি পড়ো</Chip>
        </CardBox>
      </Rise>
    </div>
    <Rise at={B7.c} style={{ fontSize: 50, fontWeight: 600, textAlign: "center" }}>Questions না বুঝলে — <b style={{ color: COLORS.red }}>কোন Information খুঁজছ</b> বুঝবে না</Rise>
  </div>
);

// ═══════════ S7b — Question Analysis (Estimate · Size · Community) ═══════════
const B7b = (() => {
  const f = new Finder(69);
  const q = f.at("An estimate of the size to which a community grew"); f.at("এখানে কী চাওয়া হয়েছে");
  const k1 = f.at("প্রথমত, Estimate"); const b1 = f.at("আনুমানিক হিসাব");
  const k2 = f.at("দ্বিতীয়ত, Size"); const b2 = f.at("আকার বা পরিমাণ");
  const k3 = f.at("তৃতীয়ত, Community"); const b3 = f.at("একটি জনগোষ্ঠী");
  const mean = f.at("একটি জনগোষ্ঠীর আকার বা জনসংখ্যা");
  const c81 = f.id("Population, Number of People"); const c82 = f.id("Approximately-এর মতো");
  const chips = [f.atId(c81, 0.3), f.atId(c81, 0.55), f.atId(c81, 0.85), f.atId(c82, 0)];
  const fin = f.at("একটি Question ভালোভাবে বুঝলে");
  return { q, k: [k1, k2, k3], b: [b1, b2, b3], mean, chips, fin };
})();
export const Analyze: React.FC = () => {
  const kw = [["Estimate", "আনুমানিক হিসাব"], ["Size", "আকার বা পরিমাণ"], ["Community", "জনগোষ্ঠী"]];
  const hl = { bg: COLORS.cream, fg: COLORS.dark };
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", gap: 28, justifyContent: "center" }}>
      <Card at={B7b.q} sfx="pop" vol={0.22} style={{ padding: "26px 36px", fontSize: 62, fontWeight: 700, lineHeight: 1.25 }}>
        <span style={{ color: COLORS.cream, fontSize: 28, fontWeight: 600, display: "block", marginBottom: 6 }}>QUESTION</span>
        An <Hl at={B7b.k[0]} colors={{ bg: COLORS.red, fg: COLORS.white }}>estimate</Hl> of the <Hl at={B7b.k[1]} colors={{ bg: COLORS.red, fg: COLORS.white }}>size</Hl> to which a <Hl at={B7b.k[2]} colors={{ bg: COLORS.red, fg: COLORS.white }}>community</Hl> grew.
      </Card>
      <div style={{ display: "flex", gap: 20 }}>
        {kw.map(([en, bn], i) => (
          <Rise key={en} at={B7b.k[i]} style={{ flex: 1 }} sfx="tick" vol={0.2} rate={0.95 + i * 0.05}>
            <div style={{ background: COLORS.cream, color: COLORS.dark, borderRadius: 24, padding: "18px 26px" }}>
              <div style={{ fontSize: 28, fontWeight: 700, color: COLORS.red }}>{["প্রথমত", "দ্বিতীয়ত", "তৃতীয়ত"][i]}</div>
              <div style={{ fontSize: 56, fontWeight: 700, lineHeight: 1.1 }}>{en}</div>
              <Rise at={B7b.b[i]} dy={10}><div style={{ fontSize: 38, fontWeight: 600 }}>= {bn}</div></Rise>
            </div>
          </Rise>
        ))}
      </div>
      <Rise at={B7b.mean} style={{ background: COLORS.dark, color: COLORS.white, borderRadius: 24, padding: "18px 30px", fontSize: 40, fontWeight: 600, lineHeight: 1.3 }}>
        অর্থ: একটি জনগোষ্ঠী কত বড় হয়েছিল — তার <b style={{ color: COLORS.cream }}>আনুমানিক হিসাব</b>
      </Rise>
      <div style={{ display: "flex", alignItems: "center", gap: 16, flexWrap: "wrap" }}>
        <Rise at={B7b.chips[0]} style={{ fontSize: 36, fontWeight: 700, display: "flex", alignItems: "center", gap: 10 }}><Mag size={44} /> Passage-এ খুঁজবে:</Rise>
        {["Population", "Number of People", "Around", "Approximately"].map((t, i) => (
          <Rise key={t} at={B7b.chips[i]} s={0.8} cfg={SPR.pop}><Chip bg={COLORS.cream} fg={COLORS.dark} size={36}>{t}</Chip></Rise>
        ))}
      </div>
      <Rise at={B7b.fin} style={{ fontSize: 38, fontWeight: 600 }}>Question ভালো করে বুঝলে আগেই জানো — কী ধরনের Information খুঁজবে</Rise>
    </div>
  );
};

// ═══════════ S8 — Keywords & Synonyms ═══════════
const B8 = (() => {
  const f = new Finder(86);
  const t = f.at("গুরুত্বপূর্ণ Keywords বের করবে"); const eq = f.at("সব শব্দ সমান"); const q = f.at("A mention of the uncertainty");
  const k = [f.at("Uncertainty."), f.at("Purpose."), f.at("Certain Objects.")];
  const no = f.at("Uncertainty শব্দটি");
  const s = [f.at("Not known."), f.at("Unknown."), f.at("Unclear.")]; const fn = f.at("Function ব্যবহার");
  const n1 = f.at("মুখস্থ করে রাখবে না"); const n2 = f.at("Meaning বুঝবে"); const n3 = f.at("Synonyms চিন্তা করবে");
  return { t, eq, q, k, no, s, fn, n1, n2, n3 };
})();
export const Keywords: React.FC = () => (
  <div style={{ display: "flex", flexDirection: "column", height: "100%", gap: 24 }}>
    <div style={{ display: "flex", gap: 24, alignItems: "center" }}>
      <Words text="Keywords বের করো" at={B8.t} size={72} accent={["Keywords"]} />
      <Rise at={B8.eq}><Chip bg="transparent" fg={COLORS.mute} border={COLORS.mute} size={32}>সব শব্দ সমান গুরুত্বপূর্ণ নয়</Chip></Rise>
    </div>
    <div style={{ display: "flex", gap: 40, flex: 1 }}>
      <Card at={B8.q} sfx="pop" vol={0.22} outer={{ width: 820 }} style={{ padding: "30px 36px", fontSize: 54, fontWeight: 600, lineHeight: 1.35, height: "100%", boxSizing: "border-box" }}>
        <div style={{ fontSize: 26, fontWeight: 700, color: COLORS.red, marginBottom: 8 }}>QUESTION</div>
        A mention of the <Hl at={B8.k[0]} kind="kw">uncertainty</Hl> regarding the <Hl at={B8.k[1]} kind="kw">purpose</Hl> of <Hl at={B8.k[2]} kind="kw">certain objects</Hl>.
      </Card>
      <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 34, justifyContent: "center" }}>
        <Rise at={B8.k[0]} sfx="tick" vol={0.2} style={{ display: "flex", flexWrap: "wrap", gap: 12, alignItems: "center" }}>
          <Chip bg={COLORS.red} fg={COLORS.white} size={48}>Uncertainty</Chip>
          <Rise at={B8.no} dy={8}><div style={{ fontSize: 30, color: COLORS.mute, fontWeight: 600, textDecoration: "line-through", textDecorationColor: COLORS.red }}>Passage-এ নাও থাকতে পারে</div></Rise>
          <div style={{ flexBasis: "100%", height: 0 }} />
          {["Not known", "Unknown", "Unclear"].map((x, i) => (<Rise key={x} at={B8.s[i]} s={0.85}><Chip bg="transparent" fg={COLORS.cream} border={COLORS.cream} size={42}>{x}</Chip></Rise>))}
        </Rise>
        <Rise at={B8.k[1]} sfx="tick" vol={0.2} rate={1.05} style={{ display: "flex", flexWrap: "wrap", gap: 12, alignItems: "center" }}>
          <Chip bg={COLORS.red} fg={COLORS.white} size={48}>Purpose</Chip>
          <Rise at={B8.fn} s={0.85}><Chip bg="transparent" fg={COLORS.cream} border={COLORS.cream} size={42}>Function</Chip></Rise>
        </Rise>
        <Rise at={B8.k[2]} sfx="tick" vol={0.2} rate={1.1}><Chip bg={COLORS.red} fg={COLORS.white} size={48}>Certain Objects</Chip></Rise>
      </div>
    </div>
    <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
      <Rise at={B8.n1}><Chip bg="transparent" fg={COLORS.white} border={COLORS.mute} size={34}><Cross size={30} color={COLORS.red} /> শুধু শব্দ মুখস্থ</Chip></Rise>
      <Rise at={B8.n2}><ArrowR size={44} color={COLORS.red} /></Rise>
      <Rise at={B8.n2} cfg={SPR.pop}><Chip bg={COLORS.cream} fg={COLORS.dark} size={34}>Meaning বোঝো</Chip></Rise>
      <Rise at={B8.n3}><ArrowR size={44} color={COLORS.red} /></Rise>
      <Rise at={B8.n3} cfg={SPR.pop} sfx="click" vol={0.25}><Chip bg={COLORS.red} fg={COLORS.white} size={34}>Synonyms ভাবো</Chip></Rise>
    </div>
  </div>
);
void interpolate; void EASE; void clamp; void useS;
