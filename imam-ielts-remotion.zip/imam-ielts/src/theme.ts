import { Easing } from "remotion";

export const FPS = 30;
export const W = 1920;
export const H = 1080;
export const LEAD = 4; // ভিজ্যুয়াল কথার ৪ ফ্রেম আগে ঢোকে

// ইউজারের থিম: কালো / ক্রিম / লাল + সাদা, ছোট লেখার জন্য হালকা ধূসর। কোনো গ্রেডিয়েন্ট নেই।
export const COLORS = {
  dark: "#15110D",
  cream: "#F5F1ED",
  red: "#E21A1E",
  white: "#FFFFFF",
  mute: "#B8B4A8",
} as const;

export type BgName = "dark" | "cream" | "red";
export type Scheme = {
  bg: string; fg: string; sub: string; accent: string; accentFg: string;
  card: string; cardFg: string; line: string; dim: string; chip: string; chipFg: string;
};
export const SCHEMES: Record<BgName, Scheme> = {
  dark: { bg: COLORS.dark, fg: COLORS.white, sub: COLORS.mute, accent: COLORS.red, accentFg: COLORS.white, card: COLORS.cream, cardFg: COLORS.dark, line: COLORS.mute, dim: COLORS.mute, chip: COLORS.red, chipFg: COLORS.white },
  cream: { bg: COLORS.cream, fg: COLORS.dark, sub: COLORS.dark, accent: COLORS.red, accentFg: COLORS.white, card: COLORS.white, cardFg: COLORS.dark, line: COLORS.dark, dim: COLORS.mute, chip: COLORS.dark, chipFg: COLORS.white },
  red: { bg: COLORS.red, fg: COLORS.white, sub: COLORS.cream, accent: COLORS.dark, accentFg: COLORS.white, card: COLORS.dark, cardFg: COLORS.white, line: COLORS.white, dim: COLORS.cream, chip: COLORS.cream, chipFg: COLORS.dark },
};

export const FONT = '"Hind Siliguri", sans-serif';

export const SPR = {
  snap: { damping: 17, stiffness: 190, mass: 0.7 },
  soft: { damping: 22, stiffness: 110, mass: 0.9 },
  pop: { damping: 11, stiffness: 210, mass: 0.6 },
};
export const EASE = {
  out: Easing.bezier(0.16, 1, 0.3, 1),
  inOut: Easing.bezier(0.65, 0, 0.35, 1),
};
export type SfxName = "pop" | "click" | "tick" | "whoosh" | "chime" | "thud";
export const SFX_FRAMES: Record<SfxName, number> = { pop: 12, click: 6, tick: 5, whoosh: 26, chime: 18, thud: 14 };
