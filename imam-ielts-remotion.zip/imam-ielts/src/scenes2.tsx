import React from "react";
import { interpolate } from "remotion";
import { Finder } from "./lib/cues";
import { LETTERS } from "./passage";
import { COLORS, EASE, SPR } from "./theme";
import { ArrowR, Card, CardBox, Check, Chip, Cross, Mag, Rise, Words, clamp, useG } from "./ui";

const COL: React.CSSProperties = { display: "flex", flexDirection: "column", height: "100%", justifyContent: "center" };

// ═══════════ S9 — Paraphrase জোড়া ═══════════
const B9 = (() => {
  const f = new Finder(105);
  const t = f.at("এবার আসি Paraphrasing"); const sub = f.at("একই Information বিভিন্ন শব্দ");
  const pairs = [["The number of people.", "The population."], ["People who lived in a particular place.", "Residents of that area."], ["Goods exchanged for other items.", "Products traded for needed goods."], ["An unknown purpose.", "Its precise function is not known."]]
    .map(([q, p]) => [f.at(q), f.at(p)] as [number, number]);
  const ex = f.at("Exact Word Matching নয়"); const mm = f.at("এটি মূলত Meaning Matching");
  return { t, sub, pairs, ex, mm };
})();
const PAIRS: [string, string][] = [["The number of people.", "The population."], ["People who lived in a particular place.", "Residents of that area."], ["Goods exchanged for other items.", "Products traded for needed goods."], ["An unknown purpose.", "Its precise function is not known."]];
export const PairsScene: React.FC = () => (
  <div style={{ ...COL, gap: 22 }}>
    <div style={{ display: "flex", alignItems: "center", gap: 30 }}>
      <Words text="Paraphrasing" at={B9.t} size={92} accent={["Paraphrasing"]} />
      <Rise at={B9.sub} style={{ fontSize: 40, fontWeight: 600 }}>একই Information — ভিন্ন শব্দ</Rise>
    </div>
    {PAIRS.map(([q, p], i) => (
      <div key={i} style={{ display: "flex", alignItems: "center", gap: 22 }}>
        <Card at={B9.pairs[i][0]} sfx="pop" vol={0.2} rate={0.96 + i * 0.03} outer={{ flex: 1 }} style={{ padding: "14px 26px", height: 150, boxSizing: "border-box", display: "flex", flexDirection: "column", justifyContent: "center" }}>
          <div style={{ fontSize: 22, fontWeight: 700, color: COLORS.red }}>QUESTION</div><div style={{ fontSize: 46, fontWeight: 600, lineHeight: 1.2 }}>{q}</div>
        </Card>
        <Rise at={B9.pairs[i][1]} cfg={SPR.pop}><ArrowR size={56} color={COLORS.red} /></Rise>
        <Card at={B9.pairs[i][1]} outer={{ flex: 1 }} style={{ padding: "14px 26px", height: 150, boxSizing: "border-box", display: "flex", flexDirection: "column", justifyContent: "center", background: COLORS.dark, color: COLORS.white }}>
          <div style={{ fontSize: 22, fontWeight: 700, color: COLORS.mute }}>PASSAGE</div><div style={{ fontSize: 46, fontWeight: 600, lineHeight: 1.2 }}>{p}</div>
        </Card>
      </div>
    ))}
    <div style={{ display: "flex", gap: 24, marginTop: 6 }}>
      <Rise at={B9.ex}><Chip bg="transparent" fg={COLORS.dark} border={COLORS.dark} size={38}><Cross size={34} color={COLORS.red} /> Exact Word Matching</Chip></Rise>
      <Rise at={B9.mm} cfg={SPR.pop} sfx="click" vol={0.25}><Chip bg={COLORS.red} fg={COLORS.white} size={38}><Check size={34} /> Meaning Matching</Chip></Rise>
    </div>
  </div>
);

// ═══════════ S10 — Scanning ═══════════
const B10 = (() => {
  const f = new Finder(128);
  const t = f.at("এবার আসি Scanning"); const d = f.at("Passage-এর মধ্যে নির্দিষ্ট"); const q = f.at("Population চাওয়া হয়েছে");
  const c = f.id("Population, People, Number, Around"); const chips = [0.2, 0.38, 0.56, 0.7, 0.84].map((x) => f.atId(c, x));
  const ctx = f.at("আশপাশের বাক্য পড়বে"); const no = f.at("উত্তর দিয়ে দেবে না"); const ok = f.at("অর্থের দিক");
  return { t, d, q, chips, ctx, no, ok };
})();
export const Scanning: React.FC = () => {
  const g = useG();
  const y = interpolate(g, [B10.chips[0], B10.chips[4] + 10], [0, 5], { easing: EASE.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const expand = clamp((g - B10.ctx) / 12);
  return (
    <div style={{ display: "flex", height: "100%", gap: 50, alignItems: "center" }}>
      <div style={{ width: 880, display: "flex", flexDirection: "column", gap: 26 }}>
        <Words text="Scanning" at={B10.t} size={110} />
        <Rise at={B10.d} style={{ fontSize: 40, fontWeight: 600, lineHeight: 1.3 }}>Passage-এর মধ্যে নির্দিষ্ট Information <b>দ্রুত</b> খুঁজে বের করার Technique</Rise>
        <Rise at={B10.q} sfx="pop" vol={0.22}>
          <div style={{ position: "relative", background: COLORS.dark, borderRadius: 28, padding: "34px 36px" }}>
            {Array.from({ length: 10 }).map((_, i) => (<div key={i} style={{ height: 26, marginBottom: 20, borderRadius: 13, width: i % 4 === 3 ? "64%" : "100%", background: COLORS.mute }} />))}
            <div style={{ position: "absolute", left: 20, right: 20, top: 24 + y * 46 * 1.0, height: 46 + expand * 92, borderRadius: 14, border: `6px solid ${COLORS.white}`, background: expand > 0.5 ? "transparent" : COLORS.red, opacity: g > B10.chips[0] - 4 ? 0.9 : 0, display: "flex", alignItems: "center", justifyContent: "flex-end", paddingRight: 18 }}>
              {g >= B10.ok ? <Check size={44} color={COLORS.white} /> : null}
            </div>
          </div>
        </Rise>
      </div>
      <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 20, alignItems: "flex-start" }}>
        <Rise at={B10.chips[0] - 6} style={{ fontSize: 40, fontWeight: 700, display: "flex", gap: 12, alignItems: "center" }}><Mag size={48} /> খুঁজবে:</Rise>
        {["Population", "People", "Number", "Around", "Approximately"].map((x, i) => (<Rise key={x} at={B10.chips[i]} s={0.8} cfg={SPR.pop}><Chip bg={COLORS.cream} fg={COLORS.dark} size={46}>{x}</Chip></Rise>))}
        <Rise at={B10.ctx} style={{ fontSize: 40, fontWeight: 600 }}>→ আশপাশের বাক্য পড়বে</Rise>
        <Rise at={B10.no}><Chip bg={COLORS.dark} fg={COLORS.white} size={38}><Cross size={32} color={COLORS.red} /> একটি শব্দ পেয়েই উত্তর নয়</Chip></Rise>
        <Rise at={B10.ok} cfg={SPR.pop} sfx="click" vol={0.25}><Chip bg={COLORS.cream} fg={COLORS.dark} size={38}><Check size={32} color={COLORS.red} /> অর্থ মিলছে কি না যাচাই</Chip></Rise>
      </div>
    </div>
  );
};

// ═══════════ S11 — Context ═══════════
const B11 = (() => {
  const f = new Finder(138);
  const t = f.at("Context বুঝে নেওয়া যাক"); const d = f.at("আশপাশের বক্তব্য"); const k = f.at("একটি Keyword খুঁজে পেয়েছ"); const unsure = f.at("নিশ্চিত নও");
  const prevNext = f.at("আগের এবং পরের বাক্য"); const main = f.at("মূল Information"); const expl = f.at("তার ব্যাখ্যা থাকে");
  const no = f.at("শুধু Keyword দেখে উত্তর দেবে না"); const yes = f.at("পুরো Context বুঝে উত্তর");
  return { t, d, k, unsure, prevNext, main, expl, no, yes };
})();
export const ContextScene: React.FC = () => {
  const bars = (w: number[]) => w.map((x, i) => <div key={i} style={{ height: 20, width: `${x}%`, borderRadius: 10, background: COLORS.mute, marginBottom: 12 }} />);
  return (
    <div style={{ display: "flex", height: "100%", gap: 60, alignItems: "center" }}>
      <div style={{ width: 700, display: "flex", flexDirection: "column", gap: 26 }}>
        <Words text="Context" at={B11.t} size={140} accent={["Context"]} />
        <Rise at={B11.d} style={{ fontSize: 48, fontWeight: 600, lineHeight: 1.3 }}>= কোনো শব্দ বা Information-এর <b style={{ color: COLORS.red }}>আশপাশের বক্তব্য</b></Rise>
        <Rise at={B11.no}><Chip bg="transparent" fg={COLORS.white} border={COLORS.mute} size={38}><Cross size={32} color={COLORS.red} /> শুধু Keyword দেখে নয়</Chip></Rise>
        <Rise at={B11.yes} cfg={SPR.pop} sfx="click" vol={0.25}><Chip bg={COLORS.red} fg={COLORS.white} size={38}><Check size={32} /> পুরো Context বুঝে উত্তর</Chip></Rise>
      </div>
      <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 22 }}>
        <Rise at={B11.prevNext}><CardBox style={{ padding: "22px 30px" }}><div style={{ fontSize: 30, fontWeight: 700, marginBottom: 12 }}>আগের বাক্য</div>{bars([100, 72])}</CardBox></Rise>
        <Rise at={B11.k} sfx="pop" vol={0.22}>
          <div style={{ background: COLORS.red, color: COLORS.white, borderRadius: 28, padding: "22px 30px" }}>
            <div style={{ fontSize: 30, fontWeight: 700, marginBottom: 12, display: "flex", gap: 14, alignItems: "center" }}>Keyword পাওয়া গেল
              <Rise at={B11.unsure} cfg={SPR.pop} s={0.4}><Chip bg={COLORS.white} fg={COLORS.red} size={28}>নিশ্চিত?</Chip></Rise>
              <Rise at={B11.main} s={0.8}><Chip bg={COLORS.dark} fg={COLORS.white} size={28}>মূল Information</Chip></Rise></div>
            {[100, 90, 60].map((x, i) => (<div key={i} style={{ height: 20, width: `${x}%`, borderRadius: 10, background: COLORS.white, marginBottom: 12 }} />))}
          </div>
        </Rise>
        <Rise at={B11.prevNext + 6}><CardBox style={{ padding: "22px 30px" }}><div style={{ fontSize: 30, fontWeight: 700, marginBottom: 12, display: "flex", gap: 14, alignItems: "center" }}>পরের বাক্য<Rise at={B11.expl} s={0.8}><Chip bg={COLORS.red} fg={COLORS.white} size={28}>ব্যাখ্যা</Chip></Rise></div>{bars([100, 80])}</CardBox></Rise>
      </div>
    </div>
  );
};

// ═══════════ S12 — Trap: শুধু King ═══════════
const B12 = (() => {
  const f = new Finder(148);
  const big = f.at("এটি বড় ভুল"); const q = f.at("The king's family."); const p = f.at("শুধু King শব্দটি");
  const got = f.at("King দেখে উত্তর দিয়ে দিলে"); const fam = f.at("King-এর Family কোথায় থাকত"); const fin = f.at("পুরো Information মিলতে হবে");
  return { big, q, p, got, fam, fin };
})();
export const Trap: React.FC = () => (
  <div style={{ ...COL, gap: 30 }}>
    <Rise at={B12.big} cfg={SPR.pop} sfx="thud" vol={0.22}><Chip bg={COLORS.red} fg={COLORS.white} size={52}><Cross size={46} /> বড় ভুল: একটি শব্দ দেখেই উত্তর</Chip></Rise>
    <div style={{ display: "flex", gap: 40, alignItems: "stretch" }}>
      <Card at={B12.q} sfx="pop" vol={0.22} outer={{ flex: 1 }} style={{ padding: "30px 38px", height: 330, boxSizing: "border-box" }}>
        <div style={{ fontSize: 28, fontWeight: 700, color: COLORS.red }}>QUESTION</div>
        <div style={{ fontSize: 80, fontWeight: 700, lineHeight: 1.2, marginTop: 14 }}>The <span style={{ background: COLORS.dark, color: COLORS.white, borderRadius: 8, padding: "0 6px" }}>king</span>'s <Rise at={B12.fam} style={{ display: "inline-block" }} dy={10} s={0.9}><span style={{ background: COLORS.red, color: COLORS.white, borderRadius: 8, padding: "0 6px" }}>family</span></Rise></div>
        <Rise at={B12.fam} style={{ fontSize: 38, fontWeight: 600, marginTop: 14 }}>King-এর Family কোথায় থাকত?</Rise>
      </Card>
      <Card at={B12.p} outer={{ flex: 1 }} style={{ padding: "30px 38px", height: 330, boxSizing: "border-box", background: COLORS.dark, color: COLORS.white }}>
        <div style={{ fontSize: 28, fontWeight: 700, color: COLORS.mute }}>PASSAGE</div>
        <div style={{ fontSize: 80, fontWeight: 700, lineHeight: 1.2, marginTop: 14 }}>… <span style={{ background: COLORS.white, color: COLORS.dark, borderRadius: 8, padding: "0 6px" }}>king</span> …</div>
        <Rise at={B12.got} style={{ fontSize: 38, fontWeight: 600, marginTop: 14, color: COLORS.mute }}>শুধু King শব্দ মিলেছে</Rise>
      </Card>
    </div>
    <div style={{ display: "flex", gap: 26 }}>
      <Rise at={B12.got}><Chip bg="transparent" fg={COLORS.dark} border={COLORS.dark} size={42}><Cross size={36} color={COLORS.red} /> এক শব্দ মিললেই উত্তর নয়</Chip></Rise>
      <Rise at={B12.fin} cfg={SPR.pop} sfx="click" vol={0.25}><Chip bg={COLORS.red} fg={COLORS.white} size={42}><Check size={36} /> পুরো Information মিলতে হবে</Chip></Rise>
    </div>
  </div>
);

// ═══════════ S13 — Question-এর ক্রম ≠ Paragraph-এর ক্রম ═══════════
const B13 = (() => {
  const f = new Finder(160);
  const t = f.at("ক্রমানুসারে আসে না"); const r = [f.at("Question 1-এর উত্তর Paragraph A-তে"), f.at("Question 2-এর উত্তর Paragraph B-তে"), f.at("Question 3-এর উত্তর আবার")];
  const no = f.at("ক্রম অনুমান করবে না"); const sep = f.at("আলাদাভাবে Analyse");
  return { t, r, no, sep };
})();
export const OrderScene: React.FC = () => (
  <div style={{ ...COL, gap: 26 }}>
    <Words text="Question-এর ক্রম = Paragraph-এর ক্রম?" at={B13.t} size={76} accent={["ক্রম?"]} />
    {[0, 1, 2].map((i) => (
      <Rise key={i} at={B13.r[i]} sfx="tick" vol={0.2} rate={0.95 + i * 0.05} style={{ display: "flex", alignItems: "center", gap: 30 }}>
        <Chip bg={COLORS.dark} fg={COLORS.white} size={56} style={{ width: 360, justifyContent: "center" }}>Question {i + 1}</Chip>
        <ArrowR size={70} color={COLORS.white} />
        <Rise at={B13.r[i] + 6} cfg={SPR.pop} s={0.5}>
          <div style={{ width: 130, height: 110, borderRadius: 26, background: i === 0 ? COLORS.cream : "transparent", border: `6px ${i === 0 ? "solid" : "dashed"} ${COLORS.cream}`, color: i === 0 ? COLORS.dark : COLORS.cream, fontSize: 76, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center" }}>{i === 0 ? "A" : "?"}</div>
        </Rise>
        <Rise at={B13.r[i] + 10} style={{ fontSize: 40, fontWeight: 600 }}>{["এখানে পাওয়া গেল", "B-তে পাওয়া যাবে — এমন নিশ্চয়তা নেই", "C-তে নাও থাকতে পারে"][i]}</Rise>
      </Rise>
    ))}
    <div style={{ display: "flex", gap: 24 }}>
      <Rise at={B13.no}><Chip bg={COLORS.dark} fg={COLORS.white} size={40}><Cross size={34} color={COLORS.red} /> নম্বর দেখে ক্রম অনুমান নয়</Chip></Rise>
      <Rise at={B13.sep} cfg={SPR.pop} sfx="click" vol={0.25}><Chip bg={COLORS.cream} fg={COLORS.dark} size={40}><Mag size={34} /> প্রতিটি Question আলাদাভাবে Analyse</Chip></Rise>
    </div>
  </div>
);

// ═══════════ S14 — একই Paragraph একাধিকবার ═══════════
const B14 = (() => {
  const f = new Finder(167);
  const t = f.at("নিষেধ না করে"); const same = f.at("একাধিকবার Answer"); const no = f.at("বাদ দিয়ে দেবে না"); const again = f.at("Information মিললে সেটিও"); const ins = f.at("Instructions সব সময় ভালোভাবে");
  return { t, same, no, again, ins };
})();
export const ReuseScene: React.FC = () => (
  <div style={{ display: "flex", height: "100%", gap: 50, alignItems: "center" }}>
    <div style={{ width: 700, display: "flex", flexDirection: "column", gap: 28 }}>
      <Words text="একই Paragraph একাধিকবার Answer হতে পারে" at={B14.t} size={56} accent={["একাধিকবার"]} />
      <Rise at={B14.ins}><Chip bg={COLORS.cream} fg={COLORS.dark} size={38}><Mag size={32} /> Instructions ভালোভাবে পড়ো</Chip></Rise>
    </div>
    <div style={{ flex: 1, display: "flex", alignItems: "center", gap: 30 }}>
      <div style={{ display: "flex", flexDirection: "column", gap: 40 }}>
        <Rise at={B14.same}><Chip bg={COLORS.cream} fg={COLORS.dark} size={52}>Question a</Chip></Rise>
        <Rise at={B14.again}><Chip bg={COLORS.cream} fg={COLORS.dark} size={52}>Question b</Chip></Rise>
      </div>
      <Rise at={B14.same + 8}><ArrowR size={80} color={COLORS.red} /></Rise>
      <Rise at={B14.same + 4} cfg={SPR.pop} sfx="pop" vol={0.25} breathe>
        <div style={{ width: 300, height: 300, borderRadius: 40, background: COLORS.red, color: COLORS.white, display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column" }}>
          <div style={{ fontSize: 40, fontWeight: 600 }}>Paragraph</div><div style={{ fontSize: 170, fontWeight: 700, lineHeight: 1 }}>C</div>
        </div>
      </Rise>
      <Rise at={B14.no} style={{ fontSize: 40, fontWeight: 600, display: "flex", flexDirection: "column", gap: 14 }}>
        <Chip bg="transparent" fg={COLORS.white} border={COLORS.mute} size={34}><Cross size={30} color={COLORS.red} /> একবার ব্যবহার করে বাদ নয়</Chip>
        <Rise at={B14.again}><Chip bg="transparent" fg={COLORS.white} border={COLORS.mute} size={34}><Check size={30} color={COLORS.red} /> মিললে আবার ব্যবহার করবে</Chip></Rise>
      </Rise>
    </div>
  </div>
);

// ═══════════ S15 — Practice Overview ═══════════
const B15 = (() => {
  const f = new Finder(175);
  const t = f.at("শুধু Theory নয়"); const nm = f.at("Passage-এর নাম Mapungubwe"); const book = f.at("Cambridge IELTS 21-এর Test 2"); const par = f.at("সাতটি Paragraph");
  const steps = [f.at("প্রাচীন Kingdom"), f.at("কৃষিকাজ এবং পশুপালন"), f.at("বিভিন্ন পণ্য উৎপাদন"), f.at("অতিরিক্ত খাদ্য ও অন্যান্য"), f.at("রাজা, রাজপরিবার"), f.at("দুর্বল হয়ে পড়ে")];
  return { t, nm, book, par, steps };
})();
const GIST = ["Southern Africa-এর প্রাচীন Kingdom", "কৃষিকাজ ও পশুপালন", "বিভিন্ন পণ্য উৎপাদন", "অতিরিক্ত উৎপাদন → বিনিময়", "রাজা · রাজপরিবার · সাধারণ মানুষ · বাণিজ্য", "পরে Kingdom দুর্বল হয়ে পড়ে"];
export const Overview: React.FC = () => (
  <div style={{ display: "flex", height: "100%", gap: 60, alignItems: "center" }}>
    <div style={{ width: 760, display: "flex", flexDirection: "column", gap: 24 }}>
      <Rise at={B15.t}><Chip bg={COLORS.red} fg={COLORS.white} size={40}>এবার সরাসরি Practice</Chip></Rise>
      <Words text="Mapungubwe" at={B15.nm} size={118} lh={1} />
      <Rise at={B15.book} style={{ fontSize: 42, fontWeight: 600 }}>Cambridge IELTS 21 · Test 2 · Reading Passage 2</Rise>
      <div style={{ display: "flex", gap: 12 }}>
        {LETTERS.map((L, i) => (<Rise key={L} at={B15.par + i * 4} s={0.7} cfg={SPR.pop}><div style={{ width: 96, height: 96, borderRadius: 22, background: COLORS.dark, color: COLORS.white, fontSize: 60, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center" }}>{L}</div></Rise>))}
      </div>
    </div>
    <div style={{ flex: 1, position: "relative", display: "flex", flexDirection: "column", gap: 18 }}>
      {GIST.map((t, i) => (
        <Rise key={i} at={B15.steps[i]} dx={50} dy={0} sfx={i === 0 ? "pop" : "tick"} vol={0.2} style={{ display: "flex", alignItems: "center", gap: 20 }}>
          <div style={{ width: 62, height: 62, borderRadius: 31, background: i === 5 ? COLORS.dark : COLORS.red, color: COLORS.white, fontSize: 36, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center", flex: "none" }}>{i + 1}</div>
          <CardBox style={{ flex: 1, padding: "14px 26px", fontSize: 38, fontWeight: 600 }}>{t}</CardBox>
        </Rise>
      ))}
    </div>
  </div>
);

// ═══════════ S17 — ৫ ধাপের পদ্ধতি ═══════════
const B17 = (() => {
  const f = new Finder(263);
  const t = f.at("একই পদ্ধতি অনুসরণ");
  const s = [f.at("প্রথমে Question পড়ব"), f.at("গুরুত্বপূর্ণ Keywords বের করব"), f.at("সম্ভাব্য Paraphrases চিন্তা"), f.at("Evidence খুঁজব"), f.at("Answer নির্বাচন করব")];
  return { t, s };
})();
const S5 = [["Question", "পড়ব"], ["Keywords", "বের করব"], ["Paraphrases", "চিন্তা করব"], ["Evidence", "Passage-এ খুঁজব"], ["Answer", "নির্বাচন করব"]];
export const Steps5: React.FC = () => (
  <div style={{ ...COL, gap: 40, justifyContent: "center" }}>
    <Words text="প্রতিটি Question — একই ৫ ধাপ" at={B17.t} size={88} accent={["৫"]} />
    <div style={{ display: "flex", gap: 22, alignItems: "stretch" }}>
      {S5.map(([a, b], i) => (
        <Card key={a} at={B17.s[i]} sfx="pop" vol={0.22} rate={0.95 + i * 0.04} outer={{ flex: 1 }} style={{ padding: "26px 22px", height: 440, boxSizing: "border-box", display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
          <div style={{ width: 84, height: 84, borderRadius: 42, background: COLORS.red, color: COLORS.white, fontSize: 52, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center" }}>{i + 1}</div>
          <div><div style={{ fontSize: 54, fontWeight: 700, lineHeight: 1.1 }}>{a}</div><div style={{ fontSize: 40, fontWeight: 600, marginTop: 8 }}>{b}</div></div>
        </Card>
      ))}
    </div>
  </div>
);

// ═══════════ S19 — ৬টি উত্তর একসাথে ═══════════
const B19 = (() => {
  const f = new Finder(528);
  const t = f.at("ছয়টি Question-এর উত্তর একসঙ্গে");
  const on = ["1: E.", "2: G.", "3: C.", "4: D.", "5: B.", "6: A."].map((x) => f.at("Question " + x));
  const bk = ["14: E.", "15: G.", "16: C.", "17: D.", "18: B.", "19: A."].map((x) => f.at("Question " + x));
  const no = f.at("অনুমান করে দেওয়া হয়নি"); const ev = f.at("নির্দিষ্ট Evidence");
  return { t, on, bk, no, ev };
})();
const ANS = ["E", "G", "C", "D", "B", "A"];
export const Answers: React.FC = () => (
  <div style={{ ...COL, gap: 20 }}>
    <Words text="৬টি উত্তর একসাথে" at={B19.t} size={78} />
    <div style={{ display: "flex", gap: 40, flex: 1 }}>
      {[{ h: "Online Website", base: 1, at: B19.on }, { h: "Cambridge IELTS 21 (মূল বই)", base: 14, at: B19.bk }].map((col) => (
        <div key={col.h} style={{ flex: 1, display: "flex", flexDirection: "column", gap: 10 }}>
          <Rise at={col.at[0] - 10} style={{ fontSize: 34, fontWeight: 700, color: COLORS.cream }}>{col.h}</Rise>
          {ANS.map((L, i) => (
            <Rise key={i} at={col.at[i]} dy={22} sfx="tick" vol={0.2} rate={0.95 + i * 0.03}>
              <CardBox style={{ padding: "6px 24px", display: "flex", alignItems: "center", justifyContent: "space-between", height: 94, boxSizing: "border-box" }}>
                <div style={{ fontSize: 48, fontWeight: 600 }}>Question {i + col.base}</div>
                <div style={{ width: 74, height: 74, borderRadius: 16, background: COLORS.red, color: COLORS.white, fontSize: 48, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center" }}>{L}</div>
              </CardBox>
            </Rise>
          ))}
        </div>
      ))}
    </div>
    <div style={{ display: "flex", gap: 20 }}>
      <Rise at={B19.no}><Chip bg={COLORS.dark} fg={COLORS.white} size={36}><Cross size={30} color={COLORS.red} /> অনুমান করে নয়</Chip></Rise>
      <Rise at={B19.ev} cfg={SPR.pop} sfx="chime" vol={0.25}><Chip bg={COLORS.cream} fg={COLORS.dark} size={36}><Check size={30} color={COLORS.red} /> প্রতিটি উত্তরে Passage-এর Evidence</Chip></Rise>
    </div>
  </div>
);

// ═══════════ S20 — ৮ ধাপের Strategy ═══════════
const B20 = (() => {
  const f = new Finder(544);
  const t = f.at("মনে করিয়ে দিই");
  const s = ["Step 1: Read the Questions.", "Step 2: Understand the Meaning.", "Step 3: Identify the Keywords.", "Step 4: Think of Synonyms.", "Step 5: Scan the Passage.", "Step 6: Read the Context.", "Step 7: Match the Meaning.", "Step 8: Select the Paragraph."].map((x) => f.at(x));
  const fin = f.at("আটটি ধাপ নিয়মিত");
  return { t, s, fin };
})();
const S8 = [["Read the Questions", "প্রথমে Questions পড়বে"], ["Understand the Meaning", "Question কী জানতে চাচ্ছে বুঝবে"], ["Identify the Keywords", "গুরুত্বপূর্ণ Keywords বের করবে"], ["Think of Synonyms", "Synonyms ও Paraphrases ভাববে"], ["Scan the Passage", "সম্ভাব্য Information খুঁজবে"], ["Read the Context", "আশপাশের বাক্য পড়বে"], ["Match the Meaning", "Question ও Passage-এর Information যাচাই"], ["Select the Paragraph", "সঠিক Paragraph Letter নির্বাচন"]];
export const Steps8: React.FC = () => (
  <div style={{ ...COL, gap: 22 }}>
    <div style={{ display: "flex", alignItems: "center", gap: 30 }}>
      <Words text="৮ ধাপের Strategy" at={B20.t} size={84} accent={["৮"]} />
      <Rise at={B20.fin} cfg={SPR.pop}><Chip bg={COLORS.red} fg={COLORS.white} size={36}>নিয়মিত Practice করবে</Chip></Rise>
    </div>
    <div style={{ display: "flex", flexWrap: "wrap", gap: 20 }}>
      {S8.map(([a, b], i) => (
        <Card key={a} at={B20.s[i]} sfx="pop" vol={0.2} rate={0.94 + i * 0.03} outer={{ width: 432 }} style={{ padding: "20px 24px", height: 340, boxSizing: "border-box", display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
          <div style={{ fontSize: 28, fontWeight: 700, color: COLORS.red }}>STEP {i + 1}</div>
          <div style={{ fontSize: 46, fontWeight: 700, lineHeight: 1.12 }}>{a}</div>
          <div style={{ fontSize: 30, fontWeight: 600, lineHeight: 1.25 }}>{b}</div>
        </Card>
      ))}
    </div>
  </div>
);

// ═══════════ S21 — সাধারণ ৬টি ভুল ═══════════
const B21 = (() => {
  const f = new Finder(565);
  const t = f.at("কিছু সাধারণ ভুল");
  const m = [1, 2, 3, 4, 5, 6].map((n) => f.at(`Mistake Number ${n}`));
  return { t, m };
})();
const MIS = [["Reading the Passage First", "আগে Questions বুঝে নাও, তারপর Passage Scan"], ["Looking for Exact Words", "শব্দ নয়, Meaning খুঁজবে"], ["Choosing an Answer Too Quickly", "পুরো Information মিলিয়ে দেখবে"], ["Confusing Headings with Information", "Headings = Main Idea · Information = নির্দিষ্ট Information"], ["Ignoring the Instructions", "Instructions ভালোভাবে পড়বে"], ["Not Checking the Context", "আশপাশের বাক্য পড়বে"]];
export const Mistakes: React.FC = () => (
  <div style={{ ...COL, gap: 22 }}>
    <Words text="৬টি সাধারণ ভুল" at={B21.t} size={84} accent={["৬টি"]} />
    <div style={{ display: "flex", flexWrap: "wrap", gap: 20 }}>
      {MIS.map(([a, b], i) => (
        <Card key={a} at={B21.m[i]} sfx="pop" vol={0.2} rate={0.94 + i * 0.03} outer={{ width: 880 }} style={{ padding: "18px 26px", height: 270, boxSizing: "border-box", display: "flex", gap: 24, alignItems: "center" }}>
          <div style={{ width: 84, height: 84, borderRadius: 42, background: COLORS.red, color: COLORS.white, display: "flex", alignItems: "center", justifyContent: "center", flex: "none" }}><Cross size={46} /></div>
          <div><div style={{ fontSize: 26, fontWeight: 700, color: COLORS.red }}>MISTAKE {i + 1}</div><div style={{ fontSize: 46, fontWeight: 700, lineHeight: 1.12 }}>{a}</div><div style={{ fontSize: 34, fontWeight: 600, marginTop: 6 }}>{b}</div></div>
        </Card>
      ))}
    </div>
  </div>
);

// ═══════════ S22 — Time Management ═══════════
const B22 = (() => {
  const f = new Finder(590);
  const t = f.at("Time Management"); const m = f.at("60 Minutes"); const c = f.id("তিনটি Passage"); const p = f.atId(c, 0.1); const q = f.atId(c, 0.6);
  const flow = [f.at("প্রথমে Questions বুঝবে"), f.at("Keywords চিহ্নিত"), f.at("Passage Scan করবে"), f.at("Evidence পেলে")];
  const stuck = f.at("অনেকক্ষণ আটকে থাকবে না"); const next = f.at("পরের Question-এ চলে যাবে"); const back = f.at("পরে আবার ফিরে আসবে");
  const sp = f.at("Speed is important"); const ac = f.at("Accuracy is more important");
  return { t, m, p, q, flow, stuck, next, back, sp, ac };
})();
const Stat: React.FC<{ at: number; to: number; unit: string; label: string }> = ({ at, to, unit, label }) => {
  const g = useG();
  const v = Math.round(interpolate(g, [at, at + 24], [0, to], { easing: EASE.out, extrapolateLeft: "clamp", extrapolateRight: "clamp" }));
  return (
    <Card at={at} sfx="pop" vol={0.22} outer={{ flex: 1 }} style={{ padding: "18px 26px", height: 300, boxSizing: "border-box" }}>
      <div style={{ fontSize: 30, fontWeight: 700, color: COLORS.cream }}>{label}</div>
      <div style={{ fontSize: 170, fontWeight: 700, lineHeight: 1.05 }}>{v}<span style={{ fontSize: 54, marginLeft: 10, color: COLORS.cream }}>{unit}</span></div>
    </Card>
  );
};
export const TimeScene: React.FC = () => (
  <div style={{ ...COL, gap: 22 }}>
    <Words text="Time Management" at={B22.t} size={84} />
    <div style={{ display: "flex", gap: 24 }}>
      <Stat at={B22.m} to={60} unit="Minutes" label="Academic Reading" />
      <Stat at={B22.p} to={3} unit="Passage" label="মোট" />
      <Stat at={B22.q} to={40} unit="Question" label="মোট" />
    </div>
    <div style={{ display: "flex", gap: 14, alignItems: "center", flexWrap: "wrap" }}>
      {["Questions বোঝো", "Keywords চিহ্নিত", "Passage Scan", "Evidence যাচাই"].map((x, i) => (
        <React.Fragment key={x}>
          <Rise at={B22.flow[i]} s={0.85} cfg={SPR.pop}><Chip bg={COLORS.cream} fg={COLORS.dark} size={44}>{i + 1}. {x}</Chip></Rise>
          {i < 3 ? <Rise at={B22.flow[i] + 4}><ArrowR size={40} color={COLORS.white} /></Rise> : null}
        </React.Fragment>
      ))}
    </div>
    <div style={{ display: "flex", gap: 14, alignItems: "center" }}>
      <Rise at={B22.stuck}><Chip bg="transparent" fg={COLORS.white} border={COLORS.white} size={42}><Cross size={36} /> একটিতে আটকে থাকবে না</Chip></Rise>
      <Rise at={B22.next}><ArrowR size={40} color={COLORS.white} /></Rise>
      <Rise at={B22.next} s={0.85}><Chip bg={COLORS.cream} fg={COLORS.dark} size={42}>পরের Question</Chip></Rise>
      <Rise at={B22.back} s={0.85}><Chip bg={COLORS.dark} fg={COLORS.white} size={42}>পরে ফিরে আসবে</Chip></Rise>
    </div>
    <div style={{ display: "flex", gap: 20, marginTop: 6 }}>
      <Rise at={B22.sp}><div style={{ fontSize: 62, fontWeight: 700, color: COLORS.cream }}>Speed is important.</div></Rise>
      <Rise at={B22.ac} cfg={SPR.pop} sfx="chime" vol={0.25}><div style={{ fontSize: 62, fontWeight: 700 }}>But <span style={{ background: COLORS.dark, color: COLORS.white, borderRadius: 10, padding: "0 12px" }}>Accuracy</span> is more important.</div></Rise>
    </div>
  </div>
);

// ═══════════ S23 — Recap ═══════════
const B23 = (() => {
  const f = new Finder(606);
  const t = f.at("Matching Information Question Type একদম");
  const it = [f.at("Matching Information কী"), f.at("Keywords বের করতে হয়"), f.at("Synonyms এবং Paraphrases"), f.at("Scanning করতে হয়"), f.at("Context বুঝতে হয়"), f.at("Evidence ব্যবহার করে")];
  const pr = f.at("Questions 14 থেকে 19");
  return { t, it, pr };
})();
const RECAP = ["Matching Information কী", "Keywords বের করা", "Synonyms ও Paraphrases", "Scanning", "Context বোঝা", "Evidence দিয়ে Paragraph নির্বাচন"];
export const Recap: React.FC = () => (
  <div style={{ display: "flex", height: "100%", gap: 60, alignItems: "center" }}>
    <div style={{ width: 640, display: "flex", flexDirection: "column", gap: 30 }}>
      <Words text="আজ যা শিখলে" at={B23.t} size={100} accent={["শিখলে"]} />
      <Rise at={B23.pr} cfg={SPR.pop} sfx="chime" vol={0.25}><CardBox style={{ padding: "24px 30px" }}><div style={{ fontSize: 28, fontWeight: 700, color: COLORS.red }}>PRACTICE</div><div style={{ fontSize: 40, fontWeight: 700, lineHeight: 1.2 }}>Cambridge IELTS 21 · Test 2 · Passage 2 — Questions 14–19</div></CardBox></Rise>
    </div>
    <div style={{ flex: 1, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
      {RECAP.map((x, i) => (
        <Rise key={x} at={B23.it[i]} sfx="tick" vol={0.2} rate={0.94 + i * 0.04}>
          <CardBox style={{ padding: "22px 24px", height: 190, boxSizing: "border-box", display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
            <div style={{ width: 56, height: 56, borderRadius: 28, background: COLORS.red, color: COLORS.white, display: "flex", alignItems: "center", justifyContent: "center" }}><Check size={34} /></div>
            <div style={{ fontSize: 38, fontWeight: 700, lineHeight: 1.15 }}>{x}</div>
          </CardBox>
        </Rise>
      ))}
    </div>
  </div>
);

// ═══════════ S24 — পরামর্শ ═══════════
const B24 = (() => {
  const f = new Finder(616);
  const t = f.at("একটি পরামর্শ থাকবে");
  const it = [f.at("মুখস্থ করবে না"), f.at("নিজে আবার Passage খুলে"), f.at("কেন একটি উত্তর সঠিক"), f.at("Answer খুঁজে বের করার Process"), f.at("নিজের ভুলগুলো Analyse"), f.at("প্রতিদিন একটু একটু")];
  return { t, it };
})();
const ADV: [string, string, boolean][] = [["উত্তর মুখস্থ নয়", "", false], ["নিজে আবার Passage খুলে প্রতিটি Question Solve করো", "", true], ["কেন উত্তরটি সঠিক — বোঝার চেষ্টা করো", "", true], ["Answer খুঁজে বের করার Process শেখো", "", true], ["নিজের ভুলগুলো Analyse করো", "", true], ["প্রতিদিন একটু একটু করে Reading Skill বাড়াও", "", true]];
export const Advice: React.FC = () => (
  <div style={{ display: "flex", height: "100%", gap: 60, alignItems: "center" }}>
    <div style={{ width: 600, display: "flex", flexDirection: "column", gap: 26 }}>
      <Words text="আমার পরামর্শ" at={B24.t} size={104} accent={["পরামর্শ"]} />
      <Rise at={B24.t + 14} style={{ fontSize: 44, fontWeight: 600, lineHeight: 1.3 }}>Practice with Evidence</Rise>
    </div>
    <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 14 }}>
      {ADV.map(([x, , ok], i) => (
        <Card key={i} at={B24.it[i]} sfx="pop" vol={0.2} rate={0.95 + i * 0.03} style={{ padding: "14px 26px", display: "flex", alignItems: "center", gap: 22, fontSize: 38, fontWeight: 600 }}>
          <div style={{ width: 60, height: 60, borderRadius: 30, background: ok ? COLORS.red : COLORS.dark, color: COLORS.white, display: "flex", alignItems: "center", justifyContent: "center", flex: "none" }}>{ok ? <Check size={34} /> : <Cross size={34} />}</div>{x}
        </Card>
      ))}
    </div>
  </div>
);

// ═══════════ S25 — Outro ═══════════
const B25 = (() => {
  const f = new Finder(625);
  const by = f.at("পাশে আছে IMAM IELTS"); const sh = f.at("Share করবে"); const st = f.at("যুক্ত থাকবে");
  const l = ["Don't Memorise the Answers.", "Understand the Strategy.", "Practise with Evidence.", "And Improve Your IELTS Reading Skills."].map((x) => f.at(x));
  const brand = f.at("This is IMAM IELTS"); const see = f.at("See you in the next lesson");
  return { by, sh, st, l, brand, see };
})();
export const Outro: React.FC = () => (
  <div style={{ display: "flex", height: "100%", gap: 60, alignItems: "center" }}>
    <div style={{ width: 1000, display: "flex", flexDirection: "column", gap: 22 }}>
      <div style={{ display: "flex", gap: 16 }}>
        <Rise at={B25.sh}><Chip bg={COLORS.dark} fg={COLORS.white} size={34}>Share করো</Chip></Rise>
        <Rise at={B25.st}><Chip bg={COLORS.cream} fg={COLORS.dark} size={34}>যুক্ত থাকো</Chip></Rise>
      </div>
      {["Don't Memorise the Answers.", "Understand the Strategy.", "Practise with Evidence.", "And Improve Your IELTS Reading Skills."].map((x, i) => (
        <Words key={x} text={x} at={B25.l[i]} size={i === 3 ? 56 : 70} stagger={3} color={i === 0 ? COLORS.cream : COLORS.white} accent={["Evidence.", "Strategy."]} accentColor={COLORS.dark} />
      ))}
    </div>
    <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 28 }}>
      <Rise at={B25.brand} cfg={SPR.pop} s={0.6} sfx="chime" vol={0.3} breathe>
        <div style={{ background: COLORS.dark, borderRadius: 40, padding: "46px 50px", display: "flex", alignItems: "center", gap: 28 }}>
          <div style={{ width: 130, height: 130, borderRadius: 32, background: COLORS.red, color: COLORS.white, fontSize: 70, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center" }}>IM</div>
          <div style={{ fontSize: 80, fontWeight: 700, color: COLORS.white, lineHeight: 1, whiteSpace: "nowrap" }}>IMAM IELTS</div>
        </div>
      </Rise>
      <Rise at={B25.see} style={{ fontSize: 50, fontWeight: 600 }}>See you in the next lesson.</Rise>
    </div>
  </div>
);
void CardBox;
