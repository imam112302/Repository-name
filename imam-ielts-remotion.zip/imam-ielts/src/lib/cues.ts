import { CUES } from "../data/cues";
import { FPS, LEAD } from "../theme";

const norm = (s: string) => s.normalize("NFC").replace(/\s+/g, " ").toLowerCase();
const NORM = CUES.map((c) => norm(c.t));

/** cue-র শুরু (ফ্রেমে)। frac = cue-র ভেতরে কতটা অংশ পরে (০..১) */
export const cueFrame = (id: number, frac = 0) => {
  const c = CUES[id - 1];
  return Math.round((c.s + frac * (c.e - c.s)) * FPS);
};
export const LAST_END = CUES[CUES.length - 1].e;
export const TOTAL = Math.ceil(LAST_END * FPS) + 15;

/** স্ক্রিপ্টের লেখা খুঁজে cue বের করে; কার্সর শুধু সামনে এগোয় (ক্রম ঠিক থাকে) */
export class Finder {
  cur: number;
  constructor(from: number) { this.cur = from; }
  id(sub: string): number {
    const q = norm(sub);
    for (let i = this.cur - 1; i < NORM.length; i++) if (NORM[i].includes(q)) { this.cur = i + 1; return i + 1; }
    throw new Error(`SRT-তে পাওয়া যায়নি (cue ${this.cur}-এর পর): "${sub}"`);
  }
  /** গ্লোবাল ফ্রেম, ভিজ্যুয়াল LEAD ফ্রেম আগে */
  at(sub: string, frac = 0): number { return cueFrame(this.id(sub), frac) - LEAD; }
  /** একই cue আবার খুঁজবে না, শুধু frac বদলে */
  atId(id: number, frac = 0): number { return cueFrame(id, frac) - LEAD; }
  skip(to: number) { this.cur = to; }
}
export const startOf = (id: number) => cueFrame(id);
