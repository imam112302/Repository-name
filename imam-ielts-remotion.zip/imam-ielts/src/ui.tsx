import React, { createContext, useContext, useEffect, useState } from "react";
import {
  Audio, Sequence, continueRender, delayRender, getRemotionEnvironment, interpolate, spring,
  staticFile, useCurrentFrame, useVideoConfig,
} from "remotion";
import { BgName, COLORS, EASE, FONT, SCHEMES, SFX_FRAMES, SPR, Scheme, SfxName } from "./theme";
import { TOTAL } from "./lib/cues";

// ───────────── Scene context: from = এই সিনের শুরুর গ্লোবাল ফ্রেম ─────────────
type Ctx = { from: number; bg: BgName };
export const SceneCtx = createContext<Ctx>({ from: 0, bg: "dark" });
export const useS = (): { S: Scheme; from: number; bg: BgName } => {
  const { from, bg } = useContext(SceneCtx);
  return { S: SCHEMES[bg], from, bg };
};
export const useG = () => { const f = useCurrentFrame(); const { from } = useContext(SceneCtx); return f + from; };
export const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));

// ───────────── SFX ─────────────
export const Sfx: React.FC<{ at: number; name: SfxName; vol?: number; rate?: number }> = ({ at, name, vol = 0.28, rate = 1 }) => {
  const { from } = useContext(SceneCtx);
  return (
    <Sequence from={Math.max(0, Math.round(at - from))} durationInFrames={SFX_FRAMES[name]} layout="none">
      <Audio src={staticFile(`sfx/${name}.wav`)} volume={vol} playbackRate={rate} />
    </Sequence>
  );
};

// ───────────── Rise: opacity + translate + scale একসাথে (spring) ─────────────
export const Rise: React.FC<{
  at: number; dy?: number; dx?: number; s?: number; cfg?: typeof SPR.snap; sfx?: SfxName; vol?: number; rate?: number;
  breathe?: boolean; style?: React.CSSProperties; children?: React.ReactNode;
}> = ({ at, dy = 34, dx = 0, s = 0.94, cfg = SPR.snap, sfx, vol, rate, breathe, style, children }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const { from } = useContext(SceneCtx);
  const lf = at - from;
  const p = spring({ frame: Math.max(0, frame - lf), fps, config: cfg });
  const op = frame < lf ? 0 : clamp(p * 1.8);
  const br = breathe && frame > lf + 24 ? 1 + 0.012 * Math.sin((frame / fps) * 2.2) : 1;
  return (
    <div style={{ opacity: op, transform: `translate(${dx * (1 - p)}px, ${dy * (1 - p)}px) scale(${(s + (1 - s) * p) * br})`, ...style }}>
      {sfx ? <Sfx at={at} name={sfx} vol={vol} rate={rate} /> : null}
      {children}
    </div>
  );
};

// ───────────── শব্দ ধরে স্ট্যাগার্ড (বাংলায় কখনো অক্ষর ধরে নয়) ─────────────
export const Words: React.FC<{
  text: string; at: number; size: number; stagger?: number; color?: string; accent?: string[]; accentColor?: string;
  weight?: number; lh?: number; center?: boolean; style?: React.CSSProperties;
}> = ({ text, at, size, stagger = 4, color, accent = [], accentColor, weight = 700, lh = 1.2, center, style }) => {
  const { S } = useS();
  const clean = (w: string) => w.replace(/[.,?!:;"“”’']/g, "").toLowerCase();
  return (
    <div style={{ display: "flex", flexWrap: "wrap", columnGap: Math.round(size * 0.28), rowGap: Math.round(size * 0.08), justifyContent: center ? "center" : "flex-start", fontSize: size, fontWeight: weight, lineHeight: lh, letterSpacing: 0, color: color ?? S.fg, ...style }}>
      {text.split(" ").map((w, i) => (
        <Rise key={i} at={at + i * stagger} dy={size * 0.5} s={0.9} style={{ display: "inline-block", color: accent.map(clean).includes(clean(w)) ? accentColor ?? S.accent : undefined }}>{w}</Rise>
      ))}
    </div>
  );
};

// ───────────── হাইলাইট সুইপ (flat রঙ; বাঁ→ডানে) ─────────────
export type HlKind = "ev" | "strong" | "bad" | "kw";
export const hlColors = (kind: HlKind, S: Scheme): { bg: string; fg: string } => {
  if (kind === "strong" || kind === "bad") return { bg: COLORS.dark, fg: COLORS.white };
  return { bg: COLORS.red, fg: COLORS.white };
};
export const Hl: React.FC<{ at: number | null; kind?: HlKind; dur?: number; colors?: { bg: string; fg: string }; children?: React.ReactNode }> = ({ at, kind = "ev", dur = 14, colors, children }) => {
  const { S } = useS();
  const g = useG();
  const p = at == null ? 0 : EASE.out(clamp((g - at) / dur));
  const c = colors ?? hlColors(kind, S);
  return (
    <span
      style={{
        backgroundImage: `linear-gradient(${c.bg}, ${c.bg})`, backgroundRepeat: "no-repeat", backgroundSize: `${p * 100}% 100%`,
        color: p > 0.45 ? c.fg : "inherit", borderRadius: 6, boxDecorationBreak: "clone", WebkitBoxDecorationBreak: "clone",
        boxShadow: p >= 1 ? `0 0 0 3px ${c.bg}` : "none",
        textDecoration: kind === "bad" && p > 0.6 ? "line-through" : "none", textDecorationColor: COLORS.red, textDecorationThickness: 4,
      }}
    >
      {children}
    </span>
  );
};

// ───────────── আইকন (SVG, থিমের রঙে — emoji নয়) ─────────────
export const Check: React.FC<{ size?: number; color?: string }> = ({ size = 40, color = "currentColor" }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={3.2} strokeLinecap="round" strokeLinejoin="round"><path d="M4 12.5l5 5L20 6.5" /></svg>
);
export const Cross: React.FC<{ size?: number; color?: string }> = ({ size = 40, color = "currentColor" }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={3.2} strokeLinecap="round"><path d="M5 5l14 14M19 5L5 19" /></svg>
);
export const ArrowR: React.FC<{ size?: number; color?: string }> = ({ size = 40, color = "currentColor" }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={3} strokeLinecap="round" strokeLinejoin="round"><path d="M4 12h15M13 6l6 6-6 6" /></svg>
);
export const Mag: React.FC<{ size?: number; color?: string }> = ({ size = 40, color = "currentColor" }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2.8} strokeLinecap="round"><circle cx="10.5" cy="10.5" r="6.5" /><path d="M15.5 15.5L21 21" /></svg>
);

// ───────────── ছোট বিল্ডিং ব্লক ─────────────
export const Chip: React.FC<{ bg: string; fg: string; size?: number; border?: string; style?: React.CSSProperties; children?: React.ReactNode }> = ({ bg, fg, size = 32, border, style, children }) => (
  <div style={{ display: "inline-flex", alignItems: "center", gap: 10, padding: `${Math.round(size * 0.2)}px ${Math.round(size * 0.5)}px`, borderRadius: size, background: bg, color: fg, fontSize: size, fontWeight: 700, lineHeight: 1.15, letterSpacing: 0, border: border ? `3px solid ${border}` : "3px solid transparent", whiteSpace: "nowrap", ...style }}>{children}</div>
);

export const CardBox: React.FC<{ style?: React.CSSProperties; children?: React.ReactNode }> = ({ style, children }) => {
  const { S, bg } = useS();
  return (
    <div style={{ background: S.card, color: S.cardFg, borderRadius: 28, padding: 32, border: bg === "cream" ? `3px solid ${COLORS.dark}` : "3px solid transparent", boxSizing: "border-box", letterSpacing: 0, ...style }}>{children}</div>
  );
};
export const Card: React.FC<{ at: number; sfx?: SfxName; style?: React.CSSProperties; outer?: React.CSSProperties; children?: React.ReactNode }> = ({ at, sfx, style, outer, children }) => (
  <Rise at={at} sfx={sfx} style={outer}><CardBox style={style}>{children}</CardBox></Rise>
);

// ───────────── ব্র্যান্ড + ট্যাগ + প্রগ্রেস + ট্রানজিশন ─────────────
export const Brand: React.FC = () => {
  const { S } = useS();
  return (
    <div style={{ position: "absolute", left: 60, top: 28, display: "flex", alignItems: "center", gap: 16, zIndex: 5 }}>
      <div style={{ width: 54, height: 54, borderRadius: 14, background: S.accent, color: S.accentFg, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: 26, letterSpacing: 0 }}>IM</div>
      <div style={{ fontSize: 38, fontWeight: 700, color: S.fg, letterSpacing: 0 }}>IMAM IELTS</div>
    </div>
  );
};

export const Shell: React.FC<{ tag?: string; first?: boolean; children?: React.ReactNode }> = ({ tag, first, children }) => {
  const { S, from } = useS();
  const frame = useCurrentFrame();
  const p = first ? 1 : interpolate(frame, [0, 12], [0, 1], { easing: EASE.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const prog = clamp((frame + from) / TOTAL);
  return (
    <div style={{ position: "absolute", inset: 0, background: S.bg, color: S.fg, fontFamily: FONT, letterSpacing: 0, overflow: "hidden", transform: `translateX(${(1 - p) * 100}%)` }}>
      {!first ? <Sfx at={from} name="whoosh" vol={0.22} /> : null}
      <Brand />
      {tag ? (
        <div style={{ position: "absolute", right: 60, top: 34, border: `3px solid ${S.line}`, color: S.fg, borderRadius: 40, padding: "6px 24px", fontSize: 28, fontWeight: 600 }}>{tag}</div>
      ) : null}
      <div style={{ position: "absolute", left: 60, right: 60, top: 118, bottom: 44 }}>{children}</div>
      <div style={{ position: "absolute", left: 0, bottom: 0, height: 8, width: `${prog * 100}%`, background: S.accent }} />
    </div>
  );
};

// ───────────── ফন্ট লোড না হওয়া পর্যন্ত রেন্ডার থামায় ─────────────
export const FontGate: React.FC<{ children?: React.ReactNode }> = ({ children }) => {
  const [ready, setReady] = useState(typeof document === "undefined");
  const [handle] = useState(() => delayRender("fonts"));
  useEffect(() => {
    const jobs: Promise<unknown>[] = [];
    for (const w of [400, 600, 700]) {
      jobs.push(document.fonts.load(`${w} 32px "Hind Siliguri"`, "আবকখ"));
      jobs.push(document.fonts.load(`${w} 32px "Hind Siliguri"`, "Abc 123"));
    }
    Promise.all(jobs).catch(() => undefined).then(() => { setReady(true); continueRender(handle); });
  }, [handle]);
  return ready ? <>{children}</> : null;
};

// ───────────── ভয়েসওভার প্রিভিউ (ফ্ল্যাগ; রেন্ডারে ডিফল্টে বন্ধ) ─────────────
export const VOICEOVER_PREVIEW = true; // false করলে Studio-তেও বাজবে না
export const PreviewAudio: React.FC = () => {
  const [ok, setOk] = useState(false);
  useEffect(() => {
    if (!VOICEOVER_PREVIEW || getRemotionEnvironment().isRendering) return;
    let dead = false;
    fetch(staticFile("voiceover.mp3"), { method: "HEAD" })
      .then((r) => { if (!dead && r.ok && (r.headers.get("content-type") || "").includes("audio")) setOk(true); })
      .catch(() => undefined);
    return () => { dead = true; };
  }, []);
  return ok ? <Audio src={staticFile("voiceover.mp3")} /> : null;
};
