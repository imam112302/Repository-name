// ফন্ট প্রজেক্টের ভেতরেই (npm install-এর পর অফলাইনে চলে) — Hind Siliguri: বাংলা যুক্তাক্ষর ঠিক আসে
import "@fontsource/hind-siliguri/bengali-400.css";
import "@fontsource/hind-siliguri/bengali-600.css";
import "@fontsource/hind-siliguri/bengali-700.css";
import "@fontsource/hind-siliguri/latin-400.css";
import "@fontsource/hind-siliguri/latin-600.css";
import "@fontsource/hind-siliguri/latin-700.css";
