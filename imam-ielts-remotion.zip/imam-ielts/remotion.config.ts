import { Config } from "@remotion/cli/config";

// রঙ ঠিক রাখার সেটিংস (VN-এ freeze করলে রঙ বদলানোর সমস্যা কমাতে):
// ১) PNG ফ্রেম  -> JPEG-এর কম্প্রেশনে ফ্ল্যাট রঙ নড়ে না
// ২) bt709 ট্যাগ -> HD ভিডিওতে সঠিক কালার ম্যাট্রিক্স স্পষ্ট করে লেখা থাকে
// ৩) yuv420p + h264 -> সব প্লেয়ার/এডিটরে খোলে
Config.setVideoImageFormat("png");
Config.setPixelFormat("yuv420p");
Config.setColorSpace("bt709");
Config.setCodec("h264");
Config.setCrf(14);
Config.setOverwriteOutput(true);
