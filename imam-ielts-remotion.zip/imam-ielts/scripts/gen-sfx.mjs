// কোডে সিন্থেসাইজ করা ছোট UI-ধাঁচের SFX (মিউজিক/ভয়েস নয়) -> public/sfx/*.wav
import fs from "node:fs";
const SR = 48000;
let seed = 12345; const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296) * 2 - 1;
const N = (d) => Math.floor(d * SR);
const lp = (x, fc) => { const a = 1 - Math.exp((-2 * Math.PI * fc) / SR); let y = 0; return x.map((v) => (y += a * (v - y))); };
const hp = (x, fc) => { const l = lp(x, fc); return x.map((v, i) => v - l[i]); };
function bpSweep(x, f0, f1, q) { // time-varying biquad band-pass
  const out = new Float32Array(x.length); let x1 = 0, x2 = 0, y1 = 0, y2 = 0;
  for (let i = 0; i < x.length; i++) {
    const f = f0 * Math.pow(f1 / f0, i / x.length), w = (2 * Math.PI * f) / SR, al = Math.sin(w) / (2 * q), c = Math.cos(w);
    const b0 = al, b2 = -al, a0 = 1 + al, a1 = -2 * c, a2 = 1 - al;
    const y = (b0 * x[i] + b2 * x2 - a1 * y1 - a2 * y2) / a0; x2 = x1; x1 = x[i]; y2 = y1; y1 = y; out[i] = y;
  } return out;
}
function reverb(x, mix = 0.1) { // খুব ছোট রুম
  const taps = [[0.023, 0.32], [0.031, 0.26], [0.043, 0.2]]; const y = new Float32Array(x.length + N(0.12)); y.set(x);
  for (const [d, g] of taps) for (let i = 0; i < x.length; i++) y[i + N(d)] += x[i] * g * mix * 3; return y;
}
const env = (i, a, d) => { const t = i / SR; return Math.min(1, t / a) * Math.exp(-t * d); };
function peak(x) { let p = 0; for (const v of x) p = Math.max(p, Math.abs(v)); return p; }
function save(name, x, target = 0.8) {
  const p = peak(x); const g = target / (p || 1); const buf = Buffer.alloc(44 + x.length * 2);
  buf.write("RIFF", 0); buf.writeUInt32LE(36 + x.length * 2, 4); buf.write("WAVEfmt ", 8); buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(SR, 24); buf.writeUInt32LE(SR * 2, 28); buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34); buf.write("data", 36); buf.writeUInt32LE(x.length * 2, 40);
  x.forEach((v, i) => buf.writeInt16LE(Math.round(Math.max(-1, Math.min(1, v * g)) * 32767), 44 + i * 2));
  fs.writeFileSync(new URL(`../public/sfx/${name}.wav`, import.meta.url), buf);
}
// pop: দ্রুত নিচে নামা pitch সহ sine
{ const n = N(0.2), x = new Float32Array(n); let ph = 0; for (let i = 0; i < n; i++) { const t = i / SR; ph += (2 * Math.PI * (150 + 330 * Math.exp(-t * 32))) / SR; x[i] = Math.sin(ph) * env(i, 0.004, 20); } save("pop", reverb(lp(x, 5000), 0.05)); }
// click: high-pass noise burst
{ const n = N(0.09), x = new Float32Array(n); for (let i = 0; i < n; i++) x[i] = rnd() * env(i, 0.001, 70); const y = lp(hp(x, 1800), 7000); save("click", Float32Array.from(y)); }
// tick: খুব ছোট, নরম
{ const n = N(0.07), x = new Float32Array(n); for (let i = 0; i < n; i++) x[i] = (Math.sin((2 * Math.PI * 1500 * i) / SR) * 0.8 + rnd() * 0.2) * env(i, 0.001, 85); save("tick", Float32Array.from(lp(x, 6000))); }
// whoosh: band-pass noise sweep + fade in/out
{ const n = N(0.6), x = new Float32Array(n); for (let i = 0; i < n; i++) x[i] = rnd(); const b = bpSweep(x, 350, 3200, 1.1); for (let i = 0; i < n; i++) b[i] *= Math.pow(Math.sin((Math.PI * i) / n), 2); save("whoosh", reverb(lp(Array.from(b), 6000), 0.06)); }
// chime/pluck: নরম ওভারটোন
{ const n = N(0.36), x = new Float32Array(n); const P = [[880, 1], [1320, 0.35], [1760, 0.18], [2640, 0.07]]; for (let i = 0; i < n; i++) { let s = 0; for (const [f, a] of P) s += Math.sin((2 * Math.PI * f * i) / SR) * a * Math.exp((-(i / SR) * (6 + f / 500))); x[i] = s * Math.min(1, i / SR / 0.004); } save("chime", reverb(lp(x, 6500), 0.08)); }
// thud: হুক/মূল বার্তার জন্য সংযত সফট থাড
{ const n = N(0.35), x = new Float32Array(n); let ph = 0; for (let i = 0; i < n; i++) { const t = i / SR; ph += (2 * Math.PI * (48 + 55 * Math.exp(-t * 22))) / SR; x[i] = Math.sin(ph) * env(i, 0.006, 11); } save("thud", Float32Array.from(lp(Array.from(x), 400)), 0.8); }
// verify
for (const f of fs.readdirSync(new URL("../public/sfx/", import.meta.url))) {
  const b = fs.readFileSync(new URL(`../public/sfx/${f}`, import.meta.url)); const n = (b.length - 44) / 2; let p = 0, clip = 0, ss = 0;
  for (let i = 0; i < n; i++) { const v = Math.abs(b.readInt16LE(44 + i * 2)) / 32767; p = Math.max(p, v); if (v >= 0.999) clip++; ss += v * v; }
  console.log(f.padEnd(11), "dur", (n / SR).toFixed(2) + "s", "peak", p.toFixed(2), "rms", Math.sqrt(ss / n).toFixed(3), clip ? "CLIPPING" : "ok");
}
