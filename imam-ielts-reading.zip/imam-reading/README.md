# IMAM IELTS – Reading Question Types (Remotion)

    npm install
    npx remotion studio src/index.ts
    npx remotion render src/index.ts Main out/video.mp4

- Composition ID: `Main` (1920x1080, 30fps, 38262 frames = 21:15)
- `public/voiceover.mp3` = আপনার অডিও (reading_sunday.m4a থেকে)। বন্ধ করতে `src/PreviewAudio.tsx`-এ `VOICEOVER_ENABLED = false`
- `public/sfx/*.wav` = ৬টি সিন্থেসাইজ করা SFX (`node scripts/make-sfx.mjs` দিয়ে আবার বানানো যায়)
- সময় সব `src/cues.ts` (SRT থেকে) থেকে আসে; দৃশ্যের কনটেন্ট `src/content.ts`-এ
- রং/ফন্ট/ইজিং `src/theme.ts`-এ
