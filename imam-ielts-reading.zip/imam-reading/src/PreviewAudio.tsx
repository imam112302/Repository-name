import React, {useEffect, useState} from 'react';
import {Audio, cancelRender, continueRender, delayRender, staticFile} from 'remotion';

// ভয়েসওভার ফ্ল্যাগ: false করলে ভিডিওতে ভয়েসওভার থাকবে না।
// public/voiceover.mp3 না থাকলে নীরবে বাদ যায়।
export const VOICEOVER_ENABLED = true;

export const PreviewAudio: React.FC = () => {
  const [has, setHas] = useState(false);
  const [handle] = useState(() => delayRender('voiceover check'));
  useEffect(() => {
    fetch(staticFile('voiceover.mp3'), {method: 'HEAD'})
      .then((r) => setHas(r.ok))
      .catch(() => setHas(false))
      .finally(() => continueRender(handle));
  }, [handle]);
  if (!VOICEOVER_ENABLED || !has) return null;
  return <Audio src={staticFile('voiceover.mp3')} volume={1} />;
};
void cancelRender;
