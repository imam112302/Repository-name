import {ToneName} from './theme';
import {TRef} from './timing';
import {CardDef, HeroLine, MItem, TileDef} from './components/templates';
import {Bullet, LRow, RRow, VisualKind} from './components/typeScenes';

export type SceneDef = {a: number; tone: ToneName; typeIdx?: number} & (
  | {kind: 'hero'; lines: HeroLine[]}
  | {kind: 'cards'; label?: {at: TRef; text: string}; headline?: {at: TRef; text: string}[]; headSize?: number; cards: CardDef[]; cols: number; cardSize?: number}
  | {kind: 'grid'; title?: {at: TRef; text: string}[]; titleSize?: number; tiles: TileDef[]; cols: number; mode: 'num' | 'check'; tileH?: number; fs?: number}
  | {kind: 'hub'}
  | {kind: 'mistake'; n: number; title: string; sub: string; wrong: MItem[]; right: MItem[]; variant: 'row' | 'flip' | 'stack'}
  | {kind: 'cta'}
  | {kind: 'rule'; num: number; en: string; bn: string; visual: VisualKind; labels?: string[]; bullets: Bullet[]}
  | {kind: 'stage'; en: string; left: LRow[]; right: RRow[]}
);

export const TYPES = [
  'Multiple Choice', 'True / False / Not Given', 'Yes / No / Not Given', 'Matching Headings', 'Matching Information',
  'Matching Features', 'Matching Sentence Endings', 'Sentence Completion', 'Summary Completion', 'Note Completion',
  'Table Completion', 'Flow Chart Completion', 'Diagram Label Completion', 'Short Answer',
];
const SHORT = ['MCQ', 'True/False/NG', 'Yes/No/NG', 'Headings', 'Information', 'Features', 'Sentence Endings', 'Sentence', 'Summary', 'Note', 'Table', 'Flow Chart', 'Diagram', 'Short Answer'];

const tip = (a: number, typeIdx: number, headline: {at: TRef; text: string}[], cards: CardDef[], cols: number, headSize = 84): SceneDef => ({
  kind: 'cards', a, tone: 'red', typeIdx, label: {at: a, text: 'মনে রাখবেন'}, headline, cards, cols, headSize,
});
const rule = (a: number, typeIdx: number, bn: string, visual: VisualKind, bullets: Bullet[], labels?: string[]): SceneDef => ({
  kind: 'rule', a, tone: 'dark', typeIdx, num: typeIdx + 1, en: TYPES[typeIdx], bn, visual, bullets, labels,
});
const stage = (a: number, typeIdx: number, left: LRow[], right: RRow[]): SceneDef => ({kind: 'stage', a, tone: 'cream', typeIdx, en: TYPES[typeIdx], left, right});

export const SCENES: SceneDef[] = [
  // ===================== INTRO =====================
  {kind: 'hero', a: 1, tone: 'dark', lines: [
    {at: 1, text: 'Welcome to', size: 70, weight: 500, muted: true},
    {at: [1, 0.5], text: '[[IMAM]] IELTS', size: 190, sfx: 'thud'},
  ]},
  {kind: 'hero', a: 2, tone: 'red', lines: [
    {at: 2, text: 'IELTS Reading-এ ভালো Band Score', size: 56, weight: 500, muted: true},
    {at: [2, 1.2], text: 'শুধু ইংরেজি জানলেই [[হবে না]]', size: 112, sfx: 'thud'},
    {at: 3, text: 'জানতে হবে কীভাবে Question Type সমাধান করবেন', size: 66, weight: 600},
  ]},
  {kind: 'cards', a: 4, tone: 'cream', label: {at: 4, text: 'সমস্যা'}, headline: [{at: 4, text: 'অনেক শিক্ষার্থীর এই দুটো সমস্যা'}], headSize: 70, cols: 1, cardSize: 44, cards: [
    {at: 4, text: 'Passage পড়েন, কিন্তু সঠিক উত্তর খুঁজে পান না', mark: 'cross'},
    {at: 5, text: 'সঠিক উত্তর খুঁজে পেয়েও ভুল করে বসেন', mark: 'cross'},
    {at: 6, text: 'প্রধান কারণ: সঠিক Strategy না জানা', tag: 'মূল কারণ', mark: 'check'},
  ]},
  {kind: 'hub', a: 7, tone: 'dark'},
  {kind: 'cards', a: 9, tone: 'cream', label: {at: 9, text: 'আজকের ভিডিও'}, headline: [{at: 9, text: 'IELTS Academic Reading-এর'}, {at: [9, 1.2], text: 'সব ধরনের [[Question Type]]'}], headSize: 84, cols: 2, cardSize: 48, cards: [
    {at: 10, text: 'প্রতিটির জন্য সহজ ব্যাখ্যা', tag: 'ব্যাখ্যা', mark: 'check'},
    {at: [10, 1.6], text: 'প্রতিটির সাথে বাস্তব উদাহরণ', tag: 'Example', mark: 'check'},
  ]},
  {kind: 'cards', a: 11, tone: 'red', label: {at: 11, text: 'আপনি শিখবেন'}, headline: [{at: 11, text: 'এই ভিডিওতে দেখাব কীভাবে'}], headSize: 80, cols: 3, cardSize: 44, cards: [
    {at: [11, 1.0], text: 'প্রশ্ন বুঝবেন', mark: 'num'},
    {at: [11, 3.6], text: 'Passage থেকে উত্তর খুঁজবেন', mark: 'num'},
    {at: [11, 6.4], text: 'Common Mistakes এড়িয়ে চলবেন', mark: 'num'},
  ]},
  {kind: 'grid', a: 12, tone: 'cream', mode: 'num', cols: 5, tileH: 112, fs: 28, titleSize: 72,
    title: [{at: 12, text: 'তাই শেষ পর্যন্ত [[দেখুন]]'}, {at: 13, text: 'এক ভিডিওতেই সব Question Type'}],
    tiles: TYPES.map((t, i) => ({at: [13, 0.1 + i * 0.18] as TRef, text: t}))},

  // ===================== 01 MCQ =====================
  rule(15, 0, 'অপশন থেকে সঠিক উত্তর বাছাই', 'options', [
    {at: 16, text: 'কয়েকটি Option দেওয়া হবে'},
    {at: 18, text: 'কখনো একটি সঠিক উত্তর'},
    {at: 19, text: 'কখনো একাধিক সঠিক উত্তর'},
    {at: 20, text: 'প্রথমে প্রশ্নটি ভালোভাবে পড়ুন'},
    {at: 21, text: 'গুরুত্বপূর্ণ Keywords চিহ্নিত করুন'},
    {at: 22, text: 'Passage-এ Synonyms খুঁজুন'},
  ]),
  stage(23, 0, [
    {k: 'lbl', at: 24, text: 'QUESTION'},
    {k: 'p', at: 25, text: 'Why did the scientist begin [[studying climate change]]?', hl: [32]},
    {k: 'opt', at: 26, letter: 'A', text: 'To improve agricultural production.'},
    {k: 'opt', at: 27, letter: 'B', text: 'To understand [[rising global temperatures]].', hl: [34], ok: 38},
    {k: 'opt', at: 28, letter: 'C', text: 'To develop new energy sources.'},
    {k: 'opt', at: 29, letter: 'D', text: 'To protect endangered animals.'},
    {k: 'lbl', at: 30, text: 'PASSAGE'},
    {k: 'p', at: 31, text: 'The researcher became [[interested in climate patterns]] after noticing a significant [[increase in average temperatures]].', hl: [33, 35]},
  ], [
    {k: 'syn', at: 32, a: 'Studying Climate Change', b: 'Interested in Climate Patterns', bAt: 33},
    {k: 'syn', at: 34, a: 'Rising Global Temperatures', b: 'Increase in Average Temperatures', bAt: 35},
    {k: 'say', at: 36, text: 'শব্দ এক নয়'},
    {k: 'say', at: 37, text: 'কিন্তু [[Meaning একই]]'},
    {k: 'verdict', at: 38, tone: 'ans', label: 'Option B'},
  ]),
  tip(39, 0, [{at: 40, text: 'একই শব্দ নয়, [[একই Meaning]] খুঁজুন'}], [
    {at: 43, text: 'প্রতিটি Option ভালোভাবে যাচাই করুন', mark: 'check'},
    {at: 44, text: 'ভুল Option-এও Passage-এর কিছু তথ্য থাকতে পারে', mark: 'cross'},
    {at: 45, text: 'কিন্তু সেটি সঠিক উত্তর নাও হতে পারে', mark: 'cross'},
  ], 3),

  // ===================== 02 TFNG =====================
  rule(46, 1, 'Passage-এর সাথে Statement মেলানো', 'trio', [
    {at: 47, text: 'Passage-এর তথ্যের সঙ্গে Statement মিলিয়ে দেখুন'},
    {at: 49, tag: 'TRUE', text: 'তথ্য মিলে গেছে'},
    {at: 50, tag: 'FALSE', text: 'তথ্য বিপরীত'},
    {at: 51, tag: 'NOT GIVEN', text: 'পর্যাপ্ত তথ্য নেই'},
  ]),
  stage(52, 1, [
    {k: 'lbl', at: 53, text: 'PASSAGE'},
    {k: 'p', at: 54, text: 'Sarah moved to London in [[2018]].', hl: [63]},
    {k: 'p', at: 55, text: 'She started working at a university two years later.'},
    {k: 'stmt', at: 56, n: 1, text: '[[Sarah moved to London in 2018.]]', hl: [57], active: [56, 60], ans: {at: 58, label: 'TRUE', tone: 'ok'}},
    {k: 'stmt', at: 60, n: 2, text: 'Sarah moved to London in [[2019]].', hl: [64], active: [60, 66], ans: {at: 62, label: 'FALSE', tone: 'bad'}},
    {k: 'stmt', at: 66, n: 3, text: 'Sarah studied at Oxford University.', active: [66, 72], ans: {at: 68, label: 'NOT GIVEN', tone: 'ng'}},
  ], [
    {k: 'verdict', at: 58, until: 60, tone: 'ok', label: 'TRUE'},
    {k: 'say', at: 59, until: 60, text: 'Passage ও Statement-এ [[একই তথ্য]]'},
    {k: 'verdict', at: 62, until: 66, tone: 'bad', label: 'FALSE'},
    {k: 'say', at: 63, until: 66, text: 'Passage: [[2018]]'},
    {k: 'say', at: 64, until: 66, text: 'Statement: [[2019]]'},
    {k: 'say', at: 65, until: 66, text: 'দুটো তথ্য [[পরস্পরবিরোধী]]'},
    {k: 'verdict', at: 68, tone: 'ng', label: 'NOT GIVEN'},
    {k: 'say', at: 69, text: 'Sarah কোথায় পড়েছেন — Passage-এ [[বলা হয়নি]]'},
  ]),
  tip(71, 1, [{at: 72, text: 'Not Given [[≠]] False'}], [
    {at: 73, text: 'Passage থেকে সত্য না মিথ্যা, তা নিশ্চিত হওয়া যাচ্ছে না', mark: 'check'},
    {at: 74, text: 'Common Mistake: নিজের Knowledge ব্যবহার করা', mark: 'cross'},
    {at: 76, text: 'শুধু Passage-এর তথ্যের ওপর ভিত্তি করে উত্তর দিন', mark: 'check'},
  ], 3),

  // ===================== 03 YNNG =====================
  rule(77, 2, 'Writer-এর মত যাচাই', 'trio', [
    {at: 78, text: 'দেখতে TFNG-এর মতো, কিন্তু পার্থক্য আছে'},
    {at: 79, tag: 'TRUE / FALSE', text: 'Factual Information যাচাই'},
    {at: 80, tag: 'YES / NO', text: "Writer's Views, Claims, Opinions যাচাই"},
  ], ['YES', 'NO', 'NOT GIVEN']),
  stage(81, 2, [
    {k: 'lbl', at: 82, text: 'PASSAGE'},
    {k: 'p', at: 83, text: 'The government believes that [[public transport should receive more investment]] because it can reduce traffic congestion.', hl: [85]},
    {k: 'stmt', at: 84, n: 1, text: 'The government supports greater investment in public transport.', active: [84, 88], ans: {at: 86, label: 'YES', tone: 'ok'}},
    {k: 'stmt', at: 88, n: 2, text: 'The government believes that [[private cars]] are the best solution to traffic problems.', hl: [92], active: [88, 93], ans: {at: 90, label: 'NO', tone: 'bad'}},
    {k: 'stmt', at: 93, n: 3, text: 'The government plans to build ten new railway stations.', active: [93, 97], ans: {at: 95, label: 'NOT GIVEN', tone: 'ng'}},
  ], [
    {k: 'verdict', at: 86, until: 88, tone: 'ok', label: 'YES'},
    {k: 'say', at: 87, until: 88, text: 'Government-এর [[Support]]-এর কথা বলা হয়েছে'},
    {k: 'verdict', at: 90, until: 93, tone: 'bad', label: 'NO'},
    {k: 'say', at: 91, until: 93, text: '[[Public Transport]]-কে সমর্থন করা হয়েছে'},
    {k: 'say', at: 92, until: 93, text: '[[Private Cars]]-কে নয়'},
    {k: 'verdict', at: 95, tone: 'ng', label: 'NOT GIVEN'},
    {k: 'say', at: 96, text: 'Railway Station-এর সংখ্যা নিয়ে [[কিছু বলা হয়নি]]'},
  ]),
  tip(97, 2, [{at: 98, text: '[[Writer-এর Opinion]] বুঝুন'}], [
    {at: 98, text: 'Writer বা নির্দিষ্ট ব্যক্তির মত দেখে Yes / No ঠিক করুন', mark: 'check'},
    {at: 99, text: 'নিজের Opinion দিয়ে উত্তর দেওয়া যাবে না', mark: 'cross'},
  ], 2),

  // ===================== 04 Matching Headings =====================
  rule(100, 3, 'Paragraph-এর Main Idea', 'paragraphs', [
    {at: 101, text: 'অনেকেই এই প্রশ্নে সমস্যায় পড়েন'},
    {at: 102, text: 'প্রতিটি Paragraph-এর Main Idea খুঁজুন'},
    {at: 104, text: 'সঠিক Heading-এর সঙ্গে Paragraph Match করুন'},
    {at: 106, text: 'Heading মানে পুরো Paragraph-এর মূল বিষয়'},
    {at: 107, text: 'Paragraph-এর একটি ছোট তথ্য নয়'},
  ]),
  stage(108, 3, [
    {k: 'lbl', at: 109, text: 'PARAGRAPH'},
    {k: 'p', at: 110, text: 'Many people now prefer [[working from home]].', hl: [119]},
    {k: 'p', at: 111, text: 'This arrangement allows employees to [[save commuting time]] and [[spend more time with their families]].', hl: [120, 121]},
    {k: 'p', at: 112, text: 'Companies can also [[reduce office expenses]].', hl: [122]},
    {k: 'lbl', at: 113, text: 'HEADINGS'},
    {k: 'opt', at: 114, letter: 'A', text: 'The history of modern offices.'},
    {k: 'opt', at: 115, letter: 'B', text: 'Benefits of working remotely.', ok: 123},
    {k: 'opt', at: 116, letter: 'C', text: 'Problems caused by technology.'},
    {k: 'opt', at: 117, letter: 'D', text: 'Changes in public transportation.'},
  ], [
    {k: 'say', at: 118, text: 'এই Paragraph-এ কী নিয়ে আলোচনা?'},
    {k: 'say', at: 119, text: '[[Work From Home]]-এর সুবিধা'},
    {k: 'say', at: 120, text: '১) সময় বাঁচানো'},
    {k: 'say', at: 121, text: '২) পরিবারকে সময় দেওয়া'},
    {k: 'say', at: 122, text: '৩) অফিসের খরচ কমানো'},
    {k: 'verdict', at: 123, tone: 'ans', label: 'Option B'},
  ]),
  tip(124, 3, [{at: 124, text: 'প্রথম ও শেষ বাক্য ভালোভাবে পড়ুন'}], [
    {at: 125, text: 'তবে সব সময় প্রথম বাক্যে Main Idea থাকে না', mark: 'cross'},
    {at: 126, text: 'পুরো Paragraph-এর Meaning বুঝতে হবে', mark: 'check'},
    {at: 128, text: 'একটি শব্দ মিলে গেলেই Heading বেছে নেবেন না', mark: 'cross'},
  ], 3, 76),

  // ===================== 05 Matching Information =====================
  rule(130, 4, 'কোন Paragraph-এ কোন তথ্য', 'paragraphs', [
    {at: 131, text: 'নির্দিষ্ট Information খুঁজে বের করুন'},
    {at: 132, text: 'কোন Paragraph-এ কোন তথ্য — শনাক্ত করুন'},
  ]),
  stage(133, 4, [
    {k: 'tiles', at: 134, items: ['A', 'B', 'C', 'D', 'E'], dt: 0.45, pick: {idx: 2, at: 138}},
    {k: 'lbl', at: 135, text: 'QUESTION'},
    {k: 'p', at: 136, text: 'Which paragraph mentions the [[discovery]] of a [[new species]]?', hl: [143, 144]},
    {k: 'lbl', at: 138, text: 'PARAGRAPH C'},
    {k: 'p', at: 139, text: 'Scientists recently [[discovered]] a [[previously unknown species]] of frog in a remote forest.', hl: [143, 144]},
  ], [
    {k: 'say', at: 137, text: 'প্রতিটি Paragraph-এ তথ্যটি খুঁজুন'},
    {k: 'say', at: 140, text: '[[New Species]] আবিষ্কারের কথা'},
    {k: 'verdict', at: 141, tone: 'ans', label: 'Paragraph C'},
    {k: 'syn', at: 143, a: 'Discovery', b: 'Finding', bAt: 143},
    {k: 'syn', at: 144, a: 'New Species', b: 'Previously Unknown Species', bAt: 144},
  ]),
  tip(145, 4, [{at: 146, text: 'একই Paragraph [[একাধিকবার]] ব্যবহার হতে পারে'}], [
    {at: 147, text: 'প্রশ্নের নির্দেশনা অবশ্যই ভালোভাবে পড়বেন', mark: 'check'},
  ], 1, 80),

  // ===================== 06 Matching Features =====================
  rule(148, 5, 'ব্যক্তি, প্রতিষ্ঠান বা দেশের সাথে তথ্য', 'match', [
    {at: 149, text: 'ব্যক্তি, প্রতিষ্ঠান, দেশ বা অন্য Feature-এর সঙ্গে তথ্য Match করুন'},
  ]),
  stage(150, 5, [
    {k: 'tiles', at: 151, items: ['Dr. Smith', 'Professor Brown', 'Dr. Wilson'], dt: 1.0, pick: {idx: 1, at: 159}},
    {k: 'lbl', at: 153, text: 'QUESTION'},
    {k: 'p', at: 154, text: 'Which scientist developed a [[new teaching method]]?', hl: [158]},
    {k: 'lbl', at: 156, text: 'PASSAGE'},
    {k: 'p', at: 157, text: '[[Professor Brown]] introduced an [[innovative approach to teaching mathematics]].', hl: [157, 158]},
  ], [
    {k: 'say', at: 152, text: 'প্রত্যেকের আলাদা গবেষণার বিষয়'},
    {k: 'say', at: 155, text: 'খুঁজুন: কোন Scientist [[নতুন Teaching Method]] তৈরি করেছেন?'},
    {k: 'syn', at: 158, a: 'Innovative Approach to Teaching Mathematics', b: 'নতুন Teaching Method', bAt: 158},
    {k: 'verdict', at: 159, tone: 'ans', label: 'Professor Brown'},
  ]),
  tip(160, 5, [{at: 160, text: 'গুরুত্বপূর্ণ [[Strategy]]'}], [
    {at: 161, text: 'প্রথমে দেওয়া Names বা Features খুঁজে বের করুন', mark: 'num'},
    {at: 162, text: 'এরপর তাদের সঙ্গে সম্পর্কিত Information পড়ুন', mark: 'num'},
    {at: 163, text: 'একই নামের আশেপাশে একাধিক তথ্য থাকতে পারে', mark: 'cross'},
  ], 3),

  // ===================== 07 Sentence Endings =====================
  rule(164, 6, 'অসম্পূর্ণ বাক্যের সঠিক শেষাংশ', 'match', [
    {at: 165, text: 'কয়েকটি Incomplete Sentence দেওয়া হবে'},
    {at: 166, text: 'কয়েকটি Sentence Ending দেওয়া থাকবে'},
    {at: 167, text: 'সঠিক Ending নির্বাচন করে বাক্য সম্পূর্ণ করুন'},
  ]),
  stage(168, 6, [
    {k: 'lbl', at: 169, text: 'BEGINNINGS'},
    {k: 'stmt', at: 171, n: 1, text: 'Regular exercise helps people.', active: [184, 188], ans: {at: 187, label: 'C', tone: 'ans'}},
    {k: 'stmt', at: 173, n: 2, text: 'Solar energy is becoming popular because', active: [188, 192], ans: {at: 191, label: 'A', tone: 'ans'}},
    {k: 'stmt', at: 175, n: 3, text: 'Many students prefer online learning.', active: [192, 196], ans: {at: 195, label: 'B', tone: 'ans'}},
    {k: 'lbl', at: 176, text: 'ENDINGS'},
    {k: 'opt', at: 177, letter: 'A', text: 'It can reduce electricity costs.', ok: 191},
    {k: 'opt', at: 179, letter: 'B', text: 'Because it offers greater flexibility.', ok: 195},
    {k: 'opt', at: 181, letter: 'C', text: 'Maintain good physical health.', ok: 187},
  ], [
    {k: 'syn', at: 184, until: 188, a: 'Regular exercise helps people', b: 'Maintain good physical health', bAt: 186, sep: 'to'},
    {k: 'verdict', at: 187, until: 188, tone: 'ans', label: 'উত্তর C'},
    {k: 'syn', at: 188, until: 192, a: 'Solar energy is becoming popular because', b: 'It can reduce electricity costs', bAt: 190, sep: 'to'},
    {k: 'verdict', at: 191, until: 192, tone: 'ans', label: 'উত্তর A'},
    {k: 'syn', at: 192, a: 'Many students prefer online learning', b: 'Because it offers greater flexibility', bAt: 194, sep: 'to'},
    {k: 'verdict', at: 195, tone: 'ans', label: 'উত্তর B'},
  ]),
  tip(196, 6, [{at: 196, text: 'শুধু [[Grammar]] নয়'}], [
    {at: 197, text: 'Sentence-এর Meaning-ও বুঝতে হবে', mark: 'check'},
  ], 1, 96),

  // ===================== 08 Sentence Completion =====================
  rule(198, 7, 'ফাঁকা জায়গায় সঠিক শব্দ', 'blanks', [
    {at: 199, text: 'একটি অসম্পূর্ণ Sentence দেওয়া হবে'},
    {at: 200, text: 'Passage থেকে সঠিক শব্দ দিয়ে সম্পূর্ণ করুন'},
  ]),
  stage(201, 7, [
    {k: 'lbl', at: 201, text: 'QUESTION'},
    {k: 'p', at: 202, text: 'The [[main source of energy]] for the human body is [_].', hl: [205], fill: {at: 206, text: 'Carbohydrates'}},
    {k: 'lbl', at: 203, text: 'PASSAGE'},
    {k: 'p', at: 204, text: '[[Carbohydrates]] provide the body with its [[primary source of energy]].', hl: [206, 205]},
  ], [
    {k: 'say', at: 201, text: 'Blank-এ কী বসবে?'},
    {k: 'say', at: 203, text: 'Passage থেকে [[সঠিক শব্দ]] খুঁজুন'},
    {k: 'syn', at: 205, a: 'Main Source of Energy', b: 'Primary Source of Energy', bAt: 205},
    {k: 'verdict', at: 206, tone: 'ans', label: 'Carbohydrates'},
  ]),
  tip(207, 7, [{at: 208, text: '[[Instruction]] ভালোভাবে পড়ুন'}], [
    {at: 209, tag: 'No More Than Two Words', text: 'সর্বোচ্চ দুইটি শব্দ'},
    {at: 211, tag: 'One Word Only', text: 'একটির বেশি শব্দ নয়'},
    {at: 213, text: 'সঠিক উত্তরও Word Limit পার করলে ভুল হতে পারে', mark: 'cross'},
  ], 3),

  // ===================== 09 Summary Completion =====================
  rule(214, 8, 'Summary-র ফাঁকা পূরণ', 'blanks', [
    {at: 215, text: 'একটি Summary দেওয়া হবে'},
    {at: 216, text: 'কিছু জায়গা ফাঁকা থাকবে'},
    {at: 217, text: 'Passage থেকে সঠিক শব্দ খুঁজে পূরণ করুন'},
    {at: 218, text: 'কখনো Word List দেওয়া থাকবে'},
    {at: 219, text: 'কখনো Passage থেকেই উত্তর খুঁজতে হবে'},
  ]),
  stage(220, 8, [
    {k: 'lbl', at: 221, text: 'PASSAGE'},
    {k: 'p', at: 222, text: 'Bees collect [[nectar]] from flowers and use it to produce honey.', hl: [227]},
    {k: 'p', at: 223, text: 'They also play an important role in pollination.'},
    {k: 'lbl', at: 224, text: 'SUMMARY'},
    {k: 'p', at: 225, text: 'Bees collect [_] from flowers to produce honey.', fill: {at: 228, text: 'Nectar'}},
  ], [
    {k: 'say', at: 224, text: 'Summary-র [[ফাঁকা জায়গা]] পূরণ করতে হবে'},
    {k: 'say', at: 226, text: 'Passage-এ কী বলা হয়েছে?'},
    {k: 'say', at: 227, text: 'Bees collect [[Nectar]] from flowers'},
    {k: 'verdict', at: 228, tone: 'ans', label: 'Nectar'},
  ]),
  tip(229, 8, [{at: 230, text: 'Sentence [[হুবহু একই]] নাও হতে পারে'}], [
    {at: 231, text: 'তাই Synonyms বুঝতে হবে', mark: 'check'},
    {at: 232, text: 'Word Limit অবশ্যই মেনে চলুন', mark: 'check'},
  ], 2, 80),

  // ===================== 10 Note Completion =====================
  rule(233, 9, 'Notes-এর Blank পূরণ', 'kv', [
    {at: 234, text: 'কিছু Notes দেওয়া হবে'},
    {at: 235, text: 'গুরুত্বপূর্ণ তথ্যের জায়গায় Blank থাকবে'},
    {at: 236, text: 'Passage থেকে সঠিক Information খুঁজে পূরণ করুন'},
  ]),
  stage(237, 9, [
    {k: 'lbl', at: 237, text: 'PASSAGE'},
    {k: 'p', at: 238, text: 'The museum opens at [[9 am]] and closes at [[5 pm]].', hl: [246, 247]},
    {k: 'p', at: 239, text: 'Visitors can purchase tickets [[online]].', hl: [248]},
    {k: 'lbl', at: 241, text: 'MUSEUM INFORMATION'},
    {k: 'table', at: 241, head: ['Note', 'Answer'], rowAt: [242, 243, 244], rows: [
      {a: 'Opening Time', fill: {at: 246, text: '9 am'}},
      {a: 'Closing Time', fill: {at: 247, text: '5 pm'}},
      {a: 'Ticket Purchase', fill: {at: 248, text: 'Online'}},
    ]},
  ], [
    {k: 'say', at: 240, text: 'Notes-এ [[Blank]] আছে'},
    {k: 'say', at: 245, text: 'এখন Passage থেকে উত্তর বের করুন'},
    {k: 'syn', at: 246, a: 'Opening Time', b: '9 am', bAt: 246, sep: 'to'},
    {k: 'syn', at: 247, a: 'Closing Time', b: '5 pm', bAt: 247, sep: 'to'},
    {k: 'syn', at: 248, a: 'Ticket Purchase', b: 'Online', bAt: 248, sep: 'to'},
  ]),
  tip(249, 9, [{at: 249, text: 'পুরো Passage [[পড়ার দরকার নেই]]'}], [
    {at: 250, text: 'প্রথমে Notes-এর Keywords বুঝুন', mark: 'num'},
    {at: 251, text: 'তারপর Passage-এ সেই তথ্য Locate করুন', mark: 'num'},
  ], 2, 80),

  // ===================== 11 Table Completion =====================
  rule(252, 10, 'Table-এর Blank পূরণ', 'table', [
    {at: 253, text: 'একটি Table দেওয়া থাকবে'},
    {at: 254, text: 'বিভিন্ন তথ্যের জায়গায় Blank থাকবে'},
    {at: 255, text: 'Passage থেকে সঠিক তথ্য খুঁজে Table সম্পূর্ণ করুন'},
  ]),
  stage(256, 10, [
    {k: 'lbl', at: 257, text: 'PASSAGE'},
    {k: 'p', at: 258, text: 'Three cities introduced public bicycle services.'},
    {k: 'p', at: 259, text: 'London started its service in [[2010]].', hl: [268]},
    {k: 'p', at: 260, text: 'Paris started its service in [[2007]].', hl: [269]},
    {k: 'p', at: 261, text: 'And Berlin started its service in [[2002]].', hl: [270]},
    {k: 'table', at: 262, head: ['City', 'Starting Year'], rowAt: [264, 265, 266], rows: [
      {a: 'London', fill: {at: 268, text: '2010'}},
      {a: 'Paris', fill: {at: 269, text: '2007'}},
      {a: 'Berlin', fill: {at: 270, text: '2002'}},
    ]},
  ], [
    {k: 'say', at: 262, text: 'Table-এর [[Blank]] পূরণ করতে হবে'},
    {k: 'say', at: 267, text: 'City-র সাথে সঠিক Year Match করুন'},
    {k: 'syn', at: 268, a: 'London', b: '2010', bAt: 268, sep: 'to'},
    {k: 'syn', at: 269, a: 'Paris', b: '2007', bAt: 269, sep: 'to'},
    {k: 'syn', at: 270, a: 'Berlin', b: '2002', bAt: 270, sep: 'to'},
  ]),
  tip(272, 10, [{at: 272, text: 'সঠিক [[Row,]] সঠিক তথ্য'}], [
    {at: 272, text: 'City Name এবং Year ভালোভাবে Match করুন', mark: 'check'},
    {at: 273, text: 'ভুল Row-তে সঠিক তথ্য লিখলেও উত্তর ভুল হবে', mark: 'cross'},
  ], 2, 88),

  // ===================== 12 Flow Chart =====================
  rule(274, 11, 'ধাপে ধাপে Process', 'flow', [
    {at: 275, text: 'Process-এর ধাপ Flow Chart-এ দেখানো হয়'},
    {at: 276, text: 'কিছু ধাপ দেওয়া থাকবে'},
    {at: 277, text: 'কিছু জায়গা ফাঁকা থাকবে'},
    {at: 278, text: 'Passage থেকে সঠিক তথ্য খুঁজে পূরণ করুন'},
  ]),
  stage(279, 11, [
    {k: 'lbl', at: 279, text: 'PASSAGE'},
    {k: 'p', at: 280, text: '[[First]], the coffee beans are collected.', hl: [280]},
    {k: 'p', at: 281, text: '[[Next]], they are dried in the sun.', hl: [281]},
    {k: 'p', at: 282, text: '[[After drying]], the beans are [[roasted]].', hl: [282, 289]},
    {k: 'p', at: 283, text: '[[Finally]], they are ground into powder.', hl: [283]},
    {k: 'lbl', at: 284, text: 'FLOW CHART'},
    {k: 'flow', boxes: [
      {at: 285, text: 'Collect Coffee Beans'},
      {at: 286, text: 'Dry the Beans'},
      {at: 287, text: '', fill: {at: 289, text: 'Roasted'}},
      {at: 288, text: 'Grind into Powder'},
    ]},
  ], [
    {k: 'say', at: 280, text: '[[Sequence Words]] খেয়াল করুন'},
    {k: 'say', at: 284, text: 'ধাপগুলো Flow Chart-এ সাজানো'},
    {k: 'verdict', at: 289, tone: 'ans', label: 'Roasted'},
    {k: 'say', at: 290, text: 'শুকানোর পর Coffee Beans [[Roasted]] করা হয়'},
  ]),
  {kind: 'cards', a: 291, tone: 'red', typeIdx: 11, label: {at: 291, text: 'মনে রাখবেন'}, headline: [{at: 291, text: '[[Sequence Words]] খুব গুরুত্বপূর্ণ'}], headSize: 80, cols: 5, cardSize: 40, cards: [
    {at: 292, text: 'First', mark: 'num'}, {at: 293, text: 'Next', mark: 'num'}, {at: 294, text: 'Then', mark: 'num'},
    {at: 295, text: 'After That', mark: 'num'}, {at: 296, text: 'Finally', mark: 'num'},
  ]},

  // ===================== 13 Diagram Label =====================
  rule(298, 12, 'Diagram-এর অংশের নাম', 'diagram', [
    {at: 299, text: 'একটি Diagram দেওয়া হবে'},
    {at: 300, text: 'বিভিন্ন অংশের নাম ফাঁকা থাকবে'},
    {at: 301, text: 'Passage থেকে সঠিক শব্দ খুঁজে Label করুন'},
  ]),
  stage(302, 12, [
    {k: 'p', at: 304, text: '[[Water]] enters the plant through its [[roots]].', hl: [308, 308]},
    {k: 'p', at: 305, text: 'It travels up the [[stem]] and reaches the [[leaves]].', hl: [310, 312]},
    {k: 'plant', at: 302, labels: [
      {at: 307, text: 'Water absorption part', y: 360, fill: {at: 308, text: 'Roots'}},
      {at: 309, text: 'Main supporting part', y: 210, fill: {at: 310, text: 'Stem'}},
      {at: 311, text: 'Water reaches', y: 110, fill: {at: 312, text: 'Leaves'}},
    ]},
  ], [
    {k: 'say', at: 303, text: 'Passage-এ তথ্যটি আছে'},
    {k: 'say', at: 306, text: 'Diagram-এ [[তিনটি Blank]]'},
    {k: 'syn', at: 308, a: 'Water Absorption Part', b: 'Roots', bAt: 308, sep: 'to'},
    {k: 'syn', at: 310, a: 'Main Supporting Part', b: 'Stem', bAt: 310, sep: 'to'},
    {k: 'syn', at: 312, a: 'Water Reaches', b: 'Leaves', bAt: 312, sep: 'to'},
  ]),
  tip(314, 12, [{at: 314, text: 'প্রতিটি অংশ ভালোভাবে [[পর্যবেক্ষণ]] করুন'}], [
    {at: 314, text: 'Diagram-এর প্রতিটি অংশ দেখুন', mark: 'num'},
    {at: 315, text: 'তারপর Passage-এর Information-এর সঙ্গে Match করুন', mark: 'num'},
  ], 2, 76),

  // ===================== 14 Short Answer =====================
  rule(316, 13, 'ছোট সরাসরি উত্তর', 'qa', [
    {at: 317, text: 'সরাসরি কয়েকটি প্রশ্ন করা হবে'},
    {at: 318, text: 'Passage থেকে অল্প কয়েকটি শব্দে উত্তর দিন'},
  ]),
  stage(319, 13, [
    {k: 'lbl', at: 319, text: 'PASSAGE'},
    {k: 'p', at: 320, text: '[[Thomas Edison]] invented a practical electric light bulb in [[1879]].', hl: [323, 326]},
    {k: 'lbl', at: 321, text: 'QUESTIONS'},
    {k: 'stmt', at: 322, n: 1, text: 'Who invented a practical electric light bulb?', active: [322, 324], ans: {at: 323, label: 'Thomas Edison', tone: 'ans'}},
    {k: 'stmt', at: 325, n: 2, text: 'When was it invented?', active: [325, 327], ans: {at: 326, label: '1879', tone: 'ans'}},
  ], [
    {k: 'say', at: 321, text: 'সরাসরি প্রশ্ন, [[ছোট উত্তর]]'},
    {k: 'syn', at: 323, a: 'Who?', b: 'Thomas Edison', bAt: 323, sep: 'to'},
    {k: 'syn', at: 326, a: 'When?', b: '1879', bAt: 326, sep: 'to'},
  ]),
  {kind: 'cards', a: 327, tone: 'red', typeIdx: 13, label: {at: 327, text: 'মনে রাখবেন'}, headline: [{at: 327, text: 'প্রশ্নের [[শব্দ]] বুঝুন'}], headSize: 80, cols: 3, cardSize: 40, cards: [
    {at: 328, tag: 'Who', text: 'Person-এর নাম'},
    {at: 329, tag: 'When', text: 'Time বা Date'},
    {at: 330, tag: 'Where', text: 'Place'},
    {at: 331, tag: 'Why', text: 'Reason'},
    {at: 332, tag: 'How', text: 'Method বা Process'},
    {at: 333, text: 'Keywords সঠিক উত্তর খুঁজতে সাহায্য করবে', mark: 'check'},
  ]},

  // ===================== COMMON MISTAKES =====================
  {kind: 'hero', a: 334, tone: 'dark', lines: [
    {at: 334, text: '[[Common]] Mistakes', size: 150, sfx: 'thud'},
    {at: 335, text: 'শুধু Question Type জানা যথেষ্ট নয়', size: 62, weight: 600},
    {at: 336, text: 'কোন ভুলগুলো আপনার Score কমিয়ে দেয়?', size: 62, weight: 500, muted: true},
  ]},
  {kind: 'mistake', a: 337, tone: 'cream', n: 1, sub: 'প্রথম ভুল', title: 'Reading Every Word', variant: 'row',
    wrong: [{at: 338, text: 'Passage-এর প্রতিটি শব্দ পড়ার চেষ্টা'}, {at: 339, text: 'অনেক সময় নষ্ট হয়'}],
    right: [{at: 340, text: 'আগে Structure ও Main Idea বুঝুন'}, {at: 341, text: 'তারপর প্রশ্ন অনুযায়ী Information খুঁজুন'}]},
  {kind: 'mistake', a: 342, tone: 'red', n: 2, sub: 'দ্বিতীয় ভুল', title: 'Ignoring Synonyms', variant: 'flip',
    wrong: [{at: 343, text: 'প্রশ্ন ও Passage-এর শব্দ সব সময় এক নয়'}],
    right: [{at: 344, a: 'Increase', b: 'Rise'}, {at: 345, a: 'Decrease', b: 'Decline'}, {at: 346, a: 'Important', b: 'Significant'}, {at: 347, a: 'Difficult', b: 'Challenging'}, {at: 348, text: 'Vocabulary ও Synonyms শেখার অভ্যাস করুন'}]},
  {kind: 'mistake', a: 349, tone: 'dark', n: 3, sub: 'তৃতীয় ভুল', title: 'Ignoring Word Limit', variant: 'stack',
    wrong: [{at: 350, text: 'সঠিক উত্তর খুঁজে পান'}, {at: 351, text: 'কিন্তু Word Limit না মানায় ভুল হয়'}],
    right: [{at: 352, text: 'প্রতিটি প্রশ্নের Instruction ভালোভাবে পড়ুন'}]},
  {kind: 'mistake', a: 353, tone: 'cream', n: 4, sub: 'চতুর্থ ভুল', title: 'Using Your Own Knowledge', variant: 'row',
    wrong: [{at: 354, text: 'ব্যক্তিগত Knowledge দিয়ে উত্তর দেওয়া'}],
    right: [{at: 355, text: 'Passage-এ যা বলা হয়েছে, সেটিই অনুসরণ করুন'}]},
  {kind: 'mistake', a: 356, tone: 'red', n: 5, sub: 'পঞ্চম ভুল', title: 'Too Much Time on One Question', variant: 'flip',
    wrong: [{at: 357, text: 'একটি প্রশ্নের পেছনে অতিরিক্ত সময়'}],
    right: [{at: 358, text: 'কঠিন মনে হলে Mark করে পরের প্রশ্নে যান'}, {at: 359, text: 'সময় থাকলে পরে ফিরে আসুন'}]},

  // ===================== STRATEGIES =====================
  {kind: 'hero', a: 360, tone: 'dark', lines: [
    {at: 360, text: 'এবার কয়েকটি গুরুত্বপূর্ণ', size: 70, weight: 500, muted: true},
    {at: [360, 0.8], text: '[[Strategy]]', size: 190, sfx: 'thud'},
    {at: 361, text: 'নিয়মিত Practice করলে Reading Skills উন্নত হবে', size: 56, weight: 600},
  ]},
  {kind: 'grid', a: 362, tone: 'cream', mode: 'check', cols: 2, tileH: 118, fs: 38,
    title: [{at: 362, text: 'Reading Skills উন্নত করার [[৭টি]] উপায়'}], titleSize: 64,
    tiles: [
      {at: 362, text: 'প্রতিদিন ইংরেজি Reading Practice'},
      {at: 363, text: 'প্রতিটি Question Type আলাদাভাবে Practice'},
      {at: 364, text: 'নতুন Vocabulary ও Synonyms শিখুন'},
      {at: 365, text: 'Mock Test-এর পর ভুলগুলো Analyse করুন'},
      {at: 366, text: 'কেন সঠিক, কেন অন্য Option ভুল — বুঝুন'},
      {at: 368, text: 'নিয়মিত Cambridge IELTS Practice Tests'},
      {at: 369, text: 'সময় ধরে Practice করার অভ্যাস'},
    ]},

  // ===================== CLOSING =====================
  {kind: 'cards', a: 370, tone: 'red', label: {at: 370, text: 'মনে রাখবেন'}, headline: [{at: 371, text: 'শুধু বেশি Passage পড়লেই হবে না'}], headSize: 80, cols: 3, cardSize: 42, cards: [
    {at: 372, text: 'সঠিক Information খুঁজে বের করা শিখুন', mark: 'num'},
    {at: 373, text: 'প্রতিটি Question Type-এর Strategy বুঝুন', mark: 'num'},
    {at: 374, text: 'নিয়মিত Practice করুন', mark: 'num'},
  ]},
  {kind: 'grid', a: 375, tone: 'dark', mode: 'num', cols: 5, tileH: 112, fs: 28, titleSize: 68,
    title: [{at: 375, text: 'আজ আমরা শিখলাম সব [[Question Type]]'}],
    tiles: TYPES.map((t, i) => ({at: [375, 0.2 + i * 0.17] as TRef, text: SHORT[i]}))},
  {kind: 'hero', a: 377, tone: 'cream', lines: [
    {at: 377, text: 'IELTS Reading-এ ভালো Band Score চান?', size: 70, weight: 600},
    {at: [377, 2.6], text: 'আজ থেকেই [[Practice]] শুরু করুন', size: 120, sfx: 'thud'},
  ]},
  {kind: 'cta', a: 378, tone: 'red'},
  {kind: 'hero', a: 381, tone: 'dark', lines: [
    {at: 381, text: 'দেখা হবে পরবর্তী ভিডিওতে', size: 84, weight: 600},
    {at: 382, text: 'Until then, keep [[learning]] and keep [[improving.]]', size: 72, weight: 500},
    {at: 383, text: 'Thank you for watching [[IMAM]] IELTS', size: 66, weight: 700, sfx: 'chime'},
  ]},
];
