import React from 'react';
import {interpolate, useCurrentFrame} from 'remotion';
import {RADIUS, TONES} from '../theme';
import {TRef} from '../timing';
import {Content, Icon, Reveal, SfxName, Words, useScene, useT} from './core';

const RED = TONES.dark.accent;

// ============ Hero: কাইনেটিক টাইপোগ্রাফি ============
export interface HeroLine {at: TRef; text: string; size: number; weight?: number; sfx?: SfxName; muted?: boolean}
export const Hero: React.FC<{lines: HeroLine[]; align?: 'left' | 'center'}> = ({lines, align = 'center'}) => {
  const {tone} = useScene();
  const t = useT();
  return (
    <Content top={90} style={{justifyContent: 'center', alignItems: align === 'center' ? 'center' : 'flex-start', gap: 26}}>
      {lines.map((l, i) => (
        <Words key={i} text={l.text} at={t(l.at)} size={l.size} weight={l.weight ?? 700} align={align} color={l.muted ? tone.sub : undefined} sfx={l.sfx} line={1.2} />
      ))}
    </Content>
  );
};

// ============ Cards: বক্তব্য + কার্ড ============
export interface CardDef {at: TRef; text: string; tag?: string; mark?: 'check' | 'cross' | 'num'}
export const Cards: React.FC<{
  label?: {at: TRef; text: string}; headline?: {at: TRef; text: string}[]; headSize?: number;
  cards: CardDef[]; cols: number; cardSize?: number;
}> = ({label, headline = [], headSize = 88, cards, cols, cardSize = 42}) => {
  const {tone} = useScene();
  const t = useT();
  const gap = 26;
  return (
    <Content top={110} style={{justifyContent: 'center', gap: 34}}>
      {label ? (
        <Reveal at={t(label.at)} x={-30} y={0} sfx="pop">
          <span style={{display: 'inline-block', background: tone.chipBg, color: tone.chipFg, fontSize: 34, fontWeight: 700, padding: '6px 28px', borderRadius: 40}}>{label.text}</span>
        </Reveal>
      ) : null}
      <div style={{display: 'flex', flexDirection: 'column', gap: 6}}>
        {headline.map((h, i) => (
          <Words key={i} text={h.text} at={t(h.at)} size={headSize} line={1.2} sfx={i === 0 ? 'thud' : undefined} />
        ))}
      </div>
      <div style={{display: 'flex', flexWrap: 'wrap', gap}}>
        {cards.map((c, i) => (
          <Reveal key={i} at={t(c.at)} i={i} sfx="pop" style={{width: `calc((100% - ${gap * (cols - 1)}px) / ${cols})`, boxSizing: 'border-box'}}>
            <div style={{background: tone.card, color: tone.cardFg, borderRadius: RADIUS, padding: '26px 32px', border: c.mark === 'cross' ? `3px dashed ${RED}` : `2px solid ${tone.line}`, display: 'flex', gap: 22, alignItems: 'center', minHeight: 120}}>
              {c.mark ? (
                <div style={{flex: 'none', width: 62, height: 62, borderRadius: '50%', background: c.mark === 'cross' ? RED : tone.name === 'dark' ? TONES.dark.chipBg : TONES.cream.chipBg, color: c.mark === 'cross' ? '#fff' : tone.name === 'dark' ? TONES.dark.chipFg : TONES.cream.chipFg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 32, fontWeight: 700}}>
                  {c.mark === 'num' ? i + 1 : <Icon k={c.mark} size={34} />}
                </div>
              ) : null}
              <div style={{display: 'flex', flexDirection: 'column'}}>
                {c.tag ? <div style={{fontSize: 30, fontWeight: 700, color: RED, lineHeight: 1.2}}>{c.tag}</div> : null}
                <div style={{fontSize: cardSize, fontWeight: 600, lineHeight: 1.3}}>{c.text}</div>
              </div>
            </div>
          </Reveal>
        ))}
      </div>
    </Content>
  );
};

// ============ Grid: Bento / Recap / Checklist ============
export interface TileDef {at: TRef; text: string; sub?: string}
export const Grid: React.FC<{
  title?: {at: TRef; text: string}[]; titleSize?: number; tiles: TileDef[]; cols: number; mode: 'num' | 'check'; tileH?: number; fs?: number;
}> = ({title = [], titleSize = 76, tiles, cols, mode, tileH = 120, fs = 32}) => {
  const {tone} = useScene();
  const t = useT();
  const f = useCurrentFrame();
  const gap = 20;
  return (
    <Content top={110} style={{justifyContent: 'center', gap: 30}}>
      {title.map((h, i) => (
        <Words key={i} text={h.text} at={t(h.at)} size={titleSize} line={1.2} sfx={i === 0 ? 'thud' : undefined} />
      ))}
      <div style={{display: 'flex', flexWrap: 'wrap', gap}}>
        {tiles.map((tl, i) => {
          const at = t(tl.at);
          const done = f >= at + 8;
          return (
            <Reveal key={i} at={at} i={i} sfx={mode === 'check' ? 'tick' : 'pop'} vol={0.24} y={22} style={{width: `calc((100% - ${gap * (cols - 1)}px) / ${cols})`, boxSizing: 'border-box'}}>
              <div style={{background: tone.card, color: tone.cardFg, borderRadius: 24, border: `2px solid ${tone.line}`, minHeight: tileH, padding: '14px 24px', display: 'flex', alignItems: 'center', gap: 18}}>
                <div style={{flex: 'none', width: 54, height: 54, borderRadius: mode === 'check' ? '50%' : 14, background: done && mode === 'check' ? RED : tone.name === 'dark' ? TONES.dark.chipBg : TONES.cream.chipBg, color: done && mode === 'check' ? '#fff' : tone.name === 'dark' ? TONES.dark.chipFg : TONES.cream.chipFg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 26, fontWeight: 700}}>
                  {mode === 'check' ? (done ? <Icon k="check" size={30} /> : i + 1) : String(i + 1).padStart(2, '0')}
                </div>
                <div style={{display: 'flex', flexDirection: 'column'}}>
                  <div style={{fontSize: fs, fontWeight: 600, lineHeight: 1.25}}>{tl.text}</div>
                  {tl.sub ? <div style={{fontSize: fs - 8, color: tone.cardSub, lineHeight: 1.3}}>{tl.sub}</div> : null}
                </div>
              </div>
            </Reveal>
          );
        })}
      </div>
    </Content>
  );
};

// ============ Hub and Spoke ============
export const Hub: React.FC<{center: string; centerSub: string; nodes: {at: TRef; text: string}[]; title: {at: TRef; text: string}; caption: {at: TRef; text: string}}> = ({center, centerSub, nodes, title, caption}) => {
  const {tone} = useScene();
  const t = useT();
  const f = useCurrentFrame();
  const CX = 880; const CY = 400; const RX = 700; const RY = 330;
  const breathe = 1 + Math.sin(f / 18) * 0.02;
  return (
    <Content top={90} style={{}}>
      <Words text={title.text} at={t(title.at)} size={64} sfx="thud" />
      <div style={{position: 'relative', flex: 1}}>
        <svg width={1760} height={800} style={{position: 'absolute', left: 0, top: 0}}>
          {nodes.map((n, i) => {
            const a = (i / nodes.length) * Math.PI * 2 - Math.PI / 2;
            const p = interpolate(f, [t(n.at), t(n.at) + 12], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
            return <line key={i} x1={CX} y1={CY} x2={CX + Math.cos(a) * RX * p} y2={CY + Math.sin(a) * RY * p} stroke={tone.line} strokeWidth={3} />;
          })}
        </svg>
        <Reveal at={t(title.at) + 6} y={0} sfx="chime" style={{position: 'absolute', left: CX - 150, top: CY - 150, width: 300, height: 300}}>
          <div style={{width: 300, height: 300, borderRadius: '50%', background: RED, color: '#fff', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', transform: `scale(${breathe})`}}>
            <div style={{fontSize: 48, fontWeight: 700, lineHeight: 1.1}}>{center}</div>
            <div style={{fontSize: 30, fontWeight: 500}}>{centerSub}</div>
          </div>
        </Reveal>
        {nodes.map((n, i) => {
          const a = (i / nodes.length) * Math.PI * 2 - Math.PI / 2;
          return (
            <Reveal key={i} at={t(n.at)} i={i} sfx="pop" vol={0.2} y={0} style={{position: 'absolute', left: CX + Math.cos(a) * RX - 105, top: CY + Math.sin(a) * RY - 30, width: 210}}>
              <div style={{background: tone.card, color: tone.cardFg, border: `2px solid ${tone.line}`, borderRadius: 40, height: 60, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 27, fontWeight: 600, whiteSpace: 'nowrap'}}>{n.text}</div>
            </Reveal>
          );
        })}
        <Reveal at={t(caption.at)} y={20} sfx="pop" style={{position: 'absolute', left: 0, right: 0, top: CY + 190, display: 'flex', justifyContent: 'center'}}>
          <div style={{background: tone.chipBg, color: tone.chipFg, fontSize: 44, fontWeight: 700, padding: '10px 40px', borderRadius: 50}}>{caption.text}</div>
        </Reveal>
      </div>
    </Content>
  );
};

// ============ Common Mistake ============
export interface MItem {at: TRef; text?: string; a?: string; b?: string}
export const Mistake: React.FC<{n: number; title: string; sub: string; wrong: MItem[]; right: MItem[]; variant: 'row' | 'flip' | 'stack'; at: TRef}> = ({n, title, sub, wrong, right, variant, at}) => {
  const {tone} = useScene();
  const t = useT();
  const head = (
    <div style={{display: 'flex', flexDirection: variant === 'stack' ? 'row' : 'column', alignItems: variant === 'stack' ? 'center' : 'flex-start', gap: variant === 'stack' ? 40 : 10, width: variant === 'stack' ? '100%' : 560, flex: 'none'}}>
      <Reveal at={t(at)} y={0} sfx="thud">
        <div style={{fontSize: variant === 'stack' ? 150 : 220, fontWeight: 700, lineHeight: 1, color: tone.accent}}>{String(n).padStart(2, '0')}</div>
      </Reveal>
      <div>
        <div style={{fontSize: 34, fontWeight: 600, color: tone.sub}}>{sub}</div>
        <Words text={title} at={t(at) + 4} size={variant === 'stack' ? 76 : 64} line={1.15} />
      </div>
    </div>
  );
  const box = (items: MItem[], good: boolean) => (
    <div style={{flex: 1, background: tone.card, color: tone.cardFg, border: good ? `2px solid ${tone.line}` : `3px dashed ${RED}`, borderRadius: RADIUS, padding: '26px 34px', display: 'flex', flexDirection: 'column', gap: 16, minHeight: 200}}>
      <div style={{display: 'flex', alignItems: 'center', gap: 14, fontSize: 32, fontWeight: 700, color: good ? tone.cardFg : RED}}>
        <span style={{width: 48, height: 48, borderRadius: '50%', background: good ? (tone.name === 'dark' ? TONES.dark.chipBg : TONES.cream.chipBg) : RED, color: good ? (tone.name === 'dark' ? TONES.dark.chipFg : TONES.cream.chipFg) : '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
          <Icon k={good ? 'check' : 'cross'} size={28} />
        </span>
        {good ? 'সঠিক উপায়' : 'ভুল'}
      </div>
      {items.map((it, i) => (
        <Reveal key={i} at={t(it.at)} i={i} x={good ? 30 : -30} y={0} sfx={good ? 'tick' : 'pop'}>
          {it.a ? (
            <div style={{display: 'flex', alignItems: 'center', gap: 18, fontSize: 38, fontWeight: 600}}>
              <span>{it.a}</span><Icon k="arrow" size={34} color={RED} /><span style={{color: RED}}>{it.b}</span>
            </div>
          ) : (
            <div style={{fontSize: 40, fontWeight: 600, lineHeight: 1.3}}>{it.text}</div>
          )}
        </Reveal>
      ))}
    </div>
  );
  const cards = variant === 'stack' ? (
    <div style={{display: 'flex', gap: 30, flex: 1, alignItems: 'stretch'}}>{box(wrong, false)}{box(right, true)}</div>
  ) : (
    <div style={{display: 'flex', flexDirection: 'column', gap: 28, flex: 1, justifyContent: 'center'}}>{box(wrong, false)}{box(right, true)}</div>
  );
  return (
    <Content top={100} style={{flexDirection: variant === 'stack' ? 'column' : 'row', gap: variant === 'stack' ? 40 : 70, alignItems: variant === 'stack' ? 'stretch' : 'center', justifyContent: 'center'}}>
      {variant === 'flip' ? <>{cards}{head}</> : <>{head}{cards}</>}
    </Content>
  );
};

// ============ CTA: Like / Share / Subscribe ============
export const CTA: React.FC<{items: {at: TRef; label: string; kind: 'like' | 'share' | 'bell'}[]; title: {at: TRef; text: string}}> = ({items, title}) => {
  const {tone} = useScene();
  const t = useT();
  const f = useCurrentFrame();
  const glyph = (k: string) =>
    k === 'like' ? <path d="M7 22V11l5-9c2 0 3 1.4 3 3v4h5.5c1.3 0 2.2 1.2 1.9 2.4l-1.7 7.6c-.2 1-1.1 1.9-2.2 1.9H7zM2 11h3v11H2z" fill="currentColor" />
    : k === 'share' ? <path d="M4 12v7c0 1 1 2 2 2h12c1 0 2-1 2-2v-7M12 3v13M7 8l5-5 5 5" fill="none" stroke="currentColor" strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round" />
    : <path d="M12 2a6 6 0 00-6 6v4l-2 3v1h16v-1l-2-3V8a6 6 0 00-6-6zm-2 17a2 2 0 004 0z" fill="currentColor" />;
  return (
    <Content top={90} style={{justifyContent: 'center', alignItems: 'center', gap: 60}}>
      <Words text={title.text} at={t(title.at)} size={72} align="center" sfx="thud" />
      <div style={{display: 'flex', gap: 50}}>
        {items.map((it, i) => {
          const last = i === items.length - 1;
          const pulse = last ? 1 + Math.max(0, Math.sin(f / 7)) * 0.04 : 1;
          return (
            <Reveal key={i} at={t(it.at)} i={i} sfx={last ? 'chime' : 'pop'} y={50}>
              <div style={{width: 470, height: 330, borderRadius: 36, background: last ? TONES.dark.bg : '#fff', color: last ? '#fff' : TONES.dark.bg, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 20, transform: `scale(${pulse})`, border: `3px solid ${tone.line}`}}>
                <svg width={120} height={120} viewBox="0 0 24 24" style={{color: last ? RED : TONES.dark.bg}}>{glyph(it.kind)}</svg>
                <div style={{fontSize: 52, fontWeight: 700}}>{it.label}</div>
              </div>
            </Reveal>
          );
        })}
      </div>
    </Content>
  );
};
