import React from 'react';
import {interpolate, useCurrentFrame} from 'remotion';
import {FONT, RADIUS, TONES} from '../theme';
import {FPS, TRef} from '../timing';
import {Content, Icon, Reveal, Rich, Sfx, Words, useScene, useT} from './core';

const RED = TONES.dark.accent;
export type Verdict = 'ok' | 'bad' | 'ng' | 'ans';

// ===================== Rule scene =====================
export type VisualKind = 'options' | 'trio' | 'paragraphs' | 'match' | 'blanks' | 'kv' | 'table' | 'flow' | 'diagram' | 'qa';
export interface Bullet {at: TRef; text: string; tag?: string}

const Bar: React.FC<{w: number | string; h?: number; fill?: string}> = ({w, h = 14, fill}) => {
  const {tone} = useScene();
  return <div style={{width: w, height: h, borderRadius: h / 2, background: fill ?? tone.line}} />;
};
const Slot: React.FC<{w?: number; h?: number}> = ({w = 150, h = 48}) => (
  <div style={{width: w, height: h, borderRadius: 12, border: `3px dashed ${RED}`, flex: 'none'}} />
);
const Pill: React.FC<{text: string; dark?: boolean; red?: boolean; w?: number}> = ({text, dark, red, w}) => {
  const {tone} = useScene();
  return (
    <div style={{width: w, padding: '8px 22px', borderRadius: 40, fontSize: 28, fontWeight: 600, whiteSpace: 'nowrap', textAlign: 'center', background: red ? RED : dark ? TONES.dark.chipBg : 'transparent', color: red || dark ? (red ? '#fff' : TONES.dark.chipFg) : tone.cardFg, border: red || dark ? 'none' : `2px solid ${tone.line}`}}>{text}</div>
  );
};

const Visual: React.FC<{kind: VisualKind; labels?: string[]}> = ({kind, labels}) => {
  const {tone} = useScene();
  const f = useCurrentFrame();
  const P = (i: number, node: React.ReactNode, sfx = true) => (
    <Reveal key={i} at={12 + i * 7} i={i} y={18} sfx={sfx ? 'pop' : undefined} vol={0.2}>{node}</Reveal>
  );
  let body: React.ReactNode = null;
  if (kind === 'options') {
    body = (
      <div style={{display: 'flex', flexDirection: 'column', gap: 14, width: '100%'}}>
        {['A', 'B', 'C', 'D'].map((l, i) =>
          P(i, (
            <div style={{display: 'flex', alignItems: 'center', gap: 20}}>
              <div style={{width: 46, height: 46, borderRadius: '50%', background: i === 1 && f > 80 ? RED : 'transparent', border: `3px solid ${i === 1 && f > 80 ? RED : tone.line}`, color: i === 1 && f > 80 ? '#fff' : tone.cardFg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 26, fontWeight: 700}}>{l}</div>
              <Bar w={[620, 520, 580, 460][i]} />
            </div>
          )))}
      </div>
    );
  } else if (kind === 'trio') {
    const L = labels ?? ['TRUE', 'FALSE', 'NOT GIVEN'];
    body = (
      <div style={{display: 'flex', gap: 24, width: '100%', justifyContent: 'center'}}>
        {L.map((l, i) => P(i, (
          <div style={{width: 280, height: 190, borderRadius: 24, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 10, background: i === 0 ? TONES.dark.chipBg : i === 1 ? RED : 'transparent', color: i === 0 ? TONES.dark.chipFg : i === 1 ? '#fff' : tone.cardFg, border: i === 2 ? `3px solid ${tone.cardFg}` : 'none', fontSize: 38, fontWeight: 700}}>
            <Icon k={i === 0 ? 'check' : i === 1 ? 'cross' : 'q'} size={56} />{l}
          </div>
        )))}
      </div>
    );
  } else if (kind === 'paragraphs') {
    body = (
      <div style={{display: 'flex', gap: 40, width: '100%', alignItems: 'center'}}>
        <div style={{display: 'flex', flexDirection: 'column', gap: 12, flex: 1}}>
          {['A', 'B', 'C'].map((l, i) => P(i, (
            <div style={{display: 'flex', gap: 16, alignItems: 'center'}}>
              <Pill text={l} dark w={64} />
              <div style={{display: 'flex', flexDirection: 'column', gap: 8, flex: 1}}><Bar w="100%" /><Bar w="70%" /></div>
            </div>
          )))}
        </div>
        <Icon k="arrow" size={60} color={RED} />
        <div style={{display: 'flex', flexDirection: 'column', gap: 14, flex: 1}}>
          {['Heading i', 'Heading ii', 'Heading iii'].map((l, i) => P(i + 3, <Pill text={l} red={i === 1 && f > 70} />))}
        </div>
      </div>
    );
  } else if (kind === 'match') {
    body = (
      <div style={{display: 'flex', gap: 30, width: '100%', alignItems: 'center', justifyContent: 'center'}}>
        <div style={{display: 'flex', flexDirection: 'column', gap: 16}}>{['1', '2', '3'].map((l, i) => P(i, <Pill text={l} dark w={190} />))}</div>
        <div style={{display: 'flex', flexDirection: 'column', gap: 40}}>{[0, 1, 2].map((i) => P(i + 3, <Icon k="arrow" size={46} color={RED} />, false))}</div>
        <div style={{display: 'flex', flexDirection: 'column', gap: 16}}>{['A', 'B', 'C'].map((l, i) => P(i + 3, <Pill text={l} w={190} />))}</div>
      </div>
    );
  } else if (kind === 'blanks') {
    body = (
      <div style={{display: 'flex', flexDirection: 'column', gap: 30, width: '100%', alignItems: 'center'}}>
        {P(0, (
          <div style={{display: 'flex', alignItems: 'center', gap: 16}}><Bar w={220} h={18} /><Slot w={200} /><Bar w={260} h={18} /></div>
        ))}
        {P(2, <Pill text="Passage ➜ word" red />, false)}
      </div>
    );
  } else if (kind === 'kv') {
    body = (
      <div style={{display: 'flex', flexDirection: 'column', gap: 16, width: '100%'}}>
        {[0, 1, 2].map((i) => P(i, (
          <div style={{display: 'flex', alignItems: 'center', gap: 24}}><Bar w={260} h={18} /><Slot w={260} /></div>
        )))}
      </div>
    );
  } else if (kind === 'table') {
    body = (
      <div style={{display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, width: '100%'}}>
        {Array.from({length: 9}).map((_, i) => P(i, (
          <div style={{height: 64, borderRadius: 12, border: `2px solid ${tone.line}`, background: i < 3 ? tone.line : 'transparent', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
            {i === 4 || i === 8 ? <Slot w={120} h={34} /> : <Bar w={90} h={12} />}
          </div>
        ), false))}
      </div>
    );
  } else if (kind === 'flow') {
    body = (
      <div style={{display: 'flex', alignItems: 'center', gap: 14, width: '100%', justifyContent: 'center'}}>
        {[0, 1, 2, 3].map((i) => (
          <React.Fragment key={i}>
            {P(i, i === 2 ? <Slot w={190} h={110} /> : <div style={{width: 190, height: 110, borderRadius: 18, background: tone.line}} />)}
            {i < 3 ? <Icon k="arrow" size={40} color={RED} /> : null}
          </React.Fragment>
        ))}
      </div>
    );
  } else if (kind === 'diagram') {
    body = (
      <div style={{display: 'flex', alignItems: 'center', gap: 50, width: '100%', justifyContent: 'center'}}>
        {P(0, <div style={{width: 200, height: 200, borderRadius: '50%', background: tone.line}} />)}
        <div style={{display: 'flex', flexDirection: 'column', gap: 18}}>{[1, 2, 3].map((i) => P(i, (
          <div style={{display: 'flex', alignItems: 'center', gap: 12}}><Bar w={90} h={6} fill={RED} /><Slot w={230} h={46} /></div>
        )))}</div>
      </div>
    );
  } else {
    body = (
      <div style={{display: 'flex', flexDirection: 'column', gap: 20, width: '100%'}}>
        {P(0, <div style={{alignSelf: 'flex-start', background: tone.line, borderRadius: 26, padding: '16px 30px', fontSize: 34, fontWeight: 600}}>Who / When / Where ?</div>, true)}
        {P(1, <div style={{alignSelf: 'flex-end', background: RED, color: '#fff', borderRadius: 26, padding: '16px 30px', fontSize: 34, fontWeight: 700}}>অল্প কয়েকটি শব্দ</div>, true)}
      </div>
    );
  }
  return (
    <div style={{background: tone.card, border: `2px solid ${tone.line}`, borderRadius: RADIUS, height: 290, padding: '24px 34px', display: 'flex', alignItems: 'center', boxSizing: 'border-box', color: tone.cardFg}}>
      {body}
    </div>
  );
};

export const RuleScene: React.FC<{num: number; en: string; bn: string; visual: VisualKind; labels?: string[]; bullets: Bullet[]; at: TRef}> = ({num, en, bn, visual, labels, bullets, at}) => {
  const {tone} = useScene();
  const t = useT();
  const f = useCurrentFrame();
  const breathe = Math.sin(f / 24) * 4;
  return (
    <Content top={110} style={{flexDirection: 'row', gap: 60}}>
      <div style={{width: 600, flex: 'none', display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 14}}>
        <Reveal at={t(at)} y={0} sfx="thud">
          <div style={{fontSize: 210, fontWeight: 700, lineHeight: 0.95, color: tone.accent, transform: `translateY(${breathe}px)`}}>{String(num).padStart(2, '0')}</div>
        </Reveal>
        <Words text={en} at={t(at) + 4} size={70} line={1.1} />
        <Reveal at={t(at) + 14} y={20}>
          <div style={{fontSize: 38, fontWeight: 500, color: tone.sub}}>{bn}</div>
        </Reveal>
      </div>
      <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 24, justifyContent: 'center'}}>
        <Reveal at={t(at) + 6} y={30} sfx="pop"><Visual kind={visual} labels={labels} /></Reveal>
        <div style={{display: 'flex', flexDirection: 'column', gap: 10}}>
          {bullets.map((b, i) => (
            <Reveal key={i} at={t(b.at)} i={i} x={40} y={0} sfx="pop" vol={0.22}>
              <div style={{display: 'flex', alignItems: 'center', gap: 18, fontSize: 36, fontWeight: 600, lineHeight: 1.3, color: tone.fg}}>
                <span style={{flex: 'none', width: 14, height: 14, borderRadius: '50%', background: tone.accent}} />
                {b.tag ? <span style={{background: RED, color: '#fff', padding: '0 16px', borderRadius: 14, fontWeight: 700}}>{b.tag}</span> : null}
                <span>{b.text}</span>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </Content>
  );
};

// ===================== Stage: উদাহরণ + ব্যাখ্যা একই স্ক্রিনে =====================
export type LRow =
  | {k: 'lbl'; at: TRef; text: string}
  | {k: 'p'; at: TRef; text: string; hl?: TRef[]; fill?: {at: TRef; text: string}}
  | {k: 'opt'; at: TRef; letter: string; text: string; hl?: TRef[]; ok?: TRef}
  | {k: 'stmt'; at: TRef; n: number; text: string; hl?: TRef[]; active?: [TRef, TRef]; ans?: {at: TRef; label: string; tone: Verdict}; fill?: {at: TRef; text: string}}
  | {k: 'tiles'; at: TRef; items: string[]; dt: number; pick?: {idx: number; at: TRef}}
  | {k: 'table'; at: TRef; head: [string, string]; rows: {a: string; fill: {at: TRef; text: string}}[]; rowAt: TRef[]}
  | {k: 'flow'; boxes: {at: TRef; text: string; fill?: {at: TRef; text: string}}[]}
  | {k: 'plant'; at: TRef; labels: {at: TRef; text: string; y: number; fill: {at: TRef; text: string}}[]};

export type RRow =
  | {k: 'say'; at: TRef; until?: TRef; text: string}
  | {k: 'syn'; at: TRef; until?: TRef; a: string; b: string; bAt?: TRef; sep?: 'eq' | 'to'}
  | {k: 'verdict'; at: TRef; until?: TRef; label: string; tone: Verdict};

const Em: React.FC<{text: string}> = ({text}) => (
  <>
    {text.split(/(\[\[.+?\]\])/g).map((s, i) =>
      s.startsWith('[[') ? <span key={i} style={{color: RED, fontWeight: 700}}>{s.slice(2, -2)}</span> : <span key={i}>{s}</span>,
    )}
  </>
);

const VerdictChip: React.FC<{label: string; tone: Verdict; size?: number}> = ({label, tone, size = 54}) => {
  const bg = tone === 'ok' ? TONES.cream.chipBg : tone === 'ng' ? 'transparent' : RED;
  const fg = tone === 'ok' ? TONES.cream.chipFg : tone === 'ng' ? TONES.dark.bg : '#fff';
  return (
    <div style={{display: 'inline-flex', alignItems: 'center', gap: 14, background: bg, color: fg, border: tone === 'ng' ? `4px solid ${TONES.dark.bg}` : 'none', borderRadius: 24, padding: '8px 30px', fontSize: size, fontWeight: 700, lineHeight: 1.25}}>
      <Icon k={tone === 'bad' ? 'cross' : tone === 'ng' ? 'q' : 'check'} size={size * 0.8} />{label}
    </div>
  );
};

const LeftRow: React.FC<{row: LRow; i: number}> = ({row, i}) => {
  const {tone} = useScene();
  const t = useT();
  const f = useCurrentFrame();
  if (row.k === 'lbl') {
    return <Reveal at={t(row.at)} y={10} x={-16}><div style={{fontSize: 28, fontWeight: 700, color: RED, marginTop: 6}}>{row.text}</div></Reveal>;
  }
  if (row.k === 'p') {
    return <Reveal at={t(row.at)} y={16} sfx="pop" vol={0.18} i={i}><div style={{fontSize: 38, fontWeight: 500, color: tone.cardFg}}><Rich text={row.text} hl={row.hl} fill={row.fill} /></div></Reveal>;
  }
  if (row.k === 'opt') {
    const ok = row.ok !== undefined && f >= t(row.ok);
    return (
      <Reveal at={t(row.at)} y={14} sfx="pop" vol={0.2} i={i}>
        <div style={{display: 'flex', alignItems: 'center', gap: 20, padding: '8px 18px', borderRadius: 18, background: ok ? TONES.cream.chipBg : 'transparent', color: ok ? TONES.cream.chipFg : tone.cardFg, border: `2px solid ${ok ? TONES.cream.chipBg : tone.line}`, fontSize: 36, fontWeight: 500}}>
          <div style={{flex: 'none', width: 46, height: 46, borderRadius: '50%', background: ok ? RED : TONES.cream.chipBg, color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 26, fontWeight: 700}}>{ok ? <Icon k="check" size={28} /> : row.letter}</div>
          <Rich text={row.text} hl={row.hl} />
          {row.ok !== undefined ? <Sfx at={t(row.ok)} name="tick" /> : null}
        </div>
      </Reveal>
    );
  }
  if (row.k === 'stmt') {
    const act = row.active ? f >= t(row.active[0]) && f < t(row.active[1]) : false;
    return (
      <Reveal at={t(row.at)} y={14} sfx="pop" vol={0.2} i={i}>
        <div style={{display: 'flex', alignItems: 'center', gap: 18, padding: '10px 18px', borderRadius: 20, border: `3px solid ${act ? RED : 'transparent'}`, background: act ? 'rgba(226,26,30,0.07)' : 'transparent', fontSize: 36, fontWeight: 500, color: tone.cardFg}}>
          <div style={{flex: 'none', width: 62, height: 62, borderRadius: 16, background: TONES.cream.chipBg, color: TONES.cream.chipFg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28, fontWeight: 700}}>Q{row.n}</div>
          <div style={{flex: 1}}><Rich text={row.text} hl={row.hl} fill={row.fill} /></div>
          {row.ans ? <Reveal at={t(row.ans.at)} y={0} sfx="tick" i={i}><div style={{flex: 'none'}}><VerdictChip label={row.ans.label} tone={row.ans.tone} size={30} /></div></Reveal> : null}
        </div>
      </Reveal>
    );
  }
  if (row.k === 'tiles') {
    const picked = row.pick && f >= t(row.pick.at);
    return (
      <div style={{display: 'flex', gap: 16}}>
        {row.items.map((s, j) => {
          const on = picked && row.pick && row.pick.idx === j;
          return (
            <Reveal key={j} at={t(row.at) + Math.round(j * row.dt * FPS)} i={j} y={16} sfx="pop" vol={0.2} style={{flex: 1}}>
              <div style={{borderRadius: 20, padding: '16px 10px', textAlign: 'center', fontSize: 34, fontWeight: 700, background: on ? RED : 'transparent', color: on ? '#fff' : tone.cardFg, border: `3px solid ${on ? RED : tone.line}`, whiteSpace: 'nowrap'}}>{s}</div>
            </Reveal>
          );
        })}
      </div>
    );
  }
  if (row.k === 'table') {
    return (
      <div style={{display: 'flex', flexDirection: 'column', gap: 10}}>
        <Reveal at={t(row.at)} y={14} sfx="pop" vol={0.2}>
          <div style={{display: 'flex', gap: 10, fontSize: 30, fontWeight: 700}}>
            <div style={{flex: 1, padding: '10px 22px', borderRadius: 14, background: TONES.cream.chipBg, color: TONES.cream.chipFg}}>{row.head[0]}</div>
            <div style={{flex: 1, padding: '10px 22px', borderRadius: 14, background: TONES.cream.chipBg, color: TONES.cream.chipFg}}>{row.head[1]}</div>
          </div>
        </Reveal>
        {row.rows.map((r, j) => (
          <Reveal key={j} at={t(row.rowAt[j])} i={j} y={14} sfx="pop" vol={0.2}>
            <div style={{display: 'flex', gap: 10, fontSize: 36, fontWeight: 500}}>
              <div style={{flex: 1, padding: '8px 22px', borderRadius: 14, border: `2px solid ${tone.line}`}}>{r.a}</div>
              <div style={{flex: 1, padding: '8px 22px', borderRadius: 14, border: `2px solid ${tone.line}`}}><Rich text="[_]" fill={r.fill} /></div>
            </div>
          </Reveal>
        ))}
      </div>
    );
  }
  if (row.k === 'flow') {
    return (
      <div style={{display: 'flex', alignItems: 'center', gap: 10, marginTop: 6}}>
        {row.boxes.map((b, j) => (
          <React.Fragment key={j}>
            <Reveal at={t(b.at)} i={j} y={16} sfx="pop" vol={0.2} style={{flex: 1}}>
              <div style={{minHeight: 116, borderRadius: 20, padding: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', textAlign: 'center', fontSize: 30, fontWeight: 600, background: b.fill ? 'transparent' : TONES.cream.chipBg, color: b.fill ? tone.cardFg : TONES.cream.chipFg, border: b.fill ? `3px dashed ${RED}` : 'none'}}>
                {b.fill ? <Rich text="[_]" fill={b.fill} /> : b.text}
              </div>
            </Reveal>
            {j < row.boxes.length - 1 ? <Icon k="arrow" size={34} color={RED} /> : null}
          </React.Fragment>
        ))}
      </div>
    );
  }
  // plant
  const draw = interpolate(f, [t(row.at), t(row.at) + 20], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const D = TONES.dark.bg;
  return (
    <svg viewBox="0 0 1000 430" width="100%" style={{opacity: draw, fontFamily: FONT}}>
      <line x1={40} y1={290} x2={440} y2={290} stroke={D} strokeWidth={5} strokeLinecap="round" />
      <path d="M240 290 C 200 330, 170 370, 150 410 M240 290 L 240 410 M240 290 C 280 330, 310 370, 330 410" stroke={D} strokeWidth={6} fill="none" strokeLinecap="round" />
      <line x1={240} y1={290} x2={240} y2={110} stroke={D} strokeWidth={12} strokeLinecap="round" />
      <ellipse cx={170} cy={130} rx={80} ry={36} transform="rotate(-28 170 130)" fill={D} />
      <ellipse cx={315} cy={105} rx={85} ry={38} transform="rotate(24 315 105)" fill={D} />
      {row.labels.map((l, j) => {
        const at = t(l.at);
        const p = interpolate(f, [at, at + 10], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
        const fillP = f >= t(l.fill.at);
        const tx = l.y === 110 ? 300 : l.y === 210 ? 252 : 250;
        const ty = l.y === 110 ? 100 : l.y === 210 ? 210 : 370;
        return (
          <g key={j} opacity={p}>
            <line x1={tx} y1={ty} x2={500} y2={l.y} stroke={RED} strokeWidth={3} />
            <text x={510} y={l.y - 22} fontSize={30} fontWeight={600} fill={D}>{l.text}</text>
            <rect x={510} y={l.y - 8} width={330} height={56} rx={12} fill={fillP ? RED : 'none'} stroke={RED} strokeWidth={3} strokeDasharray={fillP ? undefined : '10 8'} />
            {fillP ? <text x={675} y={l.y + 32} fontSize={34} fontWeight={700} fill="#fff" textAnchor="middle">{l.fill.text}</text> : null}
          </g>
        );
      })}
    </svg>
  );
};

const RightRow: React.FC<{row: RRow; i: number}> = ({row, i}) => {
  const {tone} = useScene();
  const t = useT();
  const f = useCurrentFrame();
  const until = row.until !== undefined ? t(row.until) : undefined;
  if (row.k === 'say') {
    return (
      <Reveal at={t(row.at)} until={until} x={40} y={0} sfx="pop" vol={0.2} i={i}>
        <div style={{borderLeft: `8px solid ${RED}`, paddingLeft: 24, fontSize: 42, fontWeight: 600, lineHeight: 1.35, color: tone.fg}}><Em text={row.text} /></div>
      </Reveal>
    );
  }
  if (row.k === 'syn') {
    const bOn = f >= (row.bAt !== undefined ? t(row.bAt) : 0);
    return (
      <Reveal at={t(row.at)} until={until} x={40} y={0} sfx="pop" vol={0.2} i={i}>
        <div style={{display: 'flex', flexDirection: 'column', gap: 10, alignItems: 'flex-start'}}>
          <div style={{background: tone.card, color: tone.cardFg, border: `2px solid ${tone.line}`, borderRadius: 20, padding: '8px 24px', fontSize: 38, fontWeight: 600}}>{row.a}</div>
          {row.bAt !== undefined ? (
            <Reveal at={t(row.bAt)} y={12} sfx="click" i={i}>
              <div style={{display: 'flex', alignItems: 'center', gap: 14}}>
                <span style={{fontSize: 48, fontWeight: 700, color: RED, lineHeight: 1}}>{row.sep === 'to' ? '→' : '≈'}</span>
                <div style={{background: RED, color: '#fff', borderRadius: 20, padding: '8px 24px', fontSize: 38, fontWeight: 600}}>{row.b}</div>
              </div>
            </Reveal>
          ) : bOn ? null : null}
        </div>
      </Reveal>
    );
  }
  return (
    <Reveal at={t(row.at)} until={until} y={24} sfx="chime" vol={0.26} i={i}>
      <VerdictChip label={row.label} tone={row.tone} />
    </Reveal>
  );
};

export const StageScene: React.FC<{en: string; left: LRow[]; right: RRow[]}> = ({en, left, right}) => {
  const {tone} = useScene();
  const t = useT();
  return (
    <Content top={100} style={{flexDirection: 'row', gap: 40}}>
      <div style={{flex: 1.45, display: 'flex', flexDirection: 'column', minWidth: 0}}>
        <Reveal at={t(1)} y={0}>
          <div style={{display: 'flex', alignItems: 'center', gap: 16, marginBottom: 14}}>
            <span style={{background: RED, color: '#fff', fontSize: 30, fontWeight: 700, padding: '4px 22px', borderRadius: 30}}>Example</span>
            <span style={{fontSize: 34, fontWeight: 700, color: tone.fg}}>{en}</span>
          </div>
        </Reveal>
        <div style={{flex: 1, background: tone.card, border: `2px solid ${tone.line}`, borderRadius: RADIUS, padding: '26px 34px', display: 'flex', flexDirection: 'column', gap: 14, overflow: 'hidden'}}>
          {left.map((r, i) => <LeftRow key={i} row={r} i={i} />)}
        </div>
      </div>
      <div style={{flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0}}>
        <Reveal at={t(1)} y={0}>
          <div style={{display: 'flex', alignItems: 'center', gap: 16, marginBottom: 14}}>
            <span style={{background: tone.chipBg, color: tone.chipFg, fontSize: 30, fontWeight: 700, padding: '4px 22px', borderRadius: 30}}>ব্যাখ্যা</span>
          </div>
        </Reveal>
        <div style={{display: 'flex', flexDirection: 'column', gap: 26, paddingTop: 10}}>
          {right.map((r, i) => <RightRow key={i} row={r} i={i} />)}
        </div>
      </div>
    </Content>
  );
};
