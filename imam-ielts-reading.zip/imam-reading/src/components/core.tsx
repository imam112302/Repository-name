import React, {createContext, useContext} from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {EASE, FONT, PAD_X, SFX_VOL, SPR, Tone, TONES} from '../theme';
import {TRef, relFrame} from '../timing';

export type SfxName = 'pop' | 'click' | 'tick' | 'whoosh' | 'chime' | 'thud';

interface Ctx {from: number; dur: number; tone: Tone}
export const SceneCtx = createContext<Ctx>({from: 0, dur: 100, tone: TONES.dark});
export const useScene = () => useContext(SceneCtx);
export const useT = () => {
  const {from} = useScene();
  return (r: TRef) => relFrame(r, from);
};

// ---------- SFX ----------
export const Sfx: React.FC<{at: number; name: SfxName; vol?: number; rate?: number}> = ({at, name, vol = SFX_VOL, rate = 1}) => (
  <Sequence from={at} durationInFrames={30} layout="none">
    <Audio src={staticFile(`sfx/${name}.wav`)} volume={vol} playbackRate={rate} />
  </Sequence>
);
let _n = 0;
export const rateFor = (i: number) => [1, 1.06, 0.95][i % 3];

// ---------- Reveal ----------
export const Reveal: React.FC<{
  at: number; until?: number; x?: number; y?: number; sfx?: SfxName; vol?: number; i?: number;
  style?: React.CSSProperties; children: React.ReactNode;
}> = ({at, until, x = 0, y = 28, sfx, vol, i = 0, style, children}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  if (until !== undefined && f > until + 10) return null;
  const p = f < at ? 0 : spring({frame: f - at, fps, config: SPR.pop});
  const ex = until === undefined ? 0 : interpolate(f, [until, until + 9], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: EASE.in});
  const op = Math.min(1, p * 1.5) * (1 - ex);
  return (
    <>
      {sfx ? <Sfx at={at} name={sfx} vol={vol} rate={rateFor(i)} /> : null}
      <div style={{opacity: op, transform: `translate(${(1 - p) * x}px, ${(1 - p) * y - ex * 14}px) scale(${0.95 + 0.05 * p})`, ...style}}>
        {children}
      </div>
    </>
  );
};

// ---------- শব্দ ধরে স্ট্যাগার্ড (শুধু স্পেসে ভাঙে) ----------
export const parseAccent = (text: string): {w: string; a: boolean}[] => {
  const out: {w: string; a: boolean}[] = [];
  const re = /\[\[(.+?)\]\]/g;
  let last = 0; let m: RegExpExecArray | null;
  const push = (s: string, a: boolean) => s.split(' ').filter(Boolean).forEach((w) => out.push({w, a}));
  while ((m = re.exec(text))) {
    push(text.slice(last, m.index), false);
    push(m[1], true);
    last = m.index + m[0].length;
  }
  push(text.slice(last), false);
  return out;
};

export const Words: React.FC<{
  text: string; at: number; size: number; weight?: number; color?: string; accent?: string;
  gap?: number; align?: 'left' | 'center'; line?: number; sfx?: SfxName; stagger?: number;
}> = ({text, at, size, weight = 700, color, accent, gap = 4, align = 'left', line = 1.25, sfx, stagger = 4}) => {
  const {tone} = useScene();
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const words = parseAccent(text);
  return (
    <div style={{display: 'flex', flexWrap: 'wrap', columnGap: size * 0.28, rowGap: gap, justifyContent: align === 'center' ? 'center' : 'flex-start', fontSize: size, fontWeight: weight, lineHeight: line, color: color ?? tone.fg}}>
      {sfx ? <Sfx at={at} name={sfx} /> : null}
      {words.map((w, i) => {
        const s = at + i * stagger;
        const p = f < s ? 0 : spring({frame: f - s, fps, config: SPR.pop});
        return (
          <span key={i} style={{display: 'inline-block', opacity: Math.min(1, p * 1.6), transform: `translateY(${(1 - p) * 40}px) scale(${0.9 + 0.1 * p})`, color: w.a ? (accent ?? tone.accent) : undefined}}>
            {w.w}
          </span>
        );
      })}
    </div>
  );
};

// ---------- আইকন (SVG, থিমের রঙে) ----------
export const Icon: React.FC<{k: 'check' | 'cross' | 'arrow' | 'q' | 'dot'; size?: number; color?: string; stroke?: number}> = ({k, size = 32, color = 'currentColor', stroke = 4}) => {
  const d = {check: 'M5 13l4 4L19 7', cross: 'M6 6l12 12M18 6L6 18', arrow: 'M4 12h14M13 6l6 6-6 6', q: '', dot: ''}[k];
  if (k === 'q') return <span style={{fontSize: size, fontWeight: 700, lineHeight: 1, color}}>?</span>;
  if (k === 'dot') return <span style={{display: 'inline-block', width: size * 0.4, height: size * 0.4, borderRadius: '50%', background: color}} />;
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={stroke * 24 / size * 0.6} strokeLinecap="round" strokeLinejoin="round">
      <path d={d} />
    </svg>
  );
};

// ---------- Rich text: [[হাইলাইট]] এবং [_] ফাঁকা ----------
export const Rich: React.FC<{
  text: string; hl?: TRef[]; fill?: {at: TRef; text: string}; size?: number; weight?: number; color?: string;
}> = ({text, hl = [], fill, size, weight, color}) => {
  const {tone} = useScene();
  const t = useT();
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const parts: React.ReactNode[] = [];
  const re = /\[\[(.+?)\]\]|\[_\]/g;
  let last = 0; let k = 0; let m: RegExpExecArray | null;
  while ((m = re.exec(text))) {
    if (m.index > last) parts.push(<span key={`t${last}`}>{text.slice(last, m.index)}</span>);
    if (m[0] === '[_]') {
      const at = fill ? t(fill.at) : 99999;
      const p = f < at ? 0 : spring({frame: f - at, fps, config: SPR.pop});
      parts.push(
        <span key={`b${m.index}`} style={{display: 'inline-block', minWidth: 150, textAlign: 'center', borderBottom: p < 0.05 ? `4px dashed ${tone.cardSub}` : '4px solid transparent', background: p > 0.05 ? TONES.dark.accent : 'transparent', color: '#fff', borderRadius: 12, padding: p > 0.05 ? '0 16px' : '0 4px', transform: `scale(${0.8 + 0.2 * p})`}}>
          {fill && p > 0.05 ? fill.text : '\u00a0'}
          {sfxBlank(fill ? t(fill.at) : 0, !!fill)}
        </span>,
      );
    } else {
      const ref = hl[k]; k += 1;
      const at = ref === undefined ? 9 : t(ref);
      const p = f < at ? 0 : interpolate(f, [at, at + 10], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: EASE.out});
      parts.push(
        <span key={`h${m.index}`} style={{background: `linear-gradient(${TONES.dark.accent}, ${TONES.dark.accent}) no-repeat left center`, backgroundSize: `${p * 100}% 100%`, color: p > 0.4 ? '#fff' : undefined, borderRadius: 8, padding: '0 8px', margin: '0 -2px', boxDecorationBreak: 'clone', WebkitBoxDecorationBreak: 'clone'}}>
          {m[1]}
          {ref !== undefined ? <Sfx at={at} name="click" vol={0.2} /> : null}
        </span>,
      );
    }
    last = m.index + m[0].length;
  }
  if (last < text.length) parts.push(<span key="end">{text.slice(last)}</span>);
  return <span style={{fontSize: size, fontWeight: weight, color, lineHeight: 1.5}}>{parts}</span>;
};
const sfxBlank = (at: number, on: boolean) => (on ? <Sfx at={at} name="chime" vol={0.26} /> : null);

// ---------- Scene shell: ব্যাকগ্রাউন্ড wipe, ডেকো, এক্সিট, হেডার ----------
export const SceneShell: React.FC<{
  tone: Tone; prev: Tone | null; seed: number; typeIdx?: number; children: React.ReactNode;
}> = ({tone, prev, seed, typeIdx, children}) => {
  const f = useCurrentFrame();
  const {dur} = useScene();
  const wp = prev ? interpolate(f, [0, 13], [0, 1], {extrapolateRight: 'clamp', easing: EASE.inOut}) : 1;
  const ex = interpolate(f, [dur - 8, dur - 1], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: EASE.in});
  const sway = Math.sin(f / 50 + seed) * 18;
  const side = seed % 2 === 0;
  return (
    <AbsoluteFill style={{background: prev ? prev.bg : tone.bg, fontFamily: FONT}}>
      {prev ? <Sfx at={0} name="whoosh" vol={0.22} /> : null}
      <AbsoluteFill style={{background: tone.bg, clipPath: `inset(${(1 - wp) * 100}% 0 0 0)`, overflow: 'hidden'}}>
        <div style={{position: 'absolute', width: 760, height: 760, borderRadius: '50%', border: `3px solid ${tone.deco}`, [side ? 'right' : 'left']: -220, bottom: -260 + sway}} />
        <div style={{position: 'absolute', width: 260, height: 260, borderRadius: '50%', background: tone.deco, [side ? 'left' : 'right']: -90, top: -100 - sway}} />
        <div style={{position: 'absolute', left: PAD_X, bottom: 26, fontSize: 22, fontWeight: 600, color: tone.sub, opacity: 0.8}}>IMAM IELTS · Reading</div>
        {typeIdx !== undefined ? <TypeHeader idx={typeIdx} tone={tone} /> : null}
        <div style={{position: 'absolute', inset: 0, opacity: 1 - ex, transform: `translateY(${-ex * 26}px)`}}>{children}</div>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};

export const TYPE_COUNT = 14;
const TypeHeader: React.FC<{idx: number; tone: Tone}> = ({idx, tone}) => (
  <div style={{position: 'absolute', top: 34, left: PAD_X, right: PAD_X, height: 40, display: 'flex', alignItems: 'center', gap: 20}}>
    <div style={{fontSize: 30, fontWeight: 700, color: tone.accent === tone.bg ? tone.fg : tone.fg, minWidth: 110}}>
      {String(idx + 1).padStart(2, '0')} <span style={{color: tone.sub, fontWeight: 500}}>/ {TYPE_COUNT}</span>
    </div>
    <div style={{display: 'flex', gap: 8, flex: 1}}>
      {Array.from({length: TYPE_COUNT}).map((_, i) => (
        <div key={i} style={{flex: 1, height: 8, borderRadius: 4, background: i <= idx ? tone.fg : tone.line}} />
      ))}
    </div>
  </div>
);

export const Content: React.FC<{children: React.ReactNode; top?: number; style?: React.CSSProperties}> = ({children, top = 110, style}) => (
  <div style={{position: 'absolute', left: PAD_X, right: PAD_X, top, bottom: 70, display: 'flex', flexDirection: 'column', ...style}}>{children}</div>
);

export const nextN = () => (_n += 1);
