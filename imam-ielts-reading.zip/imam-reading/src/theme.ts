import {Easing} from 'remotion';
import {loadFont} from '@remotion/google-fonts/HindSiliguri';

// ফন্ট: যুক্তাক্ষর ঠিক আসে এমন Hind Siliguri (বাংলা + ল্যাটিন)
const {fontFamily: hind} = loadFont('normal', {
  weights: ['400', '500', '600', '700'],
  subsets: ['bengali', 'latin'],
});
export const FONT = `${hind}, 'Hind Siliguri', 'Noto Sans Bengali', sans-serif`;

// তিনটা ফ্ল্যাট রঙ + সাদা। কোনো গ্রেডিয়েন্ট নেই।
export const C = {
  dark: '#15110D',
  cream: '#F5F1ED',
  red: '#E21A1E',
  white: '#FFFFFF',
  mute: '#B8B4A8',
} as const;

export type ToneName = 'dark' | 'cream' | 'red';
export interface Tone {
  name: ToneName;
  bg: string;
  fg: string; // সরাসরি ব্যাকগ্রাউন্ডের ওপর লেখা
  sub: string; // ছোট/হালকা লেখা
  accent: string; // ব্যাকগ্রাউন্ডের ওপর জোর দেওয়ার রং
  card: string;
  cardFg: string;
  cardSub: string;
  line: string;
  deco: string;
  chipBg: string;
  chipFg: string;
}

export const TONES: Record<ToneName, Tone> = {
  dark: {
    name: 'dark', bg: C.dark, fg: C.cream, sub: C.mute, accent: C.red,
    card: 'rgba(245,241,237,0.09)', cardFg: C.cream, cardSub: C.mute,
    line: 'rgba(245,241,237,0.2)', deco: 'rgba(245,241,237,0.06)', chipBg: C.cream, chipFg: C.dark,
  },
  cream: {
    name: 'cream', bg: C.cream, fg: C.dark, sub: 'rgba(21,17,13,0.62)', accent: C.red,
    card: C.white, cardFg: C.dark, cardSub: 'rgba(21,17,13,0.62)',
    line: 'rgba(21,17,13,0.16)', deco: 'rgba(21,17,13,0.06)', chipBg: C.dark, chipFg: C.cream,
  },
  red: {
    name: 'red', bg: C.red, fg: C.white, sub: 'rgba(255,255,255,0.85)', accent: C.dark,
    card: C.white, cardFg: C.dark, cardSub: 'rgba(21,17,13,0.62)',
    line: 'rgba(255,255,255,0.4)', deco: 'rgba(255,255,255,0.1)', chipBg: C.dark, chipFg: C.white,
  },
};

// মোশন-ব্যক্তিত্ব: সব জায়গায় একই
export const EASE = {
  out: Easing.bezier(0.16, 1, 0.3, 1),
  inOut: Easing.bezier(0.65, 0, 0.35, 1),
  in: Easing.bezier(0.5, 0, 0.75, 0),
};
export const SPR = {
  pop: {damping: 15, stiffness: 170, mass: 0.8},
  soft: {damping: 22, stiffness: 120, mass: 1},
  snap: {damping: 18, stiffness: 240, mass: 0.7},
};

export const RADIUS = 28;
export const SFX_VOL = 0.28;
export const PAD_X = 80;
