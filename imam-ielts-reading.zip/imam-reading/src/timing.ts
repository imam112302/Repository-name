import {CUES} from './cues';

export const FPS = 30;
export const W = 1920;
export const H = 1080;

// সময়-সূত্র: cue নম্বর, অথবা [cue নম্বর, অফসেট সেকেন্ড]
export type TRef = number | [number, number];

export const secOf = (r: TRef): number =>
  typeof r === 'number' ? CUES[r - 1][1] : CUES[r[0] - 1][1] + r[1];

export const LEAD = 5; // ভিজ্যুয়াল কথার ৪-৬ ফ্রেম আগে ঢোকে
export const MIN_ENTER = 9; // স্ক্রিন-র‍্যাপ শেষ না হওয়া পর্যন্ত কনটেন্ট ঢোকে না
export const sceneStart = (cue: number): number => Math.round(CUES[cue - 1][1] * FPS);
export const TOTAL = Math.round(CUES[CUES.length - 1][2] * FPS);

// scene-র শুরু থেকে হিসাব করা রিলেটিভ ফ্রেম
export const relFrame = (r: TRef, sceneFrom: number): number =>
  Math.max(MIN_ENTER, Math.round(secOf(r) * FPS) - LEAD - sceneFrom);
