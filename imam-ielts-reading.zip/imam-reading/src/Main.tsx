import React from 'react';
import {AbsoluteFill, Sequence} from 'remotion';
import {SCENES, TYPES} from './content';
import {SceneCtx, SceneShell} from './components/core';
import {CTA, Cards, Grid, Hero, Hub, Mistake} from './components/templates';
import {RuleScene, StageScene} from './components/typeScenes';
import {PreviewAudio} from './PreviewAudio';
import {TONES} from './theme';
import {TOTAL, sceneStart} from './timing';

const SHORT = ['MCQ', 'True/False/NG', 'Yes/No/NG', 'Headings', 'Information', 'Features', 'Sentence Endings', 'Sentence', 'Summary', 'Note', 'Table', 'Flow Chart', 'Diagram', 'Short Answer'];
void TYPES;

export const Main: React.FC = () => {
  return (
    <AbsoluteFill style={{background: TONES.dark.bg}}>
      {SCENES.map((s, i) => {
        const from = i === 0 ? 0 : sceneStart(s.a);
        const end = i + 1 < SCENES.length ? sceneStart(SCENES[i + 1].a) : TOTAL;
        const dur = end - from;
        const tone = TONES[s.tone];
        const prev = i === 0 ? null : TONES[SCENES[i - 1].tone];
        return (
          <Sequence key={i} from={from} durationInFrames={dur}>
            <SceneCtx.Provider value={{from, dur, tone}}>
              <SceneShell tone={tone} prev={prev} seed={i} typeIdx={s.typeIdx}>
                {s.kind === 'hero' && <Hero lines={s.lines} />}
                {s.kind === 'cards' && <Cards label={s.label} headline={s.headline} headSize={s.headSize} cards={s.cards} cols={s.cols} cardSize={s.cardSize} />}
                {s.kind === 'grid' && <Grid title={s.title} titleSize={s.titleSize} tiles={s.tiles} cols={s.cols} mode={s.mode} tileH={s.tileH} fs={s.fs} />}
                {s.kind === 'hub' && (
                  <Hub
                    center="IELTS" centerSub="Reading"
                    title={{at: 7, text: 'বিভিন্ন ধরনের প্রশ্ন'}}
                    caption={{at: 8, text: 'প্রতিটির নিয়ম আলাদা'}}
                    nodes={SHORT.map((t, k) => ({at: [7, 0.3 + k * 0.3] as [number, number], text: t}))}
                  />
                )}
                {s.kind === 'mistake' && <Mistake n={s.n} title={s.title} sub={s.sub} wrong={s.wrong} right={s.right} variant={s.variant} at={s.a} />}
                {s.kind === 'cta' && (
                  <CTA
                    title={{at: 378, text: 'ভিডিওটি ভালো লাগলে'}}
                    items={[
                      {at: 378, label: 'Like', kind: 'like'},
                      {at: 379, label: 'Share', kind: 'share'},
                      {at: 380, label: 'Subscribe', kind: 'bell'},
                    ]}
                  />
                )}
                {s.kind === 'rule' && <RuleScene num={s.num} en={s.en} bn={s.bn} visual={s.visual} labels={s.labels} bullets={s.bullets} at={s.a} />}
                {s.kind === 'stage' && <StageScene en={s.en} left={s.left} right={s.right} />}
              </SceneShell>
            </SceneCtx.Provider>
          </Sequence>
        );
      })}
      <PreviewAudio />
    </AbsoluteFill>
  );
};
