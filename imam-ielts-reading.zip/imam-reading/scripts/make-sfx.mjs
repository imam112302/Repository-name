// Zero-download SFX synth: soft pop / click / tick / whoosh / chime / thud  (16-bit mono WAV, 44.1k)
import fs from "node:fs";
const SR = 44100;
const out = "public/sfx";
fs.mkdirSync(out, { recursive: true });

const env = (t, a, d) => Math.min(1, t / a) * Math.exp(-t / d);
const lp = (x, c) => { let y = 0; return x.map((v) => (y += c * (v - y))); };          // one-pole low-pass
const hp = (x, c) => { const l = lp(x, c); return x.map((v, i) => v - l[i]); };           // high-pass = x - lp
let seed = 7; const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647) * 2 - 1;
const gen = (len, fn) => Array.from({ length: Math.floor(len * SR) }, (_, i) => fn(i / SR, i));
const norm = (x, peak = 0.8) => { const m = Math.max(...x.map(Math.abs)); return x.map((v) => (v / m) * peak); };
const fade = (x, ms = 6) => { const n = Math.floor((ms / 1000) * SR); return x.map((v, i) => v * Math.min(1, i / n, (x.length - i) / n)); };
const wav = (name, x0) => {
  const x = norm(x0, 0.75);
  const b = Buffer.alloc(44 + x.length * 2);
  b.write("RIFF", 0); b.writeUInt32LE(36 + x.length * 2, 4); b.write("WAVEfmt ", 8);
  b.writeUInt32LE(16, 16); b.writeUInt16LE(1, 20); b.writeUInt16LE(1, 22);
  b.writeUInt32LE(SR, 24); b.writeUInt32LE(SR * 2, 28); b.writeUInt16LE(2, 32); b.writeUInt16LE(16, 34);
  b.write("data", 36); b.writeUInt32LE(x.length * 2, 40);
  x.forEach((v, i) => b.writeInt16LE(Math.round(Math.max(-1, Math.min(1, v)) * 32767), 44 + i * 2));
  fs.writeFileSync(`${out}/${name}.wav`, b);
};

// pop: sine, pitch drops fast
{ let ph = 0; const x = gen(0.26, (t) => { const f = 180 + 520 * Math.exp(-t * 22); ph += (2 * Math.PI * f) / SR; return Math.sin(ph) * env(t, 0.004, 0.06); });
  wav("pop", fade(lp(norm(x), 0.6))); }
// click: high-passed noise burst + tiny tick
{ const n = gen(0.12, (t) => rnd() * env(t, 0.001, 0.012)); const h = hp(n, 0.25);
  const x = h.map((v, i) => v + Math.sin(2 * Math.PI * 1900 * (i / SR)) * env(i / SR, 0.001, 0.02) * 0.5);
  wav("click", fade(lp(norm(x), 0.7))); }
// tick (check mark): soft two-note
{ const x = gen(0.22, (t) => (Math.sin(2 * Math.PI * 1320 * t) * env(t, 0.003, 0.05) + (t > 0.06 ? Math.sin(2 * Math.PI * 1760 * (t - 0.06)) * env(t - 0.06, 0.003, 0.06) : 0)) * 0.6);
  wav("tick", fade(lp(norm(x), 0.55))); }
// whoosh: band-passed noise sweep, fade in/out
{ const len = 0.65; let lo = 0, bd = 0;
  const x = gen(len, (t) => { const f = 350 + 2600 * Math.pow(t / len, 1.6); const k = 2 * Math.sin(Math.PI * Math.min(0.45, f / SR));
    const nz = rnd(); const hi = nz - lo - 0.55 * bd; bd += k * hi; lo += k * bd;
    const w = Math.sin(Math.PI * (t / len)); return bd * w * w; });
  wav("whoosh", fade(lp(norm(x), 0.5), 20)); }
// chime / pluck: soft overtones
{ const x = gen(0.55, (t) => (Math.sin(2 * Math.PI * 880 * t) + 0.35 * Math.sin(2 * Math.PI * 1320 * t) + 0.18 * Math.sin(2 * Math.PI * 1760 * t)) * env(t, 0.004, 0.12));
  wav("chime", fade(lp(norm(x), 0.5), 10)); }
// thud: very soft low hit for hook / key message
{ let ph = 0; const x = gen(0.38, (t) => { const f = 48 + 70 * Math.exp(-t * 18); ph += (2 * Math.PI * f) / SR; return Math.sin(ph) * env(t, 0.006, 0.1); });
  wav("thud", fade(lp(norm(x), 0.2), 8)); }
console.log("done");
