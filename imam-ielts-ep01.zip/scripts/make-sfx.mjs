// Deterministic SFX synth: 7 short, soft, modern UI/motion-graphics sounds -> public/sfx/*.wav
import fs from 'fs';
const SR = 44100;
let seed = 1234567;
const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296 * 2 - 1; };
const buf = (sec) => new Float32Array(Math.floor(sec * SR));
const lp = (x, fc) => { const a = Math.exp(-2 * Math.PI * fc / SR); let y = 0; for (let i = 0; i < x.length; i++) { y = (1 - a) * x[i] + a * y; x[i] = y; } return x; };
const hp = (x, fc) => { const a = Math.exp(-2 * Math.PI * fc / SR); let y = 0; for (let i = 0; i < x.length; i++) { y = (1 - a) * x[i] + a * y; x[i] = x[i] - y; } return x; };
const reverb = (x, wet = 0.14) => { // very small reverb: 4 soft taps
  const out = Float32Array.from(x);
  for (const [ms, g] of [[19, 0.5], [37, 0.35], [53, 0.25], [79, 0.15]]) {
    const d = Math.floor(ms / 1000 * SR);
    for (let i = d; i < x.length; i++) out[i] += x[i - d] * g * wet * 2;
  }
  return out;
};
const fadeEnds = (x, a = 0.004, b = 0.012) => { const na = a * SR, nb = b * SR; for (let i = 0; i < na; i++) x[i] *= i / na; for (let i = 0; i < nb; i++) x[x.length - 1 - i] *= i / nb; return x; };
const svf = (x, freqFn, q) => { // band-pass state-variable filter with swept centre
  let low = 0, band = 0; const out = new Float32Array(x.length);
  for (let i = 0; i < x.length; i++) { const f = 2 * Math.sin(Math.PI * freqFn(i / SR) / SR); const high = x[i] - low - q * band; band += f * high; low += f * band; out[i] = band; }
  return out;
};
const sound = {
  pop() { const x = buf(0.22); let ph = 0; for (let i = 0; i < x.length; i++) { const t = i / SR; const f = 180 + 340 * Math.exp(-t * 38); ph += 2 * Math.PI * f / SR; x[i] = Math.sin(ph) * Math.min(1, t / 0.003) * Math.exp(-t * 22); } return lp(x, 5200); },
  click() { const x = buf(0.12); for (let i = 0; i < x.length; i++) { const t = i / SR; x[i] = rnd() * Math.exp(-t * 260) * 0.8 + Math.sin(2 * Math.PI * 1900 * t) * Math.exp(-t * 200) * 0.5; } return lp(hp(x, 1800), 9000); },
  tick() { const x = buf(0.07); for (let i = 0; i < x.length; i++) { const t = i / SR; x[i] = Math.sin(2 * Math.PI * 2600 * t) * Math.exp(-t * 130) * Math.min(1, t / 0.0015); } return lp(x, 7000); },
  whoosh() { const L = 0.62, n = buf(L).map(() => rnd()); const y = svf(n, (t) => 380 + 2600 * Math.pow(t / L, 1.4), 0.9); for (let i = 0; i < y.length; i++) { const p = i / y.length; y[i] *= Math.pow(Math.sin(Math.PI * Math.min(1, p * 1.0)), 2) * (p < 0.4 ? 1 : 0.9); } return lp(y, 6500); },
  swipe() { const L = 0.45, n = buf(L).map(() => rnd()); const y = svf(n, (t) => 700 + 3400 * Math.pow(t / L, 1.1), 0.7); for (let i = 0; i < y.length; i++) { const p = i / y.length; y[i] *= Math.pow(Math.sin(Math.PI * Math.pow(p, 0.7)), 2); } return lp(y, 7500); },
  chime() { const x = buf(0.5); for (let i = 0; i < x.length; i++) { const t = i / SR; const e = Math.min(1, t / 0.005) * Math.exp(-t * 7.5); x[i] = (Math.sin(2 * Math.PI * 880 * t) + 0.32 * Math.sin(2 * Math.PI * 1760 * t) * Math.exp(-t * 6) + 0.12 * Math.sin(2 * Math.PI * 2640 * t) * Math.exp(-t * 9)) * e; } return lp(x, 6500); },
  thud() { const x = buf(0.34); let ph = 0; for (let i = 0; i < x.length; i++) { const t = i / SR; const f = 55 + 55 * Math.exp(-t * 28); ph += 2 * Math.PI * f / SR; x[i] = Math.sin(ph) * Math.min(1, t / 0.004) * Math.exp(-t * 13); } return lp(x, 380); },
};
const wav = (x) => { const b = Buffer.alloc(44 + x.length * 2); b.write('RIFF', 0); b.writeUInt32LE(36 + x.length * 2, 4); b.write('WAVEfmt ', 8); b.writeUInt32LE(16, 16); b.writeUInt16LE(1, 20); b.writeUInt16LE(1, 22); b.writeUInt32LE(SR, 24); b.writeUInt32LE(SR * 2, 28); b.writeUInt16LE(2, 32); b.writeUInt16LE(16, 34); b.write('data', 36); b.writeUInt32LE(x.length * 2, 40); for (let i = 0; i < x.length; i++) b.writeInt16LE(Math.round(Math.max(-1, Math.min(1, x[i])) * 32767), 44 + i * 2); return b; };
fs.mkdirSync(new URL('../public/sfx/', import.meta.url), { recursive: true });
const TARGET_PEAK = 0.85;
for (const [name, fn] of Object.entries(sound)) {
  let x = fadeEnds(reverb(fn(), name === 'click' || name === 'tick' ? 0.06 : 0.12));
  x = lp(x, 8000);
  let peak = 0; for (const v of x) peak = Math.max(peak, Math.abs(v));
  const g = TARGET_PEAK / peak; for (let i = 0; i < x.length; i++) x[i] *= g;
  let p2 = 0, s = 0; for (const v of x) { p2 = Math.max(p2, Math.abs(v)); s += v * v; }
  fs.writeFileSync(new URL(`../public/sfx/${name}.wav`, import.meta.url), wav(x));
  console.log(name.padEnd(7), 'len', (x.length / SR).toFixed(2) + 's', 'peak', p2.toFixed(3), 'rms', Math.sqrt(s / x.length).toFixed(3), p2 >= 0.99 ? 'CLIPPING!' : 'ok');
}
