// Flags
export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;
// public/voiceover.mp3 থাকলে Studio প্রিভিউতে বাজবে। রেন্ডারে ডিফল্টে বন্ধ।
export const VOICEOVER_PREVIEW = true;
export const VOICEOVER_IN_RENDER = false;
// SFX চালু/বন্ধ
export const SFX_ENABLED = true;
// Studio/রেন্ডার শেষে SRT-এর পর অতিরিক্ত ফ্রেম
export const TAIL_FRAMES = 30;
