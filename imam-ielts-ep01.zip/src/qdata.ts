import {HiSpec, Mark} from './ui';
import {T, cs, at} from './timing';

export type Ans = 'TRUE' | 'FALSE' | 'NOT GIVEN';
export type Tn = 'neutral' | 'ok' | 'bad';
export type St = {t: number; text: string; tone?: Tn};
export type Rel = {t: number; sym: '=' | '≠' | '?' | '✕' | '✓'};
export type Row = {q?: St[]; p?: St[]; rel?: Rel[]};

export type QData = {
  n: 1 | 2 | 3 | 4 | 5;
  statement: string;
  answer: Ans;
  cue: {q: number; r1: number; r2: number; r3: number; r4: number; r5: number; ans: number; end: number};
  read: St[]; // R1 meaning segments
  readSweep: [number, number]; // cue range for the "reading" underline
  kws: {chip: string; phrase: string; t: number}[];
  para: {n: 1 | 2 | 3 | 4 | 5; t: number};
  evidence: {t: number; text: string; kind: 'quote' | 'fact'}[];
  pMarks: HiSpec[]; // passage highlights (without 'off' – added in Workspace)
  sMarks: HiSpec[]; // statement extra highlights (strong)
  compare: {rows: Row[]; footer: St[]};
  ansT: number;
  reason: St;
  note?: {t: number; title: string; lines: St[]};
};

const ev = (t: number): Mark => ({t, kind: 'ev'});
const strong = (t: number): Mark => ({t, kind: 'strong'});

export const QS: QData[] = [
  {
    n: 1,
    statement: 'The population of Dar es Salaam is rising more rapidly than was previously predicted.',
    answer: 'NOT GIVEN',
    cue: {q: 53, r1: 56, r2: 61, r3: 64, r4: 73, r5: 82, ans: 83, end: 92},
    read: [
      {t: T(58), text: 'Dar es Salaam-এর Population'},
      {t: T(59), text: 'আগের Prediction-এর'},
      {t: T(60), text: 'চেয়েও দ্রুত বৃদ্ধি পাচ্ছে।'},
    ],
    readSweep: [57, 57],
    kws: [
      {chip: 'Population', phrase: 'population', t: T(63, 0, 3)},
      {chip: 'Rising More Rapidly', phrase: 'rising more rapidly', t: T(63, 1, 3)},
      {chip: 'Previously Predicted', phrase: 'previously predicted', t: T(63, 2, 3)},
    ],
    para: {n: 1, t: T(66)},
    evidence: [
      {t: T(67), text: '1980 সাল থেকে আট গুণ বেড়েছে', kind: 'fact'},
      {t: T(69), text: 'প্রতি বছর আরও প্রায় পাঁচ লাখ মানুষ', kind: 'fact'},
      {t: T(71), text: 'United Nations Projection: ১০ মিলিয়ন ছাড়িয়ে যাবে', kind: 'fact'},
    ],
    pMarks: [
      {target: 'increased eightfold since 1980', marks: [ev(T(67))]},
      {target: 'swells by half a million people every year', marks: [ev(T(69))]},
      {target: 'United Nations projections anticipate it will become a megacity within seven years as its population passes 10 million', marks: [ev(T(71))]},
    ],
    sMarks: [{target: 'previously predicted', marks: [strong(T(74))]}],
    compare: {
      rows: [
        {
          q: [{t: T(74), text: 'আগের Prediction-এর চেয়েও দ্রুত'}],
          rel: [{t: T(76), sym: '?'}, {t: T(78), sym: '✕'}],
          p: [{t: T(76), text: 'Comparison আছে কি?'}, {t: T(78), text: 'না।', tone: 'bad'}, {t: T(80), text: 'তুলনা বলা হয়নি', tone: 'bad'}],
        },
        {
          q: [{t: T(79), text: 'Population Growth'}],
          rel: [{t: T(79), sym: '✓'}],
          p: [{t: T(79), text: 'Growth ও Future Projection দেওয়া আছে', tone: 'ok'}],
        },
      ],
      footer: [],
    },
    ansT: at(83, 1, 2) - 5,
    reason: {t: T(84), text: 'Growth-এর তথ্য আছে, কিন্তু আগের Prediction-এর তুলনার Information নেই'},
    note: {
      t: T(87),
      title: 'মনে রাখবে',
      lines: [
        {t: T(88), text: 'দ্রুত বাড়ছে বলেই Answer TRUE হবে না'},
        {t: T(90), text: 'Question যে Comparison দাবি করছে, Passage-এ সেই Comparison থাকতে হবে'},
      ],
    },
  },
  {
    n: 2,
    statement: 'Most of the residents of Dar es Salaam live in high-rise blocks on the edge of the city.',
    answer: 'FALSE',
    cue: {q: 92, r1: 96, r2: 99, r3: 102, r4: 107, r5: 115, ans: 116, end: 123},
    read: [
      {t: T(97), text: 'Dar es Salaam-এর অধিকাংশ মানুষ'},
      {t: T(98), text: 'শহরের প্রান্তে High-rise Buildings-এ বসবাস করে।'},
    ],
    readSweep: [96, 96],
    kws: [
      {chip: 'Most of the Residents', phrase: 'most of the residents', t: T(101, 0, 3)},
      {chip: 'High-rise Blocks', phrase: 'high-rise blocks', t: T(101, 1, 3)},
      {chip: 'Edge of the City', phrase: 'edge of the city', t: T(101, 2, 3)},
    ],
    para: {n: 2, t: T(104)},
    evidence: [{t: T(106), text: 'Four out of five of its people live in single-storey informal settlements.', kind: 'quote'}],
    pMarks: [{ctx: 'four out of five of its people live in single-storey informal settlements', target: 'four out of five of its people live in single-storey informal settlements', marks: [ev(T(106))]},
      {ctx: 'four out of five of its people live in single-storey informal settlements', target: 'single-storey informal settlements', marks: [strong(T(109))]}],
    sMarks: [{target: 'high-rise blocks', marks: [strong(T(108))]}],
    compare: {
      rows: [
        {
          q: [{t: T(108), text: 'High-rise Blocks'}],
          rel: [{t: T(110), sym: '≠'}],
          p: [{t: T(109), text: 'Single-storey Informal Settlements'}],
        },
      ],
      footer: [
        {t: T(111), text: 'সম্পূর্ণ বিপরীত Building Structure'},
        {t: T(113), text: 'Contradict', tone: 'bad'},
      ],
    },
    ansT: at(116, 1, 2) - 5,
    reason: {t: T(117), text: 'Question-এ High-rise Buildings, কিন্তু Passage-এ Single-storey Settlements'},
    note: {
      t: T(120),
      title: 'মনে রাখবে',
      lines: [
        {t: T(120), text: 'পুরো Paragraph মুখস্থ করার দরকার নেই'},
        {t: T(121), text: 'Relevant Information খুঁজে Statement-এর সঙ্গে Compare করো'},
      ],
    },
  },
  {
    n: 3,
    statement: 'Residents have been consulted about their views on the suburban rail line in Dar es Salaam.',
    answer: 'NOT GIVEN',
    cue: {q: 123, r1: 127, r2: 130, r3: 133, r4: 140, r5: 147, ans: 148, end: 156},
    read: [
      {t: T(128), text: 'Suburban Rail Line সম্পর্কে'},
      {t: T(129), text: 'Residents-দের মতামত নেওয়া হয়েছে।'},
    ],
    readSweep: [127, 127],
    kws: [
      {chip: 'Residents', phrase: 'residents', t: T(132, 0, 4)},
      {chip: 'Consulted', phrase: 'consulted', t: T(132, 1, 4)},
      {chip: 'Their Views', phrase: 'their views', t: T(132, 2, 4)},
      {chip: 'Suburban Rail Line', phrase: 'suburban rail line', t: T(132, 3, 4)},
    ],
    para: {n: 3, t: T(135)},
    evidence: [
      {t: T(137), text: 'A single suburban rail line serves residents in a few areas to the south.', kind: 'quote'},
      {t: T(138), text: 'দক্ষিণের কয়েকটি এলাকার মানুষ Rail Line ব্যবহার করতে পারে', kind: 'fact'},
    ],
    pMarks: [{target: 'A single suburban rail line serves residents in a few areas to the south', marks: [ev(T(137))]}],
    sMarks: [{target: 'consulted', marks: [strong(T(145))]}, {target: 'their views', marks: [strong(T(145))]}],
    compare: {
      rows: [
        {
          q: [{t: T(141), text: 'Residents-দের মতামত নেওয়া হয়েছে কি?'}],
          rel: [{t: T(143), sym: '?'}, {t: T(145), sym: '✕'}],
          p: [{t: T(143), text: 'শুধু Rail Line-এর অস্তিত্ব ও Service Area'}],
        },
      ],
      footer: [{t: T(145), text: 'মতামতের Information নেই', tone: 'bad'}],
    },
    ansT: at(148, 1, 2) - 5,
    reason: {t: T(149), text: 'Residents-দের Consult করার বিষয়ে Passage-এ কোনো Information নেই'},
    note: {
      t: T(151),
      title: 'Common Mistake',
      lines: [
        {t: T(152), text: 'Rail Line আছে ≠ মতামত নেওয়া হয়েছে'},
        {t: T(154), text: 'Passage-এ নেই এমন Information নিজে তৈরি করা যাবে না'},
      ],
    },
  },
  {
    n: 4,
    statement: 'The majority of the present residential development in Dar es Salaam is unplanned.',
    answer: 'TRUE',
    cue: {q: 156, r1: 160, r2: 163, r3: 166, r4: 170, r5: 182, ans: 183, end: 191},
    read: [
      {t: T(161), text: 'বর্তমান Residential Development-এর'},
      {t: T(162), text: 'অধিকাংশই Unplanned।'},
    ],
    readSweep: [160, 160],
    kws: [
      {chip: 'Majority', phrase: 'majority', t: T(165, 0, 3)},
      {chip: 'Present Residential Development', phrase: 'present residential development', t: T(165, 1, 3)},
      {chip: 'Unplanned', phrase: 'unplanned', t: T(165, 2, 3)},
    ],
    para: {n: 4, t: T(167)},
    evidence: [{t: T(169), text: 'Nearly all takes place informally without any agreed strategy.', kind: 'quote'}],
    pMarks: [
      {ctx: 'nearly all takes place informally without any agreed strategy', target: 'nearly all takes place informally without any agreed strategy', marks: [ev(T(169))]},
      {ctx: 'nearly all takes place informally without any agreed strategy', target: 'without any agreed strategy', marks: [strong(T(172))]},
      {ctx: 'nearly all takes place informally without any agreed strategy', target: 'nearly all', marks: [strong(T(179))]},
    ],
    sMarks: [{target: 'unplanned', marks: [strong(T(171))]}],
    compare: {
      rows: [
        {q: [{t: T(171), text: 'Unplanned'}], rel: [{t: T(174), sym: '='}], p: [{t: T(172), text: 'Without Any Agreed Strategy'}]},
        {q: [{t: T(178), text: 'Majority'}], rel: [{t: T(180), sym: '='}], p: [{t: T(179), text: 'Nearly All'}]},
      ],
      footer: [{t: T(181), text: 'Meaning Match', tone: 'ok'}],
    },
    ansT: at(183, 1, 2) - 5,
    reason: {t: T(184), text: 'প্রায় সব Expansion-ই Agreed Strategy ছাড়া, Informally হচ্ছে'},
    note: {
      t: T(187),
      title: 'Paraphrasing',
      lines: [
        {t: T(188), text: 'শব্দ আলাদা হলেও Meaning একই হতে পারে'},
        {t: T(190), text: 'Word Matching নয়, Meaning Matching'},
      ],
    },
  },
  {
    n: 5,
    statement: 'Dar es Salaam’s authorities have decided to follow the public transport plan adopted by a large number of African cities.',
    answer: 'FALSE',
    cue: {q: 191, r1: 195, r2: 199, r3: 203, r4: 209, r5: 220, ans: 221, end: 226},
    read: [
      {t: T(196), text: 'Dar es Salaam-এর Authorities'},
      {t: T(197), text: 'আফ্রিকার অনেক শহরের Public Transport Plan'},
      {t: T(198), text: 'অনুসরণ করার সিদ্ধান্ত নিয়েছে।'},
    ],
    readSweep: [195, 195],
    kws: [
      {chip: 'Authorities', phrase: 'authorities', t: T(201, 0, 3)},
      {chip: 'Follow', phrase: 'follow', t: T(201, 1, 3)},
      {chip: 'Public Transport Plan', phrase: 'public transport plan', t: T(201, 2, 3)},
      {chip: 'Large Number of African Cities', phrase: 'large number of african cities', t: T(202)},
    ],
    para: {n: 5, t: T(204)},
    evidence: [
      {t: T(206), text: 'Unlike many cities on the continent, Dar es Salaam isn’t trying to build a metro.', kind: 'quote'},
      {t: T(208), text: 'It has chosen a less exciting but cheaper and more achievable method: the bus.', kind: 'quote'},
    ],
    pMarks: [
      {target: 'Unlike many cities on the continent, Dar es Salaam isn’t trying to build a metro', marks: [ev(T(206))]},
      {target: 'It has chosen a less exciting but cheaper and more achievable method: the bus', marks: [ev(T(208))]},
      {ctx: 'Unlike many cities on the continent', target: 'Unlike many cities', marks: [strong(T(212))]},
      {target: 'isn’t trying to build a metro', marks: [strong(T(213))]},
      {ctx: 'method: the bus', target: 'the bus', marks: [strong(T(214))]},
    ],
    sMarks: [{target: 'public transport plan', marks: [strong(T(210))]}, {target: 'follow', marks: [strong(T(210))]}],
    compare: {
      rows: [
        {
          q: [{t: T(210), text: 'অন্য অনেক শহরের মতোই একই Plan'}],
          rel: [{t: T(214), sym: '≠'}],
          p: [{t: T(212), text: 'Unlike Many Cities: Metro নয়'}, {t: T(214), text: 'Metro নয়, বরং Bus System'}],
        },
      ],
      footer: [
        {t: T(216), text: 'অনেক শহর → Metro'},
        {t: T(217), text: 'Dar es Salaam → Bus System'},
        {t: T(218), text: 'Contradict', tone: 'bad'},
      ],
    },
    ansT: at(221, 1, 2) - 5,
    reason: {t: T(222), text: 'Metro-কেন্দ্রিক Plan না নিয়ে Dar es Salaam Bus System বেছে নিয়েছে'},
  },
];

export const PASSAGE_TITLE = 'The problems of getting around the city of Dar es Salaam';
export const PARAS: string[] = [
  'Dar es Salaam in Tanzania is one of the fastest growing cities in Africa. Its population has increased eightfold since 1980 and swells by half a million people every year. United Nations projections anticipate it will become a megacity within seven years as its population passes 10 million, reaching 13.4 million by 2035. Daniel Hoornweg for the Global Cities Institute forecasts the city could be home to an incredible 73.7 million people by 2100.',
  'Today, four out of five of its people live in single-storey informal settlements on the spreading edges of the city, where the journey to and from the centre regularly takes over two hours. It can be longer if rain turns the dirt roads to mud.',
  'Even in the middle of the day, traffic frequently slows to a stop without warning. It is not unusual for cars and minibuses to queue for 20 minutes at a key intersection. A single suburban rail line serves residents in a few areas to the south but is tiny in the context of the wider city. Outside the centre many rely on boda boda (motorbike taxis) to navigate the narrow side streets and potholed mud roads that make up much of the metropolis. Their safety record is scandalous.',
  'Dar es Salaam’s reliance on four arterial roads into the city is a legacy of the colonial government that planned the city at the start of the 20th century to cater for a population of 35,000. Most of the current growth is made up of young people arriving from the countryside to find work, and as the population has exploded, Dar es Salaam has grown around those four highways. Nearly all the expansion is happening on the periphery, and nearly all takes place informally without any agreed strategy.',
  'But Dar es Salaam is pinning its hopes on a solution that could offer a different model for Africa’s megacities, giving them an alternative to a future controlled by the private car. Unlike many cities on the continent, Dar es Salaam isn’t trying to build a metro. It has chosen a less exciting but cheaper and more achievable method: the bus.',
];

export const RULES = [
  {n: 1, label: 'Read the Statement', hint: 'Statement-এর মূল বক্তব্য বোঝো'},
  {n: 2, label: 'Identify the Keywords', hint: 'গুরুত্বপূর্ণ Keywords বের করো'},
  {n: 3, label: 'Locate the Information', hint: 'Passage-এ Information খুঁজে নাও'},
  {n: 4, label: 'Compare the Information', hint: 'Meaning Match করো'},
  {n: 5, label: 'Make the Decision', hint: 'TRUE / FALSE / NOT GIVEN'},
];
export const qStart = (q: QData) => cs(q.cue.q) - 5;
