import React, {createContext, useContext} from 'react';
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {C, EASE, FONT, SPR, Tone, ToneName, tones} from './theme';

export const ToneCtx = createContext<Tone>(tones.dark);
export const useTone = () => useContext(ToneCtx);

export const clamp01 = (x: number) => Math.max(0, Math.min(1, x));
export const lerp = (a: number, b: number, p: number) => a + (b - a) * p;
export const prog = (frame: number, start: number, dur: number, ease: (x: number) => number = EASE.out) =>
  interpolate(frame, [start, start + dur], [0, 1], {easing: ease, extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});

/* ---------- entrance / exit (opacity + translate + scale, spring) ---------- */
export type AnimOpts = {x?: number; y?: number; s?: number; end?: number; spring?: keyof typeof SPR; exitDur?: number};
export function anim(frame: number, fps: number, start: number, o: AnimOpts = {}): React.CSSProperties {
  const {x = 0, y = 24, s = 0.93, end, spring: sp = 'snap', exitDur = 8} = o;
  const p = spring({frame: frame - start, fps, config: SPR[sp]});
  let op = interpolate(frame, [start, start + 7], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  let tx = (1 - p) * x;
  let ty = (1 - p) * y;
  let sc = s + (1 - s) * p;
  if (end !== undefined && frame > end) {
    const q = prog(frame, end, exitDur, EASE.in);
    op *= 1 - q;
    ty -= q * 14;
    sc *= 1 - 0.03 * q;
  }
  return {opacity: op, transform: `translate(${tx}px,${ty}px) scale(${sc})`, visibility: op <= 0.001 ? 'hidden' : 'visible'};
}

type AProps = AnimOpts & {at: number; style?: React.CSSProperties; children?: React.ReactNode};
export const A: React.FC<AProps> = ({at, style, children, ...o}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return <div style={{...anim(frame, fps, at, o), ...style}}>{children}</div>;
};

/* ---------- word-by-word reveal (শুধু স্পেসে ভাঙে — বাংলা যুক্তাক্ষর অক্ষুণ্ণ) ---------- */
export const Words: React.FC<{text: string; at: number; step?: number; end?: number; y?: number; em?: string; style?: React.CSSProperties}> = ({text, at, step = 4, end, y = 28, em, style}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = useTone();
  const raw = text.split(' ').filter(Boolean);
  let emOn = false;
  const toks = raw.map((w) => {
    const starts = w.startsWith('*');
    const ends = w.length > 1 && w.endsWith('*');
    if (starts) emOn = true;
    const isEm = emOn;
    if (ends) emOn = false;
    let word = w;
    if (starts) word = word.slice(1);
    if (ends) word = word.slice(0, -1);
    return {word, isEm};
  });
  return (
    <>
      {toks.map(({word, isEm}, i) => (
        <React.Fragment key={i}>
          <span style={{display: 'inline-block', letterSpacing: 0, color: isEm ? em ?? t.accent : undefined, ...anim(frame, fps, at + i * step, {y, s: 0.9, end}), ...style}}>{word}</span>
          {i < toks.length - 1 ? ' ' : ''}
        </React.Fragment>
      ))}
    </>
  );
};

/* ---------- highlight sweep (flat fill) ---------- */
export const Hi: React.FC<{at: number; color?: string; fg?: string; dur?: number; children: React.ReactNode}> = ({at, color, fg, dur = 14, children}) => {
  const frame = useCurrentFrame();
  const t = useTone();
  const p = prog(frame, at, dur);
  const col = color ?? t.accent;
  return (
    <span style={{display: 'inline-block', padding: '0 0.16em', borderRadius: '0.14em', color: p > 0.5 ? fg ?? t.onAccent : 'inherit', backgroundImage: `linear-gradient(${col},${col})`, backgroundRepeat: 'no-repeat', backgroundSize: `${p * 100}% 100%`}}>
      {children}
    </span>
  );
};

/* ---------- icons (SVG, currentColor) ---------- */
export const IcCheck: React.FC<{size?: number; stroke?: number}> = ({size = 28, stroke = 3.4}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round"><path d="M4.5 12.5l5 5 10-11" /></svg>
);
export const IcCross: React.FC<{size?: number; stroke?: number}> = ({size = 28, stroke = 3.4}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={stroke} strokeLinecap="round"><path d="M6 6l12 12M18 6L6 18" /></svg>
);
export const IcQuestion: React.FC<{size?: number; stroke?: number}> = ({size = 28, stroke = 3.2}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round"><path d="M8.5 9a3.5 3.5 0 117 0c0 2.2-3.5 2.6-3.5 5.2" /><circle cx="12" cy="18.6" r="0.6" fill="currentColor" /></svg>
);
export const IcArrow: React.FC<{size?: number}> = ({size = 28}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round"><path d="M4 12h15M13 6l6 6-6 6" /></svg>
);

export const Circle: React.FC<{size: number; bg: string; fg: string; border?: string; style?: React.CSSProperties; children: React.ReactNode}> = ({size, bg, fg, border, style, children}) => (
  <div style={{width: size, height: size, borderRadius: size, background: bg, color: fg, border: border ? `3px solid ${border}` : undefined, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, fontWeight: 700, fontSize: size * 0.46, lineHeight: 1, boxSizing: 'border-box', ...style}}>{children}</div>
);

/* ---------- backgrounds: flat tone-on-tone shapes, never gradients ---------- */
export type ShapeKind = 'dots' | 'rings' | 'lines' | 'blocks';
export const BgShapes: React.FC<{v: ShapeKind}> = ({v}) => {
  const frame = useCurrentFrame();
  const t = useTone();
  const els: React.ReactNode[] = [];
  if (v === 'dots') {
    const drift = frame * 0.2;
    for (let r = 0; r < 13; r++) for (let c = 0; c < 23; c++) {
      const cx = ((c * 90 + drift) % 2070) - 45;
      els.push(<circle key={r * 40 + c} cx={cx} cy={r * 90 + 30} r={3 + (Math.sin(frame / 30 + c * 0.5 + r * 0.7) + 1) * 0.9} fill={t.shape} />);
    }
  } else if (v === 'rings') {
    for (let i = 0; i < 5; i++) els.push(<circle key={i} cx={1800} cy={160} r={170 + i * 130 + Math.sin(frame / 40 + i) * 10} fill="none" stroke={t.shape} strokeWidth={3} />);
    for (let i = 0; i < 3; i++) els.push(<circle key={'b' + i} cx={100} cy={960} r={120 + i * 110 + Math.sin(frame / 36 + i) * 8} fill="none" stroke={t.shape} strokeWidth={3} />);
  } else if (v === 'lines') {
    for (let i = 0; i < 14; i++) els.push(<rect key={i} x={-200 + i * 190 + Math.sin(frame / 60) * 14} y={-100} width={46} height={1400} fill={t.shape} transform="rotate(24 960 540)" />);
  } else {
    els.push(<rect key="a" x={1380} y={-90} width={520} height={520} rx={90} fill={t.shape} transform={`rotate(${18 + Math.sin(frame / 50) * 4} 1640 170)`} />);
    els.push(<rect key="b" x={-120} y={700} width={460} height={460} rx={80} fill={t.shape} transform={`rotate(${-14 + Math.sin(frame / 45) * 4} 110 930)`} />);
  }
  return <svg width={1920} height={1080} style={{position: 'absolute', left: 0, top: 0}}>{els}</svg>;
};

export const SceneShell: React.FC<{tone: ToneName; shape?: ShapeKind; children: React.ReactNode}> = ({tone, shape = 'dots', children}) => (
  <ToneCtx.Provider value={tones[tone]}>
    <AbsoluteFill style={{background: tones[tone].bg, color: tones[tone].fg, fontFamily: FONT, letterSpacing: 0}}>
      <BgShapes v={shape} />
      {children}
    </AbsoluteFill>
  </ToneCtx.Provider>
);

/* ---------- marked text (passage + statement highlights) ---------- */
export type MarkKind = 'ev' | 'strong' | 'off';
export type Mark = {t: number; kind: MarkKind};
export type Range = {s: number; e: number; marks: Mark[]};
export type HiSpec = {ctx?: string; target: string; marks: Mark[]};

/** ctx (না থাকলে target) টেক্সটে খুঁজে Range বানায়; না পেলে null */
export function locate(text: string, spec: HiSpec): Range | null {
  const low = text.toLowerCase();
  let base = 0;
  if (spec.ctx) {
    base = low.indexOf(spec.ctx.toLowerCase());
    if (base < 0) return null;
  }
  const scope = spec.ctx ? low.slice(base, base + spec.ctx.length) : low;
  const idx = scope.indexOf(spec.target.toLowerCase());
  if (idx < 0) return null;
  return {s: base + idx, e: base + idx + spec.target.length, marks: spec.marks};
}
export const kindAt = (r: Range, frame: number): {kind: MarkKind; t: number} => {
  let k: MarkKind = 'off';
  let tt = 0;
  for (const m of r.marks) if (m.t <= frame) { k = m.kind; tt = m.t; }
  return {kind: k, t: tt};
};

export const MarkedText: React.FC<{text: string; ranges: Range[]}> = ({text, ranges}) => {
  const frame = useCurrentFrame();
  const cuts = new Set<number>([0, text.length]);
  ranges.forEach((r) => { cuts.add(r.s); cuts.add(r.e); });
  const pts = [...cuts].sort((a, b) => a - b);
  const out: React.ReactNode[] = [];
  for (let i = 0; i < pts.length - 1; i++) {
    const a = pts[i];
    const b = pts[i + 1];
    const seg = text.slice(a, b);
    let best: {r: Range; kind: MarkKind; t: number} | null = null;
    for (const r of ranges) {
      if (r.s <= a && r.e >= b) {
        const k = kindAt(r, frame);
        if (k.kind !== 'off' && (!best || r.e - r.s <= best.r.e - best.r.s)) best = {r, ...k};
      }
    }
    if (!best) { out.push(<span key={i}>{seg}</span>); continue; }
    const len = best.r.e - best.r.s;
    const sw = Math.min(26, Math.max(10, len * 0.9));
    const dly = ((a - best.r.s) / len) * sw;
    const dur = Math.max(3, ((b - a) / len) * sw);
    const p = clamp01((frame - (best.t + dly)) / dur);
    const tint = `linear-gradient(${C.redTint},${C.redTint})`;
    const under = `linear-gradient(${C.red},${C.red})`;
    const style: React.CSSProperties = {boxDecorationBreak: 'clone', WebkitBoxDecorationBreak: 'clone', backgroundRepeat: 'no-repeat'};
    if (best.kind === 'ev') {
      Object.assign(style, {backgroundImage: `${tint},${under}`, backgroundSize: `${p * 100}% 100%,${p * 100}% 3px`, backgroundPosition: '0 0,0 100%'});
    } else {
      Object.assign(style, {backgroundImage: `${under},${tint},${under}`, backgroundSize: `${p * 100}% 100%,100% 100%,100% 3px`, backgroundPosition: '0 0,0 0,0 100%', color: p > 0.45 ? C.white : undefined, fontWeight: 700});
    }
    out.push(<span key={i} style={style}>{seg}</span>);
  }
  return <>{out}</>;
};
