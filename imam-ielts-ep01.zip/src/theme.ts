import {Easing} from 'remotion';
import {loadFont} from '@remotion/google-fonts/HindSiliguri';

const {fontFamily} = loadFont('normal', {
  weights: ['400', '500', '600', '700'],
  subsets: ['bengali', 'latin'],
});
export const FONT = `${fontFamily}, 'Hind Siliguri', 'Noto Sans Bengali', 'Segoe UI', sans-serif`;

// তিনটা ফ্ল্যাট রঙ + সাদা। কোনো গ্রেডিয়েন্ট নেই।
export const C = {
  dark: '#15110D',
  cream: '#F5F1ED',
  red: '#E21A1E',
  white: '#FFFFFF',
  gray: '#B8B4A8', // ডার্ক ব্যাকগ্রাউন্ডে ছোট লেখা
  grayCream: '#96928C', // ক্রিম ব্যাকগ্রাউন্ডে ছোট লেখা
  // একই রঙের ফ্ল্যাট টোন (surface)
  darkRaise: '#211B15',
  darkRaise2: '#2D251D',
  creamDeep: '#EAE3DA',
  redTint: 'rgba(226,26,30,0.16)',
  redTintStrong: 'rgba(226,26,30,0.26)',
} as const;

export type ToneName = 'dark' | 'cream' | 'red';
export type Tone = {
  name: ToneName;
  bg: string;
  fg: string;
  dim: string;
  accent: string;
  onAccent: string;
  surface: string;
  onSurface: string;
  line: string;
  shape: string;
};

export const tones: Record<ToneName, Tone> = {
  dark: {name: 'dark', bg: C.dark, fg: C.white, dim: C.gray, accent: C.red, onAccent: C.white, surface: C.darkRaise, onSurface: C.white, line: 'rgba(255,255,255,0.16)', shape: 'rgba(255,255,255,0.045)'},
  cream: {name: 'cream', bg: C.cream, fg: C.dark, dim: C.grayCream, accent: C.red, onAccent: C.white, surface: C.white, onSurface: C.dark, line: 'rgba(21,17,13,0.14)', shape: 'rgba(21,17,13,0.05)'},
  red: {name: 'red', bg: C.red, fg: C.white, dim: 'rgba(255,255,255,0.8)', accent: C.dark, onAccent: C.white, surface: C.dark, onSurface: C.white, line: 'rgba(255,255,255,0.32)', shape: 'rgba(21,17,13,0.10)'},
};

export const EASE = {
  out: Easing.bezier(0.16, 1, 0.3, 1),
  inOut: Easing.bezier(0.65, 0, 0.35, 1),
  in: Easing.bezier(0.5, 0, 0.9, 0.4),
};

export const SPR = {
  snap: {damping: 16, stiffness: 170, mass: 0.7},
  soft: {damping: 22, stiffness: 110, mass: 0.9},
  bounce: {damping: 9, stiffness: 160, mass: 0.7},
} as const;
