import {CUES} from './srt';
import {FPS, TAIL_FRAMES} from './config';

/** ভিজ্যুয়াল কথার এত ফ্রেম আগে ঢোকে */
export const LEAD = 5;
export const TR = 10; // transition frames

/** cue n (1-based) -এর শুরু/শেষ ফ্রেম */
export const cs = (n: number) => Math.round(CUES[n - 1].start * FPS);
export const ce = (n: number) => Math.round(CUES[n - 1].end * FPS);
/** cue-র ভেতরে m ভাগের k-তম ভাগের ফ্রেম (একাধিক আইটেম সমান ব্যবধানে) */
export const at = (n: number, k = 0, m = 1) => Math.round(cs(n) + ((ce(n) - cs(n)) * k) / m);
/** at() থেকে LEAD ফ্রেম আগে */
export const T = (n: number, k = 0, m = 1) => at(n, k, m) - LEAD;

export const TOTAL_FRAMES = ce(CUES.length) + TAIL_FRAMES;
