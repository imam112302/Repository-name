export type SceneProps = {from: number; to: number};
