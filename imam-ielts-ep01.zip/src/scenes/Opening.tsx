import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';
import {C, EASE} from '../theme';
import {A, Circle, IcCheck, IcCross, IcQuestion, SceneShell, Words, Hi, anim, lerp, prog} from '../ui';
import {T, ce, cs} from '../timing';
import {SceneProps} from './types';

const center: React.CSSProperties = {alignItems: 'center', justifyContent: 'center'};

/* S1 — Hook (cues 1–3) */
export const Hook: React.FC<SceneProps> = () => {
  const frame = useCurrentFrame();
  const c2 = T(2);
  const c3 = T(3);
  const lift = -100 * prog(frame, c2, 22, EASE.inOut) - 80 * prog(frame, c3, 22, EASE.inOut);
  return (
    <SceneShell tone="dark" shape="rings">
      <AbsoluteFill style={center}>
        <div style={{transform: `translateY(${lift}px)`, display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
          <div style={{display: 'flex', gap: 44, alignItems: 'baseline', fontSize: 250, fontWeight: 700, lineHeight: 1}}>
            <A at={2} y={90} s={1.3} spring="bounce">IMAM</A>
            <A at={9} y={90} s={1.3} spring="bounce" style={{color: C.red}}>IELTS</A>
          </div>
          <div style={{height: 10, width: 1180 * prog(frame, 14, 24), background: C.cream, borderRadius: 10, marginTop: 14}} />
          <A at={c2} y={30} style={{marginTop: 26, fontSize: 76, fontWeight: 500, color: C.gray}}>Reading Masterclass</A>
          <div style={{display: 'flex', alignItems: 'center', gap: 20, marginTop: 56, height: 80}}>
            <A at={c3} y={30} s={0.8} spring="bounce" style={{background: C.red, borderRadius: 50, padding: '10px 34px', fontSize: 36, fontWeight: 700}}>EPISODE 01</A>
            {['TRUE', 'FALSE', 'NOT GIVEN'].map((w, k) => (
              <A key={w} at={T(3, k, 3)} y={30} s={0.8} spring="bounce" style={{border: '3px solid rgba(255,255,255,0.55)', borderRadius: 50, padding: '8px 30px', fontSize: 36, fontWeight: 600}}>{w}</A>
            ))}
          </div>
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};

/* S2 — Tagline (cue 4): 4s cue, তিন বাক্য সমান ব্যবধানে */
export const Tagline: React.FC<SceneProps> = () => {
  const frame = useCurrentFrame();
  const rows = [
    {n: '01', a: 'Learn the', b: 'Rules.'},
    {n: '02', a: 'Apply the', b: 'Rules.'},
    {n: '03', a: 'Find the', b: 'Answer.'},
  ];
  return (
    <SceneShell tone="red" shape="lines">
      <AbsoluteFill style={{...center, padding: '0 190px', alignItems: 'flex-start', gap: 34}}>
        {rows.map((r, k) => {
          const st = T(4, k, 3);
          const dim = k < 2 ? prog(frame, T(4, k + 1, 3), 10) : 0;
          return (
            <A key={k} at={st} x={-120} y={0} s={0.96} style={{display: 'flex', alignItems: 'center', gap: 50}}>
              <div style={{display: 'flex', alignItems: 'center', gap: 50, opacity: 1 - dim * 0.45}}>
                <Circle size={118} bg={C.dark} fg={C.white}>{r.n}</Circle>
                <div style={{position: 'relative', fontSize: 150, fontWeight: 700, lineHeight: 1.1, whiteSpace: 'nowrap'}}>
                  {r.a} <span style={{color: C.dark}}>{r.b}</span>
                  <div style={{position: 'absolute', left: 0, bottom: -4, height: 7, width: `${prog(frame, st + 8, 22) * 100}%`, background: C.white, borderRadius: 7, opacity: 0.8}} />
                </div>
              </div>
            </A>
          );
        })}
      </AbsoluteFill>
    </SceneShell>
  );
};

/* S3 — Confusion (cues 5–9) */
const CARDS: {id: string; icon: React.ReactNode; bg: string; fg: string; bd?: string}[] = [
  {id: 'TRUE', icon: <IcCheck size={58} stroke={4} />, bg: C.dark, fg: C.white},
  {id: 'FALSE', icon: <IcCross size={58} stroke={4} />, bg: C.red, fg: C.white},
  {id: 'NOT GIVEN', icon: <IcQuestion size={62} stroke={3.6} />, bg: C.white, fg: C.dark, bd: C.dark},
];
export const Confusion: React.FC<SceneProps> = () => {
  const frame = useCurrentFrame();
  const x1 = [-540, 0, 540];
  const x2 = [-1100, -290, 290];
  const p8 = prog(frame, T(8), 20, EASE.inOut);
  const jit1 = prog(frame, T(7), 8) * (1 - prog(frame, T(8) - 2, 6));
  const jit2 = prog(frame, T(9), 8);
  return (
    <SceneShell tone="cream" shape="blocks">
      {CARDS.map((cd, i) => {
        const st = T(5, i, 3);
        const x = lerp(x1[i], x2[i], p8);
        const gone = i === 0 ? 1 - p8 : 1;
        const rot = Math.sin(frame * 1.35 + i * 2) * 3.2 * (jit1 + (i > 0 ? jit2 : 0));
        return (
          <div key={cd.id} style={{position: 'absolute', left: 960 - 220 + x, top: 200, width: 440, height: 470, opacity: gone, transform: `rotate(${rot}deg)`}}>
            <A at={st} y={60} s={0.85} spring="bounce" style={{width: 440, height: 470, background: C.white, borderRadius: 42, border: `3px solid ${C.dark}`, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 36, color: C.dark, boxSizing: 'border-box'}}>
              <Circle size={130} bg={cd.bg} fg={cd.fg} border={cd.bd}>{cd.icon}</Circle>
              <div style={{fontSize: 62, fontWeight: 700, lineHeight: 1}}>{cd.id}</div>
            </A>
          </div>
        );
      })}
      {[-270, 270].map((x, k) => (
        <A key={k} at={T(6, k, 2)} end={T(8) - 2} y={0} s={0.3} spring="bounce" style={{position: 'absolute', left: 960 - 45 + x, top: 380}}>
          <Circle size={90} bg={C.red} fg={C.white} style={{fontSize: 56}}>≠</Circle>
        </A>
      ))}
      {[0, 1, 2].map((k) => (
        <A key={k} at={T(7, k, 3)} end={T(8) - 2} y={30} s={0.3} spring="bounce" style={{position: 'absolute', left: 960 - 50 + x1[k], top: 60}}>
          <Circle size={100} bg={C.red} fg={C.white}><IcQuestion size={58} stroke={4} /></Circle>
        </A>
      ))}
      <A at={T(8) + 8} y={0} s={0.2} spring="bounce" style={{position: 'absolute', left: 960 - 62, top: 395}}>
        <Circle size={124} bg={C.red} fg={C.white} style={{transform: `rotate(${Math.sin(frame * 0.9) * 6 * jit2}deg)`}}><IcQuestion size={72} stroke={4} /></Circle>
      </A>
      <div style={{position: 'absolute', left: 0, right: 0, top: 740, height: 220, display: 'flex', alignItems: 'center', justifyContent: 'center', textAlign: 'center', fontWeight: 700}}>
        <div style={{position: 'absolute', fontSize: 130}}><Words text="*Confused*" at={T(7)} end={T(8) - 4} /></div>
        <div style={{position: 'absolute', fontSize: 78}}><Words text="Passage-এ *Information* নেই" at={T(8)} end={T(9) - 4} /></div>
        <div style={{position: 'absolute', fontSize: 118, whiteSpace: 'nowrap'}}><Words text="*NOT GIVEN* নাকি *FALSE?*" at={T(9)} step={5} /></div>
      </div>
    </SceneShell>
  );
};

/* S4 — Promise (cues 10–16) */
const RULE_SHORT = ['Read', 'Keywords', 'Locate', 'Compare', 'Decide'];
export const Promise_: React.FC<SceneProps> = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const a0 = T(10), b0 = T(11), c0 = T(14), d0 = T(15);
  return (
    <SceneShell tone="dark" shape="dots">
      {/* A: শুধু Theory নয় */}
      <AbsoluteFill style={center}>
        <div style={{display: 'flex', gap: 46, alignItems: 'center', fontSize: 190, fontWeight: 700, lineHeight: 1.1}}>
          <A at={a0} end={b0 - 8} y={40}>শুধু</A>
          <A at={a0 + 5} end={b0 - 8} y={40} style={{position: 'relative', color: C.gray}}>
            Theory
            <div style={{position: 'absolute', left: -10, top: '54%', height: 16, width: `${prog(frame, a0 + 40, 14) * 108}%`, background: C.red, borderRadius: 8}} />
          </A>
          <A at={a0 + 10} end={b0 - 8} y={40}>নয়</A>
        </div>
      </AbsoluteFill>
      {/* B: Cambridge IELTS 21 passage + five rules */}
      <A at={b0} end={c0 - 8} y={50} s={0.95} style={{position: 'absolute', left: 300, top: 90, width: 620, height: 700, background: C.cream, color: C.dark, borderRadius: 34, padding: '38px 42px', boxSizing: 'border-box'}}>
        <div style={{fontSize: 40, fontWeight: 700, lineHeight: 1.15}}>Cambridge IELTS 21</div>
        <div style={{fontSize: 24, fontWeight: 600, color: C.grayCream, marginTop: 6}}>Reading Passage · Questions 1–5</div>
        <div style={{marginTop: 34, display: 'flex', flexDirection: 'column', gap: 22}}>
          {[0, 1, 2, 3, 4].map((k) => (
            <div key={k} style={{display: 'flex', alignItems: 'center', gap: 18}}>
              <Circle size={46} bg={C.creamDeep} fg={C.dark} style={{fontSize: 20}}>Q{k + 1}</Circle>
              <div style={{height: 16, borderRadius: 16, background: C.creamDeep, width: [330, 270, 350, 300, 320][k]}} />
              <A at={T(13, k, 5)} end={c0 - 8} y={0} s={0.2} spring="bounce" style={{marginLeft: 'auto'}}><Circle size={44} bg={C.red} fg={C.white}><IcCheck size={24} stroke={4} /></Circle></A>
            </div>
          ))}
        </div>
      </A>
      <div style={{position: 'absolute', left: 1010, top: 110, width: 620}}>
        <A at={T(12)} end={c0 - 8} y={20} style={{fontSize: 22, fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: C.gray, marginBottom: 20}}>Five Golden Rules</A>
        {RULE_SHORT.map((r, k) => (
          <A key={k} at={T(12, k, 5)} end={c0 - 8} x={60} y={0} style={{display: 'flex', alignItems: 'center', gap: 22, marginBottom: 22}}>
            <Circle size={86} bg={C.red} fg={C.white}>R{k + 1}</Circle>
            <div style={{fontSize: 52, fontWeight: 600}}>{r}</div>
          </A>
        ))}
      </div>
      <div style={{position: 'absolute', left: 0, right: 0, top: 880, display: 'flex', justifyContent: 'center', fontSize: 52, fontWeight: 600, height: 80, alignItems: 'center'}}>
        <div style={{position: 'absolute', whiteSpace: 'nowrap'}}><Words text="Cambridge IELTS 21-এর *Reading Passage*" at={b0} end={T(12) - 6} step={3} y={20} /></div>
        <div style={{position: 'absolute', whiteSpace: 'nowrap'}}><Words text="আমাদের নিজস্ব *Five Golden Rules*" at={T(12)} end={T(13) - 6} step={3} y={20} /></div>
        <div style={{position: 'absolute', whiteSpace: 'nowrap'}}><Words text="প্রতিটি প্রশ্ন *Solve* করব" at={T(13)} end={c0 - 8} step={3} y={20} /></div>
      </div>
      {/* C: শেষ পর্যন্ত দেখবে */}
      <A at={c0} end={d0 - 8} y={50} s={0.95} style={{position: 'absolute', left: 360, top: 140, width: 1200, height: 640, background: C.darkRaise, borderRadius: 40, border: '2px solid rgba(255,255,255,0.16)'}}>
        <div style={{position: 'absolute', left: 540, top: 190, width: 120, height: 120, borderRadius: 120, background: C.red, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
          <svg width={50} height={50} viewBox="0 0 24 24" fill={C.white}><path d="M7 4.5v15l13-7.5z" /></svg>
        </div>
        <div style={{position: 'absolute', left: 70, right: 70, bottom: 80, height: 16, borderRadius: 16, background: C.darkRaise2}}>
          <div style={{height: 16, borderRadius: 16, background: C.red, width: `${prog(frame, c0 + 6, ce(14) - cs(14) - 6, (x) => x) * 100}%`}} />
        </div>
        <div style={{position: 'absolute', left: 70, bottom: 118, fontSize: 28, fontWeight: 600, color: C.gray}}>IMAM IELTS · Episode 01</div>
      </A>
      <div style={{position: 'absolute', left: 0, right: 0, top: 850, display: 'flex', justifyContent: 'center', fontSize: 68, fontWeight: 700}}>
        <Words text="শেষ পর্যন্ত *দেখবে*" at={c0} end={d0 - 8} />
      </div>
      {/* D: Answer নয়, Technique */}
      <AbsoluteFill style={{...center, gap: 10}}>
        <A at={d0} y={40} style={{position: 'relative', fontSize: 120, fontWeight: 700, color: C.gray, lineHeight: 1.1}}>
          Answer নয়
          <div style={{position: 'absolute', left: -8, top: '56%', height: 12, width: `${prog(frame, d0 + 22, 14) * 104}%`, background: C.red, borderRadius: 8}} />
        </A>
        <div style={{fontSize: 250, fontWeight: 700, lineHeight: 1.15}}>
          <Hi at={T(16)} dur={16}><span style={{opacity: anim(frame, fps, T(16), {}).opacity}}>Technique</span></Hi>
        </div>
        <A at={T(16) + 14} y={20} style={{fontSize: 48, fontWeight: 500, color: C.gray}}>Answer বের করার Technique শিখবে</A>
      </AbsoluteFill>
    </SceneShell>
  );
};

/* S5 — Welcome (cues 17–18) */
export const Welcome: React.FC<SceneProps> = () => (
  <SceneShell tone="red" shape="rings">
    <AbsoluteFill style={center}>
      <div style={{textAlign: 'center', fontWeight: 700, lineHeight: 1.05}}>
        <div style={{fontSize: 130}}><Words text="Welcome to" at={T(17)} step={5} /></div>
        <div style={{fontSize: 250}}><Words text="*IMAM* *IELTS!*" at={T(17) + 12} step={6} y={60} /></div>
      </div>
      <A at={T(18)} y={30} style={{marginTop: 50, background: C.dark, color: C.white, borderRadius: 60, padding: '14px 44px', fontSize: 44, fontWeight: 600}}>প্রথমে খুব সংক্ষেপে বুঝে নিই</A>
    </AbsoluteFill>
  </SceneShell>
);
