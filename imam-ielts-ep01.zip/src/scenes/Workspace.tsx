import React from 'react';
import {useCurrentFrame, useVideoConfig} from 'remotion';
import {C, EASE} from '../theme';
import {A, Circle, IcArrow, IcCheck, IcCross, IcQuestion, MarkedText, Range, SceneShell, Words, anim, clamp01, locate, prog} from '../ui';
import {PARAS, PASSAGE_TITLE, QData, QS, RULES, St, Tn, qStart} from '../qdata';
import {T, cs, ce} from '../timing';
import {SceneProps} from './types';

/* ---------- geometry (এক স্ক্রিন — পুরো Q1–Q5 জুড়ে একই লেআউট) ---------- */
const PX = 40, PY = 40, PW = 1100, PH = 1000;
const RX = 1170, RW = 710;
const QCARD_H = 350, TRK_TOP = 370, TRK_H = 630;
const COL_H = 58, INTRO_H = 118, GAP = 10;
const EXP_H = TRK_H - 4 * GAP - 4 * COL_H;

const WS_END = cs(226) - 12;
const QEND = QS.map((_, i) => (i < QS.length - 1 ? qStart(QS[i + 1]) - 10 : WS_END));

/* ---------- highlight ranges (computed once) ---------- */
const TITLE_RANGES: Range[] = [{s: 0, e: PASSAGE_TITLE.length, marks: [{t: T(48), kind: 'ev'}, {t: qStart(QS[0]) - 4, kind: 'off'}]}];
const PARA_RANGES: Range[][] = PARAS.map(() => []);
const STMT_RANGES: Range[][] = QS.map(() => []);
QS.forEach((q, qi) => {
  q.pMarks.forEach((spec) => {
    let found = false;
    PARAS.forEach((p, pi) => {
      const r = locate(p, {...spec, marks: [...spec.marks, {t: QEND[qi], kind: 'off'}]});
      if (r) { PARA_RANGES[pi].push(r); found = true; }
    });
    if (!found) throw new Error('passage phrase not found: ' + spec.target);
  });
  q.kws.forEach((k) => {
    const r = locate(q.statement, {target: k.phrase, marks: [{t: k.t, kind: 'ev'}, {t: QEND[qi], kind: 'off'}]});
    if (!r) throw new Error('keyword not found: ' + k.phrase);
    STMT_RANGES[qi].push(r);
  });
  q.sMarks.forEach((spec) => {
    const r = locate(q.statement, {...spec, marks: [...spec.marks, {t: QEND[qi], kind: 'off'}]});
    if (!r) throw new Error('statement mark not found: ' + spec.target);
    STMT_RANGES[qi].push(r);
  });
});

const lastState = (list: St[] | undefined, frame: number): St | null => {
  let s: St | null = null;
  if (list) for (const x of list) if (x.t <= frame) s = x;
  return s;
};

/* ---------- passage panel ---------- */
const PassagePanel: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return (
    <div style={{position: 'absolute', left: PX, top: PY, width: PW, height: PH, background: C.cream, color: C.dark, borderRadius: 30, padding: '32px 40px 24px 86px', boxSizing: 'border-box', ...anim(frame, fps, T(47), {y: 40, s: 0.96, spring: 'soft'})}}>
      <div style={{display: 'flex', justifyContent: 'space-between', fontSize: 15, fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: C.grayCream, marginBottom: 12}}>
        <span>Reading Passage 2</span>
        <span>Cambridge IELTS 21 · Academic Reading Test 3</span>
      </div>
      <div style={{fontSize: 30, fontWeight: 700, lineHeight: 1.25, marginBottom: 18}}><MarkedText text={PASSAGE_TITLE} ranges={TITLE_RANGES} /></div>
      {PARAS.map((p, i) => {
        const active = QS.findIndex((q, qi) => q.para.n === i + 1 && frame >= q.para.t && frame < QEND[qi]);
        const pa = active >= 0 ? prog(frame, QS[active].para.t, 10) * (1 - prog(frame, QEND[active] - 2, 8, EASE.in)) : 0;
        return (
          <div key={i} style={{position: 'relative', fontSize: 20, lineHeight: 1.54, marginBottom: 14, padding: '8px 14px', margin: '0 -14px 6px', borderRadius: 10, background: `rgba(234,227,218,${pa})`}}>
            <div style={{position: 'absolute', left: -52, top: 9, width: 30, height: 30, borderRadius: 30, background: pa > 0.4 ? C.red : C.creamDeep, color: pa > 0.4 ? C.white : C.grayCream, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 15, fontWeight: 700}}>{i + 1}</div>
            <div style={{position: 'absolute', left: -14, top: 8, bottom: 8, width: 5, borderRadius: 5, background: C.red, opacity: pa, transform: `scaleY(${pa})`}} />
            <MarkedText text={p} ranges={PARA_RANGES[i]} />
          </div>
        );
      })}
    </div>
  );
};

/* ---------- question card ---------- */
const OPTS: {l: string; v: 'TRUE' | 'FALSE' | 'NOT GIVEN'}[] = [{l: 'A', v: 'TRUE'}, {l: 'B', v: 'FALSE'}, {l: 'C', v: 'NOT GIVEN'}];
const QuestionCard: React.FC<{q: QData; qi: number}> = ({q, qi}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const sweep = prog(frame, T(q.readSweep[0]), ce(q.readSweep[1]) - cs(q.readSweep[0]) + 5, (x) => x);
  const picked = frame >= q.ansT;
  const pk = anim(frame, fps, q.ansT, {y: 0, s: 0.9, spring: 'bounce'});
  return (
    <div style={{position: 'absolute', left: 0, top: 0, width: RW, height: QCARD_H, background: C.white, color: C.dark, borderRadius: 30, padding: '24px 30px', boxSizing: 'border-box'}}>
      <div style={{display: 'flex', alignItems: 'center', gap: 14}}>
        <Circle size={62} bg={C.red} fg={C.white} style={{fontSize: 26}}>Q{q.n}</Circle>
        <div style={{fontSize: 15, fontWeight: 700, letterSpacing: '0.1em', color: C.grayCream}}>TRUE / FALSE / NOT GIVEN</div>
        <div style={{marginLeft: 'auto', display: 'flex', gap: 8}}>
          {QS.map((_, k) => <div key={k} style={{width: 14, height: 14, borderRadius: 14, background: k <= qi ? C.red : C.creamDeep}} />)}
        </div>
      </div>
      <div style={{position: 'relative', marginTop: 16, fontSize: 28, fontWeight: 600, lineHeight: 1.4}}>
        <MarkedText text={q.statement} ranges={STMT_RANGES[qi]} />
        <div style={{position: 'absolute', left: 0, bottom: -10, height: 4, width: `${sweep * 100}%`, background: C.red, opacity: sweep > 0 && sweep < 1 ? 1 : 0, borderRadius: 4}} />
      </div>
      <div style={{position: 'absolute', left: 30, right: 30, bottom: 24, height: 56, display: 'flex', gap: 12}}>
        {OPTS.map((o, k) => {
          const sel = picked && o.v === q.answer;
          return (
            <div key={k} style={{flex: 1, borderRadius: 16, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, fontSize: 21, fontWeight: 700, boxSizing: 'border-box', border: `2px solid ${sel ? C.red : 'rgba(21,17,13,0.18)'}`, background: sel ? C.red : 'transparent', color: sel ? C.white : C.dark, opacity: picked && !sel ? 0.35 : 1, ...(sel ? pk : {})}}>
              <span style={{width: 28, height: 28, borderRadius: 28, background: sel ? 'rgba(255,255,255,0.25)' : C.creamDeep, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 15}}>{o.l}</span>
              {o.v}
            </div>
          );
        })}
      </div>
    </div>
  );
};

/* ---------- tracker ---------- */
const toneStyle = (tn: Tn | undefined): React.CSSProperties => {
  if (tn === 'bad') return {background: C.red, color: C.white, border: `2px solid ${C.red}`};
  if (tn === 'ok') return {background: C.cream, color: C.dark, border: `2px solid ${C.cream}`};
  return {background: C.darkRaise2, color: C.white, border: '2px solid rgba(255,255,255,0.16)'};
};
const Cell: React.FC<{states?: St[]}> = ({states}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = lastState(states, frame);
  if (!s) return <div style={{minHeight: 70}} />;
  return <div style={{minHeight: 70, borderRadius: 16, padding: '10px 14px', display: 'flex', alignItems: 'center', fontSize: 24, fontWeight: 600, lineHeight: 1.25, boxSizing: 'border-box', ...toneStyle(s.tone), ...anim(frame, fps, s.t, {y: 10, s: 0.94})}}>{s.text}</div>;
};
const RelDot: React.FC<{q: QData; ri: number}> = ({q, ri}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  let cur: {t: number; sym: string} | null = null;
  for (const r of q.compare.rows[ri].rel ?? []) if (r.t <= frame) cur = r;
  if (!cur) return <div />;
  const bad = cur.sym === '≠' || cur.sym === '✕';
  const ok = cur.sym === '✓' || cur.sym === '=';
  return (
    <div style={{width: 46, height: 46, borderRadius: 46, margin: '0 auto', display: 'flex', alignItems: 'center', justifyContent: 'center', background: bad ? C.red : ok ? C.cream : 'transparent', color: bad ? C.white : ok ? C.dark : C.gray, border: bad || ok ? 'none' : '2px dashed rgba(255,255,255,0.4)', fontSize: 26, fontWeight: 700, ...anim(frame, fps, cur.t, {y: 0, s: 0.4, spring: 'bounce'})}}>
      {cur.sym === '✕' ? <IcCross size={22} /> : cur.sym === '✓' ? <IcCheck size={22} /> : cur.sym === '?' ? <IcQuestion size={26} /> : cur.sym}
    </div>
  );
};

const RowBody: React.FC<{i: number; q: QData}> = ({i, q}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const eyebrow = (txt: string, at: number) => <A at={at} y={8} style={{fontSize: 15, fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: C.red, marginBottom: 12}}>{txt}</A>;
  if (i === 0) {
    return (
      <div>
        {eyebrow('Main Idea', T(q.cue.r1))}
        <div style={{fontSize: 32, fontWeight: 600, lineHeight: 1.45}}>
          {q.read.map((s, k) => (
            <React.Fragment key={k}><Words text={s.text} at={s.t} step={3} y={16} />{' '}</React.Fragment>
          ))}
        </div>
      </div>
    );
  }
  if (i === 1) {
    return (
      <div>
        {eyebrow('Keywords', T(q.cue.r2))}
        <div style={{display: 'flex', flexWrap: 'wrap', gap: 12}}>
          {q.kws.map((k, idx) => (
            <A key={idx} at={k.t} y={14} s={0.8} spring="bounce" style={{padding: '9px 18px', borderRadius: 40, fontSize: 28, fontWeight: 600, border: `2px solid ${C.red}`, background: 'rgba(226,26,30,0.22)'}}>{k.chip}</A>
          ))}
        </div>
      </div>
    );
  }
  if (i === 2) {
    return (
      <div>
        <A at={q.para.t} x={-18} y={0} style={{display: 'inline-flex', alignItems: 'center', gap: 10, background: C.red, borderRadius: 40, padding: '8px 20px 8px 14px', fontSize: 24, fontWeight: 700, marginBottom: 14}}>
          <span style={{transform: 'rotate(180deg)', display: 'flex'}}><IcArrow size={22} /></span>Paragraph {q.para.n}
        </A>
        <div style={{display: 'flex', flexDirection: 'column', gap: 10}}>
          {q.evidence.map((e, k) => (
            <A key={k} at={e.t} y={14} style={{borderLeft: `6px solid ${C.red}`, background: C.darkRaise2, borderRadius: 12, padding: '10px 16px', fontSize: e.kind === 'quote' ? 25 : 28, fontWeight: e.kind === 'quote' ? 500 : 600, fontStyle: e.kind === 'quote' ? 'italic' : 'normal', lineHeight: 1.35}}>{e.text}</A>
          ))}
        </div>
      </div>
    );
  }
  if (i === 3) {
    return (
      <div>
        <div style={{display: 'grid', gridTemplateColumns: '1fr 56px 1fr', gap: 10, fontSize: 14, fontWeight: 700, letterSpacing: '0.12em', color: C.gray, marginBottom: 8, textTransform: 'uppercase'}}>
          <A at={T(q.cue.r4)} y={6}>Question</A><span /><A at={T(q.cue.r4)} y={6}>Passage</A>
        </div>
        <div style={{display: 'flex', flexDirection: 'column', gap: 10}}>
          {q.compare.rows.map((r, k) => (
            <div key={k} style={{display: 'grid', gridTemplateColumns: '1fr 56px 1fr', gap: 10, alignItems: 'center'}}>
              <Cell states={r.q} /><RelDot q={q} ri={k} /><Cell states={r.p} />
            </div>
          ))}
        </div>
        <div style={{display: 'flex', flexWrap: 'wrap', gap: 10, marginTop: 14}}>
          {q.compare.footer.map((f, k) => (
            <A key={k} at={f.t} y={10} style={{padding: '8px 16px', borderRadius: 40, fontSize: 22, fontWeight: 700, ...toneStyle(f.tone)}}>{f.text}</A>
          ))}
        </div>
      </div>
    );
  }
  // R5: decision
  const noteT = q.note ? q.note.t : 1e9;
  const dots = [0, 1, 2].map((d) => 0.3 + 0.7 * Math.max(0, Math.sin(frame / 5 - d * 0.9)));
  return (
    <div style={{position: 'relative', height: '100%'}}>
      <div style={{display: 'flex', alignItems: 'center', gap: 16, height: 76}}>
        {frame < q.ansT && (
          <div style={{display: 'flex', alignItems: 'center', gap: 10, fontSize: 24, fontWeight: 600, color: C.gray}}>
            Final Decision {dots.map((o, d) => <span key={d} style={{width: 10, height: 10, borderRadius: 10, background: C.gray, opacity: o}} />)}
          </div>
        )}
        <A at={q.ansT} y={0} s={0.5} spring="bounce" style={{display: 'inline-flex', alignItems: 'center', gap: 12, background: C.red, borderRadius: 18, padding: '8px 26px 8px 18px', fontSize: 46, fontWeight: 700}}>
          <IcCheck size={40} stroke={4} />{q.answer}
        </A>
      </div>
      <div style={{position: 'absolute', left: 0, right: 0, top: 88}}>
        <A at={q.reason.t} y={12} end={noteT - 4} style={{fontSize: 31, fontWeight: 600, lineHeight: 1.4}}>{q.reason.text}</A>
        {q.note && (
          <A at={q.note.t} y={16} style={{position: 'absolute', left: 0, right: 0, top: 0, background: C.cream, color: C.dark, borderRadius: 18, padding: '14px 20px'}}>
            <div style={{fontSize: 19, fontWeight: 700, color: C.red, marginBottom: 6}}>{q.note.title}</div>
            {q.note.lines.map((l, k) => <A key={k} at={l.t} y={8} style={{fontSize: 28, fontWeight: 600, lineHeight: 1.35, marginTop: k ? 4 : 0}}>{l.text}</A>)}
          </A>
        )}
      </div>
    </div>
  );
};

const Tracker: React.FC<{q: QData}> = ({q}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const starts = [q.cue.r1, q.cue.r2, q.cue.r3, q.cue.r4, q.cue.r5].map((n) => T(n));
  const intro = 1 - prog(frame, starts[0], 14, EASE.inOut);
  const c = COL_H + intro * (INTRO_H - COL_H);
  const e = starts.map((s, i) => (i < 4 ? clamp01(prog(frame, s, 12, EASE.inOut) - prog(frame, starts[i + 1], 10, EASE.inOut)) : prog(frame, s, 12, EASE.inOut)));
  return (
    <div style={{position: 'absolute', left: 0, top: TRK_TOP, width: RW, height: TRK_H, display: 'flex', flexDirection: 'column', gap: GAP}}>
      {RULES.map((r, i) => {
        const h = c + e[i] * (EXP_H - c);
        const active = e[i] > 0.5;
        const done = i < 4 && frame >= starts[i + 1];
        const pend = !active && !done;
        const rowIn = anim(frame, fps, qStart(q) + 4 + i * 4, {y: 20, s: 0.97});
        return (
          <div key={i} style={{position: 'relative', height: h, flexShrink: 0, borderRadius: 22, overflow: 'hidden', boxSizing: 'border-box', border: `2px solid ${active ? C.red : 'rgba(255,255,255,0.16)'}`, background: active ? C.darkRaise : done ? 'rgba(255,255,255,0.04)' : 'transparent', ...rowIn}}>
            <div style={{position: 'absolute', left: 0, right: 0, top: 0, height: c, display: 'flex', alignItems: 'center', gap: 16, padding: '0 20px'}}>
              <Circle size={36} bg={active ? C.red : done ? C.cream : 'transparent'} fg={done ? C.dark : active ? C.white : C.gray} border={pend ? 'rgba(184,180,168,0.6)' : undefined} style={{fontSize: 17, border: pend ? '2px solid rgba(184,180,168,0.6)' : 'none'}}>
                {done ? <IcCheck size={20} stroke={4} /> : r.n}
              </Circle>
              <div style={{minWidth: 0}}>
                <div style={{fontSize: 24, fontWeight: 600, color: pend ? C.gray : C.white, lineHeight: 1.2}}>{r.label}</div>
                <div style={{fontSize: 19, color: C.gray, opacity: intro, height: intro > 0.05 ? 'auto' : 0, overflow: 'hidden', marginTop: 4}}>{r.hint}</div>
              </div>
            </div>
            <div style={{position: 'absolute', left: 20, right: 20, top: c + 4, bottom: 12, opacity: clamp01((e[i] - 0.45) / 0.45), overflow: 'hidden'}}>
              {e[i] > 0.01 && <RowBody i={i} q={q} />}
            </div>
          </div>
        );
      })}
    </div>
  );
};

/* ---------- intro card set (cues 47–52) ---------- */
const Intro: React.FC = () => {
  const end = qStart(QS[0]) - 10;
  const card: React.CSSProperties = {position: 'absolute', left: 0, width: RW, background: C.darkRaise, borderRadius: 30, padding: '30px 34px', boxSizing: 'border-box'};
  const eb: React.CSSProperties = {fontSize: 16, fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: C.gray};
  return (
    <>
      <A at={T(48)} end={end} y={30} style={{...card, top: 0, height: 360}}>
        <div style={eb}>Today’s Passage</div>
        <A at={T(49, 0, 2)} end={end} y={12} style={{display: 'inline-block', marginTop: 18, border: `2px solid ${C.red}`, borderRadius: 40, padding: '6px 18px', fontSize: 26, fontWeight: 600}}>Tanzania</A>
        <div style={{marginTop: 14, fontSize: 84, fontWeight: 700, lineHeight: 1.05}}><Words text="Dar es *Salaam*" at={T(49, 1, 2)} end={end} step={4} /></div>
        <div style={{display: 'flex', gap: 12, marginTop: 30, flexWrap: 'wrap'}}>
          <A at={T(50, 0, 2)} end={end} y={14} s={0.8} spring="bounce" style={{background: C.red, borderRadius: 40, padding: '10px 22px', fontSize: 28, fontWeight: 600}}>Population Growth</A>
          <A at={T(50, 1, 2)} end={end} y={14} s={0.8} spring="bounce" style={{background: C.cream, color: C.dark, borderRadius: 40, padding: '10px 22px', fontSize: 28, fontWeight: 600}}>Transportation Problems</A>
        </div>
      </A>
      <A at={T(51)} end={end} y={30} style={{...card, top: 384, height: 290}}>
        <div style={{fontSize: 40, fontWeight: 700}}>5 Questions</div>
        <div style={{display: 'flex', gap: 22, marginTop: 28}}>
          {QS.map((q, k) => <A key={k} at={T(51, k, 5)} end={end} y={16} s={0.5} spring="bounce"><Circle size={90} bg={C.red} fg={C.white} style={{fontSize: 34}}>Q{q.n}</Circle></A>)}
        </div>
      </A>
      <A at={T(52)} end={end} y={30} style={{...card, top: 698, height: 290}}>
        <div style={{fontSize: 40, fontWeight: 700}}>Same 5 Golden Rules</div>
        <div style={{display: 'flex', gap: 22, marginTop: 28}}>
          {RULES.map((r, k) => <A key={k} at={T(52, k, 5)} end={end} y={16} s={0.5} spring="bounce"><Circle size={90} bg={C.cream} fg={C.dark} style={{fontSize: 34}}>R{r.n}</Circle></A>)}
        </div>
      </A>
    </>
  );
};

export const Workspace: React.FC<SceneProps> = () => {
  return (
    <SceneShell tone="dark" shape="dots">
      <PassagePanel />
      <div style={{position: 'absolute', left: RX, top: PY, width: RW, height: PH}}>
        <Intro />
        {QS.map((q, qi) => (
          <A key={q.n} at={qStart(q)} end={QEND[qi]} y={34} s={0.97} style={{position: 'absolute', left: 0, top: 0, width: RW, height: PH}}>
            <QuestionCard q={q} qi={qi} />
            <Tracker q={q} />
          </A>
        ))}
      </div>
    </SceneShell>
  );
};
export {QEND};
