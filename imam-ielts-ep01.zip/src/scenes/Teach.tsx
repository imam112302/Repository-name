import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {C, EASE} from '../theme';
import {A, Circle, Hi, IcCheck, IcCross, IcQuestion, SceneShell, Words, lerp, prog} from '../ui';
import {T} from '../timing';
import {SceneProps} from './types';

/* S6 — TRUE / FALSE / NOT GIVEN কী (cues 19–29) */
const DEFS = [
  {id: 'TRUE', icon: <IcCheck size={52} stroke={4} />, bg: C.dark, fg: C.white, bd: undefined as string | undefined, kw: 'Same Meaning', sub: 'Statement ও Passage-এর Information-এর Meaning একই', t: T(20), te: T(22), tm: T(27), tme: T(28), chip: 'TRUE'},
  {id: 'FALSE', icon: <IcCross size={52} stroke={4} />, bg: C.red, fg: C.white, bd: undefined, kw: 'Opposite Meaning', sub: 'Statement ও Information পরস্পর Contradict করে', t: T(22), te: T(24), tm: T(28), tme: T(29), chip: 'FALSE'},
  {id: 'NOT GIVEN', icon: <IcQuestion size={56} stroke={3.6} />, bg: C.white, fg: C.dark, bd: C.dark, kw: 'No Information', sub: 'Statement সম্পর্কে Passage-এ পর্যাপ্ত Information নেই', t: T(24), te: T(26), tm: T(29), tme: T(29) + 200, chip: 'NOT GIVEN'},
];
export const Definitions: React.FC<SceneProps> = () => {
  const frame = useCurrentFrame();
  return (
    <SceneShell tone="cream" shape="dots">
      <div style={{position: 'absolute', left: 120, top: 56, fontSize: 70, fontWeight: 700, lineHeight: 1.1}}>
        <Words text="TRUE, FALSE ও NOT GIVEN — *আসলে কী?*" at={T(19)} step={4} />
      </div>
      {DEFS.map((d, k) => {
        const act = (frame >= d.t && frame < d.te) || (frame >= d.tm && frame < d.tme);
        const lift = prog(frame, act ? (frame >= d.tm ? d.tm : d.t) : 0, 10) * (act ? 1 : 0);
        return (
          <A key={d.id} at={T(19, k, 3)} y={70} s={0.9} spring="bounce" style={{position: 'absolute', left: 120 + k * 570, top: 190, width: 540, height: 520}}>
            <div style={{width: 540, height: 520, background: C.white, borderRadius: 40, boxSizing: 'border-box', padding: '36px 38px', border: `4px solid ${act ? C.red : C.dark}`, transform: `translateY(${-14 * lift}px)`, color: C.dark}}>
              <div style={{display: 'flex', alignItems: 'center', gap: 24}}>
                <Circle size={100} bg={d.bg} fg={d.fg} border={d.bd}>{d.icon}</Circle>
                <div style={{fontSize: 60, fontWeight: 700, lineHeight: 1}}>{d.id}</div>
              </div>
              <div style={{height: 3, background: 'rgba(21,17,13,0.14)', margin: '30px 0'}} />
              <A at={d.t} y={20} style={{fontSize: 54, fontWeight: 700, lineHeight: 1.1}}>
                {frame >= d.tm ? <Hi at={d.tm} dur={14}>{d.kw}</Hi> : d.kw}
              </A>
              <A at={d.t + 8} y={16} style={{fontSize: 30, fontWeight: 500, color: C.grayCream, lineHeight: 1.4, marginTop: 16}}>{d.sub}</A>
            </div>
          </A>
        );
      })}
      <A at={T(26)} y={16} style={{position: 'absolute', left: 120, top: 756, fontSize: 38, fontWeight: 700, color: C.red}}>মনে রাখবে</A>
      {DEFS.map((d, k) => (
        <A key={d.id} at={d.tm} y={30} s={0.85} spring="bounce" style={{position: 'absolute', left: 120 + k * 570, top: 830, width: 540, height: 96, background: C.dark, color: C.white, borderRadius: 28, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 14, fontSize: 38, fontWeight: 700, whiteSpace: 'nowrap'}}>
          <span>{d.kw}</span><span style={{color: C.red}}>=</span><span>{d.chip}</span>
        </A>
      ))}
    </SceneShell>
  );
};

/* S7 — Five Golden Rules (cues 30–44) */
type RuleRow = {n: number; title: string; start: number; chips: {t: number; text: string; kind?: 'strike' | 'hot'}[]};
const ROWS: RuleRow[] = [
  {n: 1, title: 'Read the Statement Carefully', start: T(31), chips: [{t: T(32), text: 'Statement ভালোভাবে পড়বে'}, {t: T(33), text: 'মূল বক্তব্য বুঝবে'}]},
  {n: 2, title: 'Identify the Keywords', start: T(34), chips: [{t: T(35), text: 'Keywords'}, {t: T(36, 0, 4), text: 'Names'}, {t: T(36, 1, 4), text: 'Numbers'}, {t: T(36, 2, 4), text: 'Dates'}, {t: T(36, 3, 4), text: 'Qualifying Words'}]},
  {n: 3, title: 'Locate the Information', start: T(37), chips: [{t: T(38, 0, 2), text: 'Keywords'}, {t: T(38, 1, 2), text: 'Synonyms'}, {t: T(39), text: 'Paraphrases'}]},
  {n: 4, title: 'Compare the Information', start: T(40), chips: [{t: T(41), text: 'Question ⇄ Passage'}, {t: T(42, 0, 2), text: 'Word Match', kind: 'strike'}, {t: T(42, 1, 2), text: 'Meaning Match', kind: 'hot'}]},
  {n: 5, title: 'Make the Decision', start: T(43), chips: [{t: T(44, 0, 3), text: 'TRUE'}, {t: T(44, 1, 3), text: 'FALSE'}, {t: T(44, 2, 3), text: 'NOT GIVEN'}]},
];
export const Rules: React.FC<SceneProps> = () => {
  const frame = useCurrentFrame();
  const lineH = 4 * 150 * Math.min(1, Math.max(0, prog(frame, ROWS[1].start, 12) * 0.25 + prog(frame, ROWS[2].start, 12) * 0.25 + prog(frame, ROWS[3].start, 12) * 0.25 + prog(frame, ROWS[4].start, 12) * 0.25));
  return (
    <SceneShell tone="dark" shape="lines">
      <div style={{position: 'absolute', left: 120, top: 52, fontSize: 84, fontWeight: 700, lineHeight: 1.1}}>
        <Words text="Five *Golden* Rules" at={T(30)} step={5} />
      </div>
      <div style={{position: 'absolute', left: 120 + 43, top: 210 + 44, width: 4, height: lineH, background: C.red, borderRadius: 4}} />
      {ROWS.map((r, k) => {
        const next = ROWS[k + 1]?.start ?? 1e9;
        const dim = prog(frame, next, 10) * 0.45;
        return (
          <React.Fragment key={r.n}>
            <A at={r.start} x={-50} y={0} style={{position: 'absolute', left: 120, top: 210 + k * 150, width: 1040, height: 140}}>
              <div style={{opacity: 1 - dim}}>
                <div style={{display: 'flex', alignItems: 'center', gap: 36}}>
                  <Circle size={90} bg={C.red} fg={C.white} style={{fontSize: 42}}>{r.n}</Circle>
                  <div style={{fontSize: 46, fontWeight: 700}}>{r.title}</div>
                </div>
                <div style={{display: 'flex', flexWrap: 'wrap', gap: 12, marginLeft: 126, marginTop: 12}}>
                  {r.chips.map((c, i) => (
                    <A key={i} at={c.t} y={12} s={0.85} spring="bounce" style={{borderRadius: 40, padding: '6px 20px', fontSize: 27, fontWeight: 600, whiteSpace: 'nowrap', border: `2px solid ${c.kind === 'hot' ? C.red : 'rgba(255,255,255,0.4)'}`, background: c.kind === 'hot' ? C.red : 'transparent', color: c.kind === 'strike' ? C.gray : C.white, textDecoration: c.kind === 'strike' ? 'line-through' : 'none', textDecorationColor: C.red, textDecorationThickness: 3}}>{c.text}</A>
                  ))}
                </div>
              </div>
            </A>
            <A at={r.start} end={next - 2} x={80} y={0} s={0.9} style={{position: 'absolute', left: 1250, top: 150, width: 560, textAlign: 'center'}}>
              <div style={{fontSize: 22, fontWeight: 700, letterSpacing: '0.2em', color: C.red}}>RULE</div>
              <div style={{fontSize: 620, fontWeight: 700, lineHeight: 1, color: C.darkRaise2}}>{r.n}</div>
            </A>
          </React.Fragment>
        );
      })}
    </SceneShell>
  );
};

/* S8 — চলো Solve করি (cues 45–46) */
const SHORT = ['Read', 'Keywords', 'Locate', 'Compare', 'Decide'];
export const LetsSolve: React.FC<SceneProps> = () => {
  const frame = useCurrentFrame();
  const conv = prog(frame, T(46), 16, EASE.inOut);
  return (
    <SceneShell tone="red" shape="blocks">
      <div style={{position: 'absolute', left: 0, right: 0, top: 150, textAlign: 'center', fontSize: 80, fontWeight: 700}}>
        <Words text="Apply the *Rules*" at={T(45)} end={T(46) + 4} step={5} />
      </div>
      {SHORT.map((s, k) => {
        const x = (k - 2) * 240;
        return (
          <A key={k} at={T(45, k, 5)} end={T(46) + 12} y={40} s={0.4} spring="bounce" style={{position: 'absolute', left: 960 - 75 + lerp(x, 0, conv), top: 360, width: 150, textAlign: 'center'}}>
            <div style={{transform: `scale(${1 - conv * 0.7})`, opacity: 1 - conv}}>
              <Circle size={150} bg={C.dark} fg={C.white} style={{fontSize: 56, margin: '0 auto'}}>R{k + 1}</Circle>
              <div style={{marginTop: 16, fontSize: 32, fontWeight: 600}}>{s}</div>
            </div>
          </A>
        );
      })}
      <A at={T(46) + 6} y={40} s={0.8} spring="bounce" style={{position: 'absolute', left: 960 - 460, top: 330, width: 920, height: 290, background: C.cream, color: C.dark, borderRadius: 44, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8}}>
        <div style={{fontSize: 86, fontWeight: 700, lineHeight: 1.1}}>Cambridge IELTS 21</div>
        <div style={{fontSize: 38, fontWeight: 600, color: C.grayCream}}>Reading Passage · 5 Questions</div>
      </A>
    </SceneShell>
  );
};
