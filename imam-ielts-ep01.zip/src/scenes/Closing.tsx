import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {C} from '../theme';
import {A, Circle, IcCheck, SceneShell, Words, anim, prog} from '../ui';
import {at, T} from '../timing';
import {QS} from '../qdata';
import {useVideoConfig} from 'remotion';
import {SceneProps} from './types';

const center: React.CSSProperties = {alignItems: 'center', justifyContent: 'center'};

/* S10 — Recap (cues 226–239) */
const ansStyle = (a: string): React.CSSProperties =>
  a === 'TRUE' ? {background: C.dark, color: C.white, border: `3px solid ${C.dark}`} : a === 'FALSE' ? {background: C.red, color: C.white, border: `3px solid ${C.red}`} : {background: C.white, color: C.dark, border: `3px solid ${C.dark}`};
export const Recap: React.FC<SceneProps> = () => {
  const frame = useCurrentFrame();
  const lit = [T(234), T(235), T(236), T(237), T(238)];
  const names = ['Read', 'Keywords', 'Locate', 'Compare', 'Decide'];
  return (
    <SceneShell tone="cream" shape="dots">
      <div style={{position: 'absolute', left: 120, top: 60, fontSize: 80, fontWeight: 700}}><Words text="FINAL *ANSWER* RECAP" at={T(226)} step={5} /></div>
      {QS.map((q, k) => (
        <A key={k} at={T(228 + k)} y={60} s={0.9} spring="bounce" style={{position: 'absolute', left: 120 + k * 341, top: 230, width: 316, height: 330, background: C.white, border: `3px solid ${C.dark}`, borderRadius: 36, boxSizing: 'border-box', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 34, color: C.dark}}>
          <Circle size={104} bg={C.dark} fg={C.white} style={{fontSize: 40}}>Q{q.n}</Circle>
          <A at={at(228 + k, 1, 2) - 5} y={0} s={0.4} spring="bounce" style={{...ansStyle(q.answer), borderRadius: 18, padding: '10px 18px', fontSize: q.answer === 'NOT GIVEN' ? 34 : 42, fontWeight: 700, whiteSpace: 'nowrap'}}>{q.answer}</A>
        </A>
      ))}
      <A at={T(234)} y={20} style={{position: 'absolute', left: 120, top: 626, fontSize: 36, fontWeight: 700, color: C.grayCream}}>Same Five Golden Rules</A>
      {names.map((n, k) => {
        const on = prog(frame, lit[k], 10);
        return (
          <A key={k} at={T(234, k, 5)} y={30} s={0.6} spring="bounce" style={{position: 'absolute', left: 120 + k * 341, top: 690, width: 316, display: 'flex', alignItems: 'center', gap: 16}}>
            <Circle size={90} bg={on > 0.5 ? C.red : C.white} fg={on > 0.5 ? C.white : C.dark} border={on > 0.5 ? undefined : C.dark} style={{fontSize: 36, transform: `scale(${1 + 0.12 * Math.sin(on * Math.PI)})`}}>{on > 0.5 ? <IcCheck size={44} stroke={4} /> : 'R' + (k + 1)}</Circle>
            <div style={{fontSize: 36, fontWeight: 700}}>{n}</div>
          </A>
        );
      })}
      <div style={{position: 'absolute', left: 120, top: 860, fontSize: 70, fontWeight: 700}}><Words text="TRUE, FALSE, NOT GIVEN-এর সঠিক *Approach*" at={T(239)} step={4} /></div>
    </SceneShell>
  );
};

/* S11 — Challenge (cues 240–248) */
const Typed: React.FC<{text: string; at: number; cps?: number}> = ({text, at: st, cps = 0.7}) => {
  const frame = useCurrentFrame();
  const n = Math.max(0, Math.min(text.length, Math.floor((frame - st) * cps)));
  const blink = Math.floor(frame / 8) % 2 === 0;
  return <>{text.slice(0, n)}<span style={{display: 'inline-block', width: 3, height: '1em', background: C.red, marginLeft: 3, verticalAlign: 'text-bottom', opacity: blink ? 1 : 0}} /></>;
};
export const Challenge: React.FC<SceneProps> = () => {
  const frame = useCurrentFrame();
  const s2 = T(244);
  const burst = T(248);
  return (
    <SceneShell tone="dark" shape="rings">
      <AbsoluteFill style={{...center, gap: 40}}>
        <div style={{fontSize: 120, fontWeight: 700, textAlign: 'center', lineHeight: 1.1}}>
          <Words text="YOUR PRACTICE" at={T(240)} end={s2 - 8} step={5} />
          <br /><Words text="*CHALLENGE*" at={T(240) + 10} end={s2 - 8} step={5} />
        </div>
        <div style={{display: 'flex', gap: 26}}>
          {QS.map((q, k) => (
            <A key={k} at={T(241, k, 5)} end={s2 - 8} y={30} s={0.4} spring="bounce"><Circle size={96} bg={C.cream} fg={C.dark} style={{fontSize: 36}}>Q{q.n}</Circle></A>
          ))}
        </div>
        <div style={{fontSize: 96, fontWeight: 700}}><Words text="এবার *তোমাদের* পালা" at={T(243)} end={s2 - 8} step={5} /></div>
      </AbsoluteFill>
      <div style={{position: 'absolute', left: 120, top: 190, width: 800, fontSize: 78, fontWeight: 700, lineHeight: 1.15}}>
        <Words text="কোন প্রশ্নটি সবচেয়ে *কঠিন?*" at={s2} step={4} />
      </div>
      <div style={{position: 'absolute', left: 120, top: 520, display: 'flex', gap: 22}}>
        {QS.map((q, k) => <A key={k} at={T(245, k, 5)} y={24} s={0.4} spring="bounce"><Circle size={100} bg={C.red} fg={C.white} style={{fontSize: 38}}>Q{q.n}</Circle></A>)}
      </div>
      <div style={{position: 'absolute', left: 120, top: 700, width: 780, fontSize: 54, fontWeight: 600, lineHeight: 1.3}}>
        <Words text="কমেন্টে *Question Number* লিখে জানাও" at={T(246)} step={3} />
      </div>
      <A at={s2 + 6} y={50} s={0.95} style={{position: 'absolute', left: 1000, top: 170, width: 800, height: 700, background: C.white, color: C.dark, borderRadius: 40, padding: 36, boxSizing: 'border-box'}}>
        <div style={{fontSize: 24, fontWeight: 700, letterSpacing: '0.1em', color: C.grayCream}}>COMMENTS</div>
        <div style={{display: 'flex', alignItems: 'center', gap: 18, marginTop: 28, border: `2px solid ${C.dark}`, borderRadius: 24, padding: '16px 20px'}}>
          <Circle size={56} bg={C.dark} fg={C.white} style={{fontSize: 22}}>You</Circle>
          <div style={{fontSize: 36, fontWeight: 600, minHeight: 46}}><Typed text="Question Number" at={T(246)} cps={0.55} /></div>
        </div>
        <A at={T(247)} y={30} s={0.9} spring="bounce" style={{display: 'flex', alignItems: 'center', gap: 18, marginTop: 40}}>
          <Circle size={72} bg={C.red} fg={C.white} style={{fontSize: 28}}>IE</Circle>
          <div style={{background: C.creamDeep, borderRadius: 28, padding: '20px 30px', fontSize: 50, fontWeight: 700}}><Typed text="FIVE OUT OF FIVE!" at={T(247, 0, 1) + 6} cps={0.5} /></div>
        </A>
      </A>
      {frame >= burst &&
        [...Array(18)].map((_, i) => {
          const a = (i / 18) * Math.PI * 2;
          const p = prog(frame, burst, 26);
          const r = 80 + 300 * p;
          return <div key={i} style={{position: 'absolute', left: 1400 + Math.cos(a) * r, top: 600 + Math.sin(a) * r * 0.8, width: i % 2 ? 22 : 16, height: i % 2 ? 22 : 16, borderRadius: i % 3 ? 22 : 4, background: i % 2 ? C.red : C.cream, opacity: 1 - p, transform: `rotate(${i * 40 + p * 180}deg)`}} />;
        })}
    </SceneShell>
  );
};

/* S12 — Closing message (cues 249–257) */
export const Message: React.FC<SceneProps> = () => {
  const frame = useCurrentFrame();
  const bEnd = T(253) - 8, cEnd = T(256) - 8;
  return (
    <SceneShell tone="red" shape="lines">
      <div style={{position: 'absolute', left: 140, top: 110, fontSize: 66, fontWeight: 700}}><Words text="IELTS Reading-এ ভালো করতে" at={T(249)} end={bEnd} step={4} /></div>
      <A at={T(249, 1, 2)} end={bEnd} y={50} s={0.9} spring="bounce" style={{position: 'absolute', left: 140, top: 320, width: 640, height: 360, background: C.dark, borderRadius: 40, display: 'flex', alignItems: 'center', justifyContent: 'center', color: C.gray, fontSize: 56, fontWeight: 700}}>
        <div style={{position: 'relative'}}>English Vocabulary
          <div style={{position: 'absolute', left: -10, top: '55%', height: 12, width: `${prog(frame, T(250), 16) * 104}%`, background: C.red, borderRadius: 8}} />
        </div>
      </A>
      <A at={T(251)} end={bEnd} x={80} y={0} style={{position: 'absolute', left: 860, top: 320, width: 900, height: 160, background: C.cream, color: C.dark, borderRadius: 36, display: 'flex', alignItems: 'center', padding: '0 44px', fontSize: 62, fontWeight: 700, gap: 24}}>
        <IcCheck size={64} stroke={4} /> Passage <span style={{color: C.red}}>Analyse</span>
      </A>
      <A at={T(252)} end={bEnd} x={80} y={0} style={{position: 'absolute', left: 860, top: 520, width: 900, height: 160, background: C.cream, color: C.dark, borderRadius: 36, display: 'flex', alignItems: 'center', padding: '0 44px', fontSize: 62, fontWeight: 700, gap: 24}}>
        <IcCheck size={64} stroke={4} /> সঠিক <span style={{color: C.red}}>Information</span> খোঁজা
      </A>
      {[
        {t: T(253), a: '01', b: 'নিয়মিত *Practice*'},
        {t: T(254), a: '02', b: '*Strategies* Follow'},
        {t: T(255), a: '03', b: 'Reading *Skills* Improve'},
      ].map((s, k) => (
        <A key={k} at={s.t} end={cEnd} y={70} s={0.9} spring="bounce" style={{position: 'absolute', left: 120 + k * 580, top: 330, width: 540, height: 380, background: C.dark, borderRadius: 40, padding: 40, boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: 40}}>
          <Circle size={110} bg={C.red} fg={C.white} style={{fontSize: 44, border: `3px solid ${C.white}`}}>{s.a}</Circle>
          <div style={{fontSize: 56, fontWeight: 700, lineHeight: 1.2}}><Words text={s.b} at={s.t + 6} end={cEnd} em={C.red} step={4} /></div>
        </A>
      ))}
      <AbsoluteFill style={{...center, textAlign: 'center'}}>
        <A at={T(256)} y={30} style={{position: 'relative', fontSize: 100, fontWeight: 700, color: C.dark, lineHeight: 1.1}}>
          Answer শেখানো নয়
          <div style={{position: 'absolute', left: -8, top: '56%', height: 12, width: `${prog(frame, T(256) + 24, 14) * 104}%`, background: C.white, borderRadius: 8}} />
        </A>
        <div style={{fontSize: 170, fontWeight: 700, lineHeight: 1.15, marginTop: 20}}><Words text="*Independent*" at={T(257)} step={5} em={C.dark} /><br /><Words text="Problem Solver" at={T(257) + 10} step={5} /></div>
      </AbsoluteFill>
    </SceneShell>
  );
};

/* S13 — End card (cues 258–260) */
export const End: React.FC<SceneProps> = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const lift = -60 * prog(frame, T(259), 20);
  return (
    <SceneShell tone="dark" shape="rings">
      <AbsoluteFill style={{...center, transform: `translateY(${lift}px)`}}>
        <A at={T(258)} y={30} style={{fontSize: 52, fontWeight: 500, color: C.gray}}>This is</A>
        <div style={{display: 'flex', gap: 36, fontSize: 220, fontWeight: 700, lineHeight: 1.05}}>
          <A at={T(258) + 4} y={80} s={1.25} spring="bounce">IMAM</A>
          <A at={T(258) + 10} y={80} s={1.25} spring="bounce" style={{color: C.red}}>IELTS</A>
        </div>
        <div style={{marginTop: 36, fontSize: 62, fontWeight: 600, textAlign: 'center', lineHeight: 1.35}}>
          {['Learn the *Rules.*', 'Apply the *Rules.*', 'Master *IELTS Reading.*'].map((l, k) => (
            <div key={k}><Words text={l} at={T(259, k, 3)} step={4} y={22} /></div>
          ))}
        </div>
      </AbsoluteFill>
      <A at={T(260)} y={40} s={0.8} spring="bounce" style={{position: 'absolute', left: 0, right: 0, top: 900, display: 'flex', justifyContent: 'center'}}>
        <div style={{background: C.red, borderRadius: 60, padding: '14px 52px', fontSize: 52, fontWeight: 700}}>See you in the next episode!</div>
      </A>
    </SceneShell>
  );
};
void anim;
