import {QS} from './qdata';
import {at, cs, T, TR} from './timing';

export type SfxType = 'pop' | 'click' | 'tick' | 'whoosh' | 'swipe' | 'chime' | 'thud';
export type SfxEvent = {f: number; type: SfxType};
export const SFX_VOL: Record<SfxType, number> = {pop: 0.3, click: 0.34, tick: 0.2, whoosh: 0.24, swipe: 0.26, chime: 0.28, thud: 0.3};

// scene boundaries: first cue of every scene after the first
export const SCENE_FIRST_CUES = [4, 5, 10, 17, 19, 30, 45, 47, 226, 240, 249, 258];

export function buildSfx(): SfxEvent[] {
  const e: SfxEvent[] = [];
  const add = (f: number, type: SfxType) => e.push({f: Math.max(0, f), type});
  SCENE_FIRST_CUES.forEach((n) => add(cs(n) - TR + 1, 'swipe'));
  // S1
  add(2, 'thud'); add(9, 'pop'); add(T(2), 'whoosh'); add(T(3), 'pop'); [0, 1, 2].forEach((k) => add(T(3, k, 3), 'tick'));
  // S2, S3
  [0, 1, 2].forEach((k) => add(T(4, k, 3), 'pop'));
  [0, 1, 2].forEach((k) => add(T(5, k, 3), 'pop')); add(T(6), 'click'); add(T(7), 'thud'); add(T(8), 'whoosh'); add(T(9), 'pop');
  // S4
  add(T(10), 'whoosh'); add(T(10) + 40, 'click'); add(T(11), 'pop'); [0, 1, 2, 3, 4].forEach((k) => { add(T(12, k, 5), 'tick'); add(T(13, k, 5), 'click'); });
  add(T(14), 'whoosh'); add(T(16), 'chime');
  // S5
  add(T(17), 'whoosh'); add(T(17) + 12, 'chime'); add(T(18), 'pop');
  // S6
  [0, 1, 2].forEach((k) => add(T(19, k, 3), 'pop')); [20, 22, 24].forEach((n) => add(T(n), 'click')); [27, 28, 29].forEach((n) => add(T(n), 'pop'));
  // S7
  add(T(30), 'whoosh'); [31, 34, 37, 40, 43].forEach((n) => add(T(n), 'pop')); add(T(42, 1, 2), 'click');
  // S8
  [0, 1, 2, 3, 4].forEach((k) => add(T(45, k, 5), 'tick')); add(T(46), 'whoosh'); add(T(46) + 12, 'chime');
  // Workspace
  add(T(47), 'whoosh'); add(T(49, 1, 2), 'pop'); add(T(51), 'click'); add(T(52), 'click');
  QS.forEach((q) => {
    add(T(q.cue.q), 'pop');
    [q.cue.r1, q.cue.r2, q.cue.r3, q.cue.r4, q.cue.r5].forEach((n) => add(T(n), 'click'));
    q.kws.forEach((k) => add(k.t, 'tick'));
    q.evidence.forEach((ev) => add(ev.t, 'click'));
    add(q.ansT, 'thud'); add(q.ansT + 4, 'chime');
    if (q.note) add(q.note.t, 'pop');
  });
  // Recap
  [0, 1, 2, 3, 4].forEach((k) => { add(T(228 + k), 'pop'); add(at(228 + k, 1, 2) - 5, 'tick'); });
  add(T(234), 'pop'); [235, 236, 237, 238].forEach((n) => add(T(n), 'click')); add(T(239), 'chime');
  // Challenge
  add(T(240), 'whoosh'); [0, 1, 2, 3, 4].forEach((k) => add(T(241, k, 5), 'tick')); add(T(243), 'thud'); add(T(244), 'pop'); add(T(246), 'click'); add(T(247), 'pop'); add(T(248), 'chime');
  // Closing
  add(T(249), 'whoosh'); add(T(250), 'click'); add(T(251), 'pop'); add(T(252), 'pop'); [253, 254, 255].forEach((n) => add(T(n), 'pop')); add(T(256), 'whoosh'); add(T(257), 'chime');
  // End
  add(T(258), 'chime'); add(T(259), 'whoosh'); add(T(260), 'pop');
  return e.sort((a, b) => a.f - b.f);
}
export const SFX_EVENTS = buildSfx();
