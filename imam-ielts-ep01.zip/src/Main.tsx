import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {ToneName} from './theme';
import {EASE} from './theme';
import {prog} from './ui';
import {TR, cs} from './timing';
import {PreviewAudio} from './PreviewAudio';
import {Sfx} from './Sfx';
import {SceneProps} from './scenes/types';
import {Confusion, Hook, Promise_, Tagline, Welcome} from './scenes/Opening';
import {Definitions, LetsSolve, Rules} from './scenes/Teach';
import {Workspace} from './scenes/Workspace';
import {Challenge, End, Message, Recap} from './scenes/Closing';

type Wipe = 'none' | 'right' | 'up' | 'iris' | 'left';
type SceneDef = {id: string; first: number; tone: ToneName; wipe: Wipe; C: React.FC<SceneProps>};

// ব্যাকগ্রাউন্ড একটার পর একটা বদলায়: dark → red → cream → dark → red → cream → dark → red → dark → cream → dark → red → dark
const SCENES: SceneDef[] = [
  {id: 'hook', first: 1, tone: 'dark', wipe: 'none', C: Hook},
  {id: 'tagline', first: 4, tone: 'red', wipe: 'right', C: Tagline},
  {id: 'confusion', first: 5, tone: 'cream', wipe: 'up', C: Confusion},
  {id: 'promise', first: 10, tone: 'dark', wipe: 'iris', C: Promise_},
  {id: 'welcome', first: 17, tone: 'red', wipe: 'left', C: Welcome},
  {id: 'definitions', first: 19, tone: 'cream', wipe: 'right', C: Definitions},
  {id: 'rules', first: 30, tone: 'dark', wipe: 'up', C: Rules},
  {id: 'letssolve', first: 45, tone: 'red', wipe: 'iris', C: LetsSolve},
  {id: 'workspace', first: 47, tone: 'dark', wipe: 'right', C: Workspace},
  {id: 'recap', first: 226, tone: 'cream', wipe: 'up', C: Recap},
  {id: 'challenge', first: 240, tone: 'dark', wipe: 'iris', C: Challenge},
  {id: 'message', first: 249, tone: 'red', wipe: 'left', C: Message},
  {id: 'end', first: 258, tone: 'dark', wipe: 'right', C: End},
];
const FRAMES = SCENES.map((s, i) => ({from: i === 0 ? 0 : cs(s.first), to: i < SCENES.length - 1 ? cs(SCENES[i + 1].first) : 1e9}));

const clip = (w: Wipe, p: number): string | undefined => {
  if (w === 'none' || p >= 1) return undefined;
  const r = (1 - p) * 100;
  if (w === 'right') return `inset(0 ${r}% 0 0)`;
  if (w === 'left') return `inset(0 0 0 ${r}%)`;
  if (w === 'up') return `inset(${r}% 0 0 0)`;
  return `circle(${p * 150}% at 50% 50%)`;
};

export const Main: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{background: '#15110D'}}>
      {SCENES.map((s, i) => {
        const {from, to} = FRAMES[i];
        if (frame < from - TR || frame >= to) return null;
        const p = prog(frame, from - TR, TR, EASE.inOut);
        return (
          <AbsoluteFill key={s.id} style={{clipPath: clip(s.wipe, p)}}>
            <s.C from={from} to={to} />
          </AbsoluteFill>
        );
      })}
      <PreviewAudio />
      <Sfx />
    </AbsoluteFill>
  );
};
