import React from 'react';
import {Audio, Sequence, staticFile} from 'remotion';
import {SFX_ENABLED} from './config';
import {SFX_EVENTS, SFX_VOL, SfxType} from './sfxPlan';

const LEN: Record<SfxType, number> = {pop: 0.22, click: 0.12, tick: 0.07, whoosh: 0.62, swipe: 0.45, chime: 0.5, thud: 0.34};
export const Sfx: React.FC = () => {
  if (!SFX_ENABLED) return null;
  return (
    <>
      {SFX_EVENTS.map((ev, i) => {
        const rate = 1 + ((i % 3) - 1) * 0.05; // পরপর একই সাউন্ডে সামান্য pitch ভ্যারিয়েশন
        return (
          <Sequence key={i} from={ev.f} durationInFrames={Math.ceil(LEN[ev.type] * 30 / rate) + 2}>
            <Audio src={staticFile(`sfx/${ev.type}.wav`)} volume={SFX_VOL[ev.type] * (0.92 + (i % 4) * 0.03)} playbackRate={rate} />
          </Sequence>
        );
      })}
    </>
  );
};
