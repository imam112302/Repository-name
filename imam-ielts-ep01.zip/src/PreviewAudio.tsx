import React, {useEffect, useState} from 'react';
import {Audio, continueRender, delayRender, getRemotionEnvironment, staticFile} from 'remotion';
import {VOICEOVER_IN_RENDER, VOICEOVER_PREVIEW} from './config';

/** public/voiceover.mp3 থাকলে বাজবে, না থাকলে নীরবে বাদ। */
export const PreviewAudio: React.FC = () => {
  const env = getRemotionEnvironment();
  const enabled = VOICEOVER_PREVIEW && (!env.isRendering || VOICEOVER_IN_RENDER);
  const [ok, setOk] = useState(false);
  const [handle] = useState(() => delayRender('voiceover-check'));

  useEffect(() => {
    let alive = true;
    const done = () => continueRender(handle);
    if (!enabled) {
      done();
      return;
    }
    const ctrl = new AbortController();
    fetch(staticFile('voiceover.mp3'), {signal: ctrl.signal})
      .then((r) => {
        if (alive && r.ok && (r.headers.get('content-type') || '').startsWith('audio')) setOk(true);
        ctrl.abort();
      })
      .catch(() => undefined)
      .finally(done);
    return () => {
      alive = false;
      ctrl.abort();
    };
  }, [enabled, handle]);

  return ok ? <Audio src={staticFile('voiceover.mp3')} /> : null;
};
