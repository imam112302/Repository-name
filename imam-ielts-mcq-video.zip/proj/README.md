# Imam IELTS: MCQ video (Remotion)

    npm install
    npx remotion studio src/index.ts
    npx remotion render src/index.ts Main out/video.mp4

- Composition ID: `Main`, 1920x1080, 30fps, duration comes from `public/subtitles.srt` (all timing is SRT-derived; see `src/timing.ts`).
- Optional voiceover: put `public/voiceover.mp3` (plays in Studio). To bake it into the render set `config.voiceover.inRender = true` in `src/config.ts`.
- SFX: `public/sfx/*.wav` (regenerate with `npm run sfx`). Switch off with `config.sfx = false`.
- Colours, easings, springs, font: `src/theme.ts`. Passage and question text: `src/data/passage.ts`. Exam timeline: `src/data/exam.ts`.
- If you edit the SRT: `npm run cues` regenerates `src/data/cues.ts`.
