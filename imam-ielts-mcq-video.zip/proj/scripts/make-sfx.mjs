// Synthesizes a small, clean UI/motion-graphics SFX kit into public/sfx/*.wav (16-bit mono, 44.1kHz)
// Sounds: whoosh, swish, pop, click, chime, thud. Short, soft attack, fast decay, low-passed, tiny reverb.
import fs from 'node:fs';

const SR = 44100;
const outDir = new URL('../public/sfx/', import.meta.url);
fs.mkdirSync(outDir, {recursive: true});

// deterministic noise
let seed = 20260101;
const rnd = () => {
  seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};
const noise = () => rnd() * 2 - 1;

// RBJ biquad (time-varying friendly)
const biquad = (type) => {
  let x1 = 0, x2 = 0, y1 = 0, y2 = 0;
  return (x, fc, q = 0.707) => {
    const w = (2 * Math.PI * Math.min(fc, SR * 0.45)) / SR;
    const cw = Math.cos(w), sw = Math.sin(w), al = sw / (2 * q);
    let b0, b1, b2, a0 = 1 + al, a1 = -2 * cw, a2 = 1 - al;
    if (type === 'lp') { b0 = (1 - cw) / 2; b1 = 1 - cw; b2 = (1 - cw) / 2; }
    else if (type === 'hp') { b0 = (1 + cw) / 2; b1 = -(1 + cw); b2 = (1 + cw) / 2; }
    else { b0 = al; b1 = 0; b2 = -al; } // bandpass (constant 0 dB peak)
    const y = (b0 / a0) * x + (b1 / a0) * x1 + (b2 / a0) * x2 - (a1 / a0) * y1 - (a2 / a0) * y2;
    x2 = x1; x1 = x; y2 = y1; y1 = y;
    return y;
  };
};

// very small reverb: 2 feedback combs
const smallReverb = (buf, mix = 0.12) => {
  const taps = [[Math.floor(SR * 0.021), 0.28], [Math.floor(SR * 0.034), 0.22]];
  const out = new Float32Array(buf.length);
  for (const [d, g] of taps) {
    for (let n = 0; n < buf.length; n++) {
      const prev = n >= d ? out[n - d] : 0;
      out[n] += (n >= d ? buf[n - d] : 0) * g * 0.5 + prev * g * 0.4;
    }
  }
  const res = new Float32Array(buf.length);
  for (let n = 0; n < buf.length; n++) res[n] = buf[n] + out[n] * mix * 4;
  return res;
};

const gen = (len, fn) => {
  const N = Math.floor(len * SR);
  const b = new Float32Array(N);
  for (let n = 0; n < N; n++) b[n] = fn(n / SR, n);
  return b;
};
const fadeEnds = (b, inMs, outMs) => {
  const i = Math.floor((inMs / 1000) * SR), o = Math.floor((outMs / 1000) * SR);
  for (let n = 0; n < i && n < b.length; n++) b[n] *= n / i;
  for (let n = 0; n < o && n < b.length; n++) b[b.length - 1 - n] *= n / o;
  return b;
};

const sounds = {};

// pop: sine with fast pitch drop + tiny envelope
sounds.pop = (() => {
  let ph = 0; const lp = biquad('lp');
  const b = gen(0.18, (t) => {
    const f = 180 + 360 * Math.exp(-t / 0.035);
    ph += (2 * Math.PI * f) / SR;
    const env = (1 - Math.exp(-t / 0.003)) * Math.exp(-t / 0.05);
    return lp(Math.sin(ph) * env, 4200);
  });
  return fadeEnds(smallReverb(b, 0.08), 1, 25);
})();

// click: high-passed noise burst + faint tick
sounds.click = (() => {
  const hp = biquad('hp'), lp = biquad('lp'); let ph = 0;
  const b = gen(0.12, (t) => {
    ph += (2 * Math.PI * 2400) / SR;
    const n = noise() * Math.exp(-t / 0.007);
    const tick = Math.sin(ph) * Math.exp(-t / 0.006) * 0.35;
    return lp(hp(n * 0.8 + tick, 1800), 7000);
  });
  return fadeEnds(b, 0.5, 15);
})();

// whoosh: band-pass noise sweep with fade in/out
const whooshMaker = (len, f0, f1, q) => {
  const bp = biquad('bp'), lp = biquad('lp');
  const b = gen(len, (t) => {
    const p = t / len;
    const fc = f0 * Math.pow(f1 / f0, p);
    const env = Math.pow(Math.sin(Math.PI * Math.min(1, p * 1.05)), 2) * (0.4 + 0.6 * p);
    return lp(bp(noise(), fc, q) * env, 5000);
  });
  return fadeEnds(smallReverb(b, 0.08), 20, 60);
};
sounds.whoosh = whooshMaker(0.62, 300, 2600, 0.9);
sounds.swish = whooshMaker(0.32, 600, 3200, 1.1);

// chime: soft pluck with gentle overtones
sounds.chime = (() => {
  const lp = biquad('lp');
  const parts = [[880, 1], [1318.5, 0.45], [1760, 0.2]];
  const b = gen(0.5, (t) => {
    let s = 0;
    for (const [f, a] of parts) s += Math.sin(2 * Math.PI * f * t) * a * Math.exp(-t / (0.15 / (f / 880)));
    return lp(s * (1 - Math.exp(-t / 0.003)), 6000);
  });
  return fadeEnds(smallReverb(b, 0.1), 1, 60);
})();

// thud: very soft low thump (hook accent)
sounds.thud = (() => {
  let ph = 0; const lp = biquad('lp');
  const b = gen(0.4, (t) => {
    const f = 52 + 60 * Math.exp(-t / 0.06);
    ph += (2 * Math.PI * f) / SR;
    const env = (1 - Math.exp(-t / 0.006)) * Math.exp(-t / 0.11);
    return lp(Math.sin(ph) * env, 240);
  });
  return fadeEnds(b, 1, 60);
})();

// level matching: equal RMS, peak cap, report
const TARGET_RMS = 0.11, PEAK_CAP = 0.8;
const writeWav = (name, f32) => {
  const N = f32.length;
  const buf = Buffer.alloc(44 + N * 2);
  buf.write('RIFF', 0); buf.writeUInt32LE(36 + N * 2, 4); buf.write('WAVEfmt ', 8);
  buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(SR, 24); buf.writeUInt32LE(SR * 2, 28); buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34);
  buf.write('data', 36); buf.writeUInt32LE(N * 2, 40);
  for (let n = 0; n < N; n++) buf.writeInt16LE(Math.max(-32768, Math.min(32767, Math.round(f32[n] * 32767))), 44 + n * 2);
  fs.writeFileSync(new URL(name + '.wav', outDir), buf);
};

console.log('name     len(s)  peak   rms    clip');
for (const [name, b] of Object.entries(sounds)) {
  let sum = 0, cnt = 0;
  for (const v of b) if (Math.abs(v) > 1e-4) { sum += v * v; cnt++; }
  const rms = Math.sqrt(sum / Math.max(1, cnt));
  let g = TARGET_RMS / rms;
  let peak = 0; for (const v of b) peak = Math.max(peak, Math.abs(v * g));
  if (peak > PEAK_CAP) g *= PEAK_CAP / peak;
  const out = b.map((v) => v * g);
  let pk = 0, clip = 0, s2 = 0, c2 = 0;
  for (const v of out) { pk = Math.max(pk, Math.abs(v)); if (Math.abs(v) >= 0.999) clip++; if (Math.abs(v) > 1e-4) { s2 += v * v; c2++; } }
  writeWav(name, out);
  console.log(`${name.padEnd(8)} ${(out.length / SR).toFixed(2).padStart(5)}  ${pk.toFixed(2)}   ${Math.sqrt(s2 / c2).toFixed(3)}  ${clip === 0 ? 'none' : clip}`);
}
