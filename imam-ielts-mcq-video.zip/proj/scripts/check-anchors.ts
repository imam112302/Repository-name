import {T} from '../src/timing';
import {questions, marks, overviewBeats, answerRows, answersStart} from '../src/data/exam';
import {paragraphs, optionTexts, questionTexts} from '../src/data/passage';

let bad = 0;
const t = (a: any, where: string) => { try { T(a); } catch (e: any) { bad++; console.log('BAD', where, e.message); } };
for (const q of questions) {
  t(q.start, `Q${q.n}.start`);
  q.beats.forEach((b, i) => t(b.a, `Q${q.n}.beat${i}`));
  q.qmarks.forEach((b, i) => t(b.a, `Q${q.n}.qmark${i}`));
  q.focus.forEach((b, i) => t(b.a, `Q${q.n}.focus${i}`));
  q.verdicts.forEach((b, i) => t(b.a, `Q${q.n}.verdict${i}`));
  q.scroll.forEach((b, i) => t(b.a, `Q${q.n}.scroll${i}`));
  q.qmarks.forEach((m) => { if (!q.question.includes(m.text)) { bad++; console.log('BAD qmark text', m.text); } });
  // beats sorted
  const fr = q.beats.map((b) => T(b.a));
  for (let i = 1; i < fr.length; i++) if (fr[i] < fr[i - 1]) { bad++; console.log(`BAD order Q${q.n} beat${i}: ${fr[i - 1]} -> ${fr[i]}`); }
  const ff = q.focus.map((b) => T(b.a)); for (let i = 1; i < ff.length; i++) if (ff[i] < ff[i - 1]) { bad++; console.log(`BAD focus order Q${q.n} ${i}`); }
  const fs2 = q.scroll.map((b) => T(b.a)); for (let i = 1; i < fs2.length; i++) if (fs2[i] < fs2[i - 1]) { bad++; console.log(`BAD scroll order Q${q.n} ${i}`); }
}
overviewBeats.forEach((b, i) => t(b.a, `ov.beat${i}`));
t(answersStart, 'answersStart'); answerRows.forEach((r, i) => t(r.a, `ans${i}`));
// marks
const spans: Record<number, [number, number, string][]> = {};
for (const m of marks) {
  t(m.a, `mark ${m.id}`); (m.pulse ?? []).forEach((p) => t(p, `pulse ${m.id}`));
  const p = paragraphs[m.para]; const idx = p.indexOf(m.text);
  if (idx < 0) { bad++; console.log('BAD mark text', m.id); continue; }
  if (p.indexOf(m.text, idx + 1) >= 0) { bad++; console.log('AMBIGUOUS mark', m.id); }
  (spans[m.para] ??= []).push([idx, idx + m.text.length, m.id]);
}
for (const [k, arr] of Object.entries(spans)) {
  arr.sort((a, b) => a[0] - b[0]);
  for (let i = 1; i < arr.length; i++) if (arr[i][0] < arr[i - 1][1]) { bad++; console.log('OVERLAP', k, arr[i - 1][2], arr[i][2]); }
}
console.log(bad === 0 ? 'ALL ANCHORS OK' : `${bad} problems`);
