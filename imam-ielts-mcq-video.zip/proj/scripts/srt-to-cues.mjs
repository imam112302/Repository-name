// public/subtitles.srt -> src/data/cues.ts  (SRT is the only timing source of truth)
import fs from 'node:fs';

const srcPath = new URL('../public/subtitles.srt', import.meta.url);
const outPath = new URL('../src/data/cues.ts', import.meta.url);
const raw = fs.readFileSync(srcPath, 'utf8').replace(/\r/g, '').replace(/^\uFEFF/, '');
const ts = (s) => {
  const m = s.match(/(\d+):(\d+):(\d+)[,.](\d+)/);
  return +m[1] * 3600 + +m[2] * 60 + +m[3] + +m[4] / 1000;
};
const cues = raw.trim().split(/\n\s*\n/).map((b) => {
  const L = b.split('\n');
  const [a, z] = L[1].split('-->');
  return { i: +L[0], start: ts(a.trim()), end: ts(z.trim()), text: L.slice(2).join(' ').trim() };
});
const out =
  '// AUTO-GENERATED from public/subtitles.srt by scripts/srt-to-cues.mjs. Do not edit by hand.\n' +
  'export type Cue = {i: number; start: number; end: number; text: string};\n' +
  'export const cues: Cue[] = ' + JSON.stringify(cues, null, 1) + ';\n';
fs.writeFileSync(outPath, out);
console.log(`cues: ${cues.length}, last end: ${cues[cues.length - 1].end}s`);
