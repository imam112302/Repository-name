import fs from 'node:fs';
import {T} from '../src/timing';
let bad = 0, n = 0;
for (const file of ['intro', 'rules', 'outro', 'exam']) {
  const src = fs.readFileSync(new URL(`../src/scenes/${file}.tsx`, import.meta.url), 'utf8');
  for (const m of src.matchAll(/\[(\d+),\s*'([^']+)'\]/g)) {
    n++;
    try { T([+m[1], m[2]]); } catch (e: any) { bad++; console.log(file, e.message); }
  }
}
console.log(`${n} scene anchors checked, ${bad} bad`);
