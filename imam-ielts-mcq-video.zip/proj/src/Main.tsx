import React, {useEffect, useState} from 'react';
import {AbsoluteFill, Sequence, continueRender, delayRender} from 'remotion';
import {PreviewAudio, SceneBg} from './components/base';
import {font} from './theme';
import {sceneDur, sceneFrom, sceneList, type SceneId} from './timing';
import {HookScene, OverviewScene, PainScene, ParaphraseScene, WhatIsScene, WhyScene} from './scenes/intro';
import {RulesScene} from './scenes/rules';
import {ExamScene} from './scenes/exam';
import {ChallengeScene, OutroScene, PracticeScene, RecapScene, TimeScene, TipsScene} from './scenes/outro';

const SCENES: Record<SceneId, React.FC> = {
  hook: HookScene, pain: PainScene, why: WhyScene, overview: OverviewScene, whatis: WhatIsScene, paraphrase: ParaphraseScene,
  rules: RulesScene, exam: ExamScene, recap: RecapScene, time: TimeScene, tips: TipsScene,
  challenge: ChallengeScene, practice: PracticeScene, outro: OutroScene,
};

export const Main: React.FC = () => {
  const [handle] = useState(() => delayRender('load fonts'));
  const [ready, setReady] = useState(false);
  useEffect(() => {
    font.waitUntilDone().catch(() => undefined).then(() => { setReady(true); continueRender(handle); });
  }, [handle]);
  if (!ready) return <AbsoluteFill />;
  return (
    <AbsoluteFill>
      {sceneList.map((s, i) => {
        const Scene = SCENES[s.id];
        return (
          <Sequence key={s.id} from={sceneFrom(s.id)} durationInFrames={sceneDur(s.id)} name={s.id}>
            <SceneBg tone={s.bg} seed={i}><Scene /></SceneBg>
          </Sequence>
        );
      })}
      <PreviewAudio />
    </AbsoluteFill>
  );
};
