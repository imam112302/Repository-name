import React from 'react';
import {useCurrentFrame} from 'remotion';

/** Absolutely positioned box (scene-local layout helper). */
export const Abs: React.FC<{x?: number; y?: number; w?: number; h?: number; r?: number; b?: number; style?: React.CSSProperties; children?: React.ReactNode}> = ({x, y, w, h, r, b, style, children}) => (
  <div style={{position: 'absolute', left: x, top: y, width: w, height: h, right: r, bottom: b, ...style}}>{children}</div>
);

/** Mounts children only between scene-local frames (plus a short exit tail). */
export const Pane: React.FC<{from: number; to: number; children?: React.ReactNode}> = ({from, to, children}) => {
  const f = useCurrentFrame();
  if (f < from - 2 || f > to + 14) return null;
  return <>{children}</>;
};
