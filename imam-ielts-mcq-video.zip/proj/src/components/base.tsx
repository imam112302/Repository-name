import React, {createContext, useContext, useEffect, useState} from 'react';
import {
  AbsoluteFill, Audio, Sequence, continueRender, delayRender, getRemotionEnvironment,
  interpolate, spring, staticFile, useCurrentFrame, useVideoConfig,
} from 'remotion';
import {alpha, colors, eases, fontFamily, hardShadow, pals, radius, springs, type Pal} from '../theme';
import {config} from '../config';

// ------------------------------------------------------------------ palette context
const PalContext = createContext<Pal>(pals.dark);
export const usePal = () => useContext(PalContext);

export const clamp01 = (v: number) => Math.max(0, Math.min(1, v));
export const ramp = (f: number, from: number, dur = 14, easing: (t: number) => number = eases.out) =>
  interpolate(f, [from, from + dur], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing});

// ------------------------------------------------------------------ scene background (flat, 3 colours)
export const SceneBg: React.FC<{tone: 'dark' | 'cream' | 'red'; seed?: number; children?: React.ReactNode}> = ({tone, seed = 0, children}) => {
  const pal = pals[tone];
  const f = useCurrentFrame();
  const d = Math.sin(f / 90 + seed) * 18;
  return (
    <PalContext.Provider value={pal}>
      <AbsoluteFill style={{background: pal.bg, color: pal.fg, fontFamily, letterSpacing: 0, overflow: 'hidden'}}>
        <div style={{position: 'absolute', width: 900, height: 900, borderRadius: '50%', border: `3px solid ${pal.line}`, right: -300 + d, top: -330 - d}} />
        <div style={{position: 'absolute', width: 420, height: 420, borderRadius: '50%', background: pal.line, left: -150 - d, bottom: -200 + d, opacity: 0.7}} />
        {children}
      </AbsoluteFill>
    </PalContext.Provider>
  );
};

// ------------------------------------------------------------------ entrances
type Dir = 'up' | 'down' | 'left' | 'right' | 'none';
type SpringCfg = {damping: number; stiffness: number; mass: number};

export const useIn = (at: number, cfg: SpringCfg = springs.snappy) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  return f < at ? 0 : spring({frame: f - at, fps, config: cfg});
};

export const Pop: React.FC<{
  at?: number; until?: number; dir?: Dir; dist?: number; from?: number; cfg?: SpringCfg;
  style?: React.CSSProperties; children?: React.ReactNode;
}> = ({at = 0, until, dir = 'up', dist = 40, from = 0.92, cfg = springs.snappy, style, children}) => {
  const f = useCurrentFrame();
  const t = useIn(at, cfg);
  const o = clamp01(t * 1.7);
  const ex = until === undefined ? 0 : ramp(f, until, 10, eases.in);
  const k = (1 - t) * dist;
  const x = dir === 'left' ? -k : dir === 'right' ? k : 0;
  const y = dir === 'up' ? k : dir === 'down' ? -k : 0;
  return (
    <div style={{opacity: f < at ? 0 : o * (1 - ex), transform: `translate(${x}px, ${y - ex * dist * 0.4}px) scale(${from + (1 - from) * Math.min(1.04, t)})`, ...style}}>
      {children}
    </div>
  );
};

/** Idle micro-motion for things that stay on screen. */
export const Breathe: React.FC<{amp?: number; period?: number; phase?: number; style?: React.CSSProperties; children?: React.ReactNode}> = ({amp = 5, period = 110, phase = 0, style, children}) => {
  const f = useCurrentFrame();
  return <div style={{transform: `translateY(${Math.sin((f / period) * Math.PI * 2 + phase) * amp}px)`, ...style}}>{children}</div>;
};

/** Word-by-word staggered text. Splits on spaces only (never inside Bengali conjuncts). */
export const Words: React.FC<{
  text: string; at?: number; until?: number; stagger?: number; size: number; weight?: number; color?: string;
  hi?: readonly string[]; hiColor?: string; strike?: readonly string[]; align?: 'left' | 'center' | 'right';
  lineHeight?: number; maxWidth?: number | string; gap?: number;
}> = ({text, at = 0, until, stagger = 4, size, weight = 700, color, hi, hiColor, strike, align = 'left', lineHeight = 1.18, maxWidth, gap}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const pal = usePal();
  const ex = until === undefined ? 0 : ramp(f, until, 10, eases.in);
  const words = text.split(' ').filter(Boolean);
  const core = (w: string) => w.replace(/[?।,.:;!]+$/g, '');
  return (
    <div style={{
      display: 'flex', flexWrap: 'wrap', maxWidth, opacity: 1 - ex, transform: `translateY(${-ex * 18}px)`,
      justifyContent: align === 'center' ? 'center' : align === 'right' ? 'flex-end' : 'flex-start',
      columnGap: gap ?? Math.round(size * 0.26), rowGap: Math.round(size * 0.06),
    }}>
      {words.map((w, i) => {
        const d = at + i * stagger;
        const t = f < d ? 0 : spring({frame: f - d, fps, config: springs.snappy});
        const isHi = hi?.includes(core(w));
        return (
          <span key={i} style={{
            display: 'inline-block', fontSize: size, fontWeight: weight, lineHeight,
            color: isHi ? hiColor ?? pal.accent : color ?? pal.fg,
            opacity: f < d ? 0 : clamp01(t * 1.6),
            transform: `translateY(${(1 - t) * size * 0.35}px) scale(${0.92 + 0.08 * Math.min(1.05, t)})`,
            textDecoration: strike?.includes(core(w)) ? 'line-through' : undefined,
            textDecorationThickness: Math.max(4, Math.round(size * 0.07)),
          }}>{w}</span>
        );
      })}
    </div>
  );
};

// ------------------------------------------------------------------ surfaces
export const Card: React.FC<{
  tone?: 'card' | 'accent'; pad?: number; shadow?: number; r?: number; style?: React.CSSProperties; children?: React.ReactNode;
}> = ({tone = 'card', pad = 32, shadow = 10, r = radius.card, style, children}) => {
  const pal = usePal();
  return (
    <div style={{
      background: tone === 'accent' ? pal.accent : pal.card, color: tone === 'accent' ? pal.accentFg : pal.cardFg,
      border: `3px solid ${pal.border}`, borderRadius: r, padding: pad, boxShadow: hardShadow(pal, shadow), boxSizing: 'border-box', ...style,
    }}>{children}</div>
  );
};

export const Chip: React.FC<{tone?: 'accent' | 'line' | 'card' | 'ink'; size?: number; style?: React.CSSProperties; children?: React.ReactNode}> = ({tone = 'accent', size = 30, style, children}) => {
  const pal = usePal();
  const bg = tone === 'accent' ? pal.accent : tone === 'card' ? pal.card : tone === 'ink' ? pal.fg : 'transparent';
  const fg = tone === 'accent' ? pal.accentFg : tone === 'card' ? pal.cardFg : tone === 'ink' ? pal.bg : pal.fg;
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 10, background: bg, color: fg, fontSize: size, fontWeight: 700, lineHeight: 1,
      padding: `${Math.round(size * 0.32)}px ${Math.round(size * 0.6)}px`, borderRadius: radius.pill,
      border: tone === 'line' ? `3px solid ${pal.fg}` : `3px solid ${tone === 'accent' ? pal.accent : bg}`, whiteSpace: 'nowrap', ...style,
    }}>{children}</span>
  );
};

// ------------------------------------------------------------------ icons (SVG, theme colours only)
export const CheckIcon: React.FC<{size?: number; color: string; p?: number; stroke?: number}> = ({size = 40, color, p = 1, stroke = 3.4}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round">
    <path d="M4.5 12.5l5 5L19.5 7" strokeDasharray={24} strokeDashoffset={24 * (1 - clamp01(p))} />
  </svg>
);
export const CrossIcon: React.FC<{size?: number; color: string; p?: number; stroke?: number}> = ({size = 40, color, p = 1, stroke = 3.4}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round">
    <path d="M6 6l12 12" strokeDasharray={18} strokeDashoffset={18 * (1 - clamp01(p * 2))} />
    <path d="M18 6L6 18" strokeDasharray={18} strokeDashoffset={18 * (1 - clamp01(p * 2 - 1))} />
  </svg>
);
const mat = (d: string) => ({size = 60, color}: {size?: number; color: string}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={color}><path d={d} /></svg>
);
export const LikeIcon = mat('M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z');
export const ShareIcon = mat('M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92s2.92-1.31 2.92-2.92-1.31-2.92-2.92-2.92z');
export const BellIcon = mat('M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z');
export const BubbleIcon = mat('M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z');
export const TargetIcon: React.FC<{size?: number; color: string; bg?: string}> = ({size = 90, color}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={1.8} strokeLinecap="round">
    <circle cx="12" cy="12" r="9" /><circle cx="12" cy="12" r="5" /><circle cx="12" cy="12" r="1.4" fill={color} />
  </svg>
);
export const SwapIcon: React.FC<{size?: number; color: string}> = ({size = 90, color}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={1.9} strokeLinecap="round" strokeLinejoin="round">
    <path d="M4 8h14l-3.5-3.5M20 16H6l3.5 3.5" />
  </svg>
);

/** Option card used in diagrams: letter badge + either grey lines or a label. */
export const OptionTile: React.FC<{
  letter: string; at: number; w: number; h: number; label?: string; labelSize?: number;
  state?: 'idle' | 'no' | 'ok'; stateAt?: number; dir?: Dir;
}> = ({letter, at, w, h, label, labelSize = 34, state = 'idle', stateAt = 0, dir = 'up'}) => {
  const f = useCurrentFrame();
  const pal = usePal();
  const p = state === 'idle' ? 0 : ramp(f, stateAt, 10);
  const okP = state === 'ok' ? p : 0;
  const badge = Math.round(Math.min(h * 0.46, 76));
  return (
    <Pop at={at} dir={dir} dist={50} cfg={springs.pop}>
      <div style={{
        position: 'relative', width: w, height: h, boxSizing: 'border-box', borderRadius: radius.card, overflow: 'hidden',
        background: pal.card, border: `3px solid ${pal.border}`, boxShadow: hardShadow(pal, 8),
        opacity: state === 'no' ? 1 - 0.4 * p : 1,
      }}>
        <div style={{position: 'absolute', inset: 0, background: pal.accent, opacity: okP}} />
        <div style={{position: 'relative', display: 'flex', alignItems: 'center', gap: 22, height: '100%', padding: '0 26px', color: okP > 0.5 ? pal.accentFg : pal.cardFg}}>
          <div style={{
            flex: 'none', width: badge, height: badge, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center',
            background: okP > 0.5 ? pal.accentFg : state === 'no' && p > 0.5 ? pal.accent : pal.cardFg,
            color: okP > 0.5 ? pal.accent : state === 'no' && p > 0.5 ? pal.accentFg : pal.card, fontSize: badge * 0.55, fontWeight: 700,
          }}>
            {state === 'no' && p > 0.5 ? <CrossIcon size={badge * 0.55} color={pal.accentFg} p={ramp(f, stateAt + 5, 8)} />
              : okP > 0.5 ? <CheckIcon size={badge * 0.6} color={pal.accent} p={ramp(f, stateAt + 5, 8)} /> : letter}
          </div>
          {label ? (
            <div style={{fontSize: labelSize, fontWeight: 700, lineHeight: 1.2}}>{label}</div>
          ) : (
            <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 14}}>
              <div style={{height: 16, borderRadius: 8, background: alpha(colors.dark, 0.18), width: '86%'}} />
              <div style={{height: 16, borderRadius: 8, background: alpha(colors.dark, 0.18), width: '52%'}} />
            </div>
          )}
        </div>
      </div>
    </Pop>
  );
};

/** Grey text-line placeholder block for passage illustrations. */
export const TextLines: React.FC<{widths: number[]; w: number; gap?: number; barH?: number; hl?: Record<number, number>; at?: number}> = ({widths, w, gap = 16, barH = 16, hl = {}, at = 0}) => {
  const pal = usePal();
  const f = useCurrentFrame();
  return (
    <div style={{display: 'flex', flexDirection: 'column', gap, width: w}}>
      {widths.map((pc, i) => {
        const p = ramp(f, at + i * 3, 12);
        return (
          <div key={i} style={{position: 'relative', height: barH, width: `${pc * p}%`, borderRadius: barH / 2, background: alpha(colors.dark, 0.18), overflow: 'hidden'}}>
            {hl[i] !== undefined && <div style={{position: 'absolute', inset: 0, width: `${hl[i] * 100}%`, background: pal.accent, borderRadius: barH / 2}} />}
          </div>
        );
      })}
    </div>
  );
};

// ------------------------------------------------------------------ audio
export type SfxName = 'whoosh' | 'swish' | 'pop' | 'click' | 'chime' | 'thud';
const SFX_LEN: Record<SfxName, number> = {whoosh: 0.62, swish: 0.32, pop: 0.18, click: 0.12, chime: 0.5, thud: 0.4};
const SFX_VOL: Record<SfxName, number> = {whoosh: 0.26, swish: 0.22, pop: 0.3, click: 0.26, chime: 0.28, thud: 0.3};

/** One sound at a scene-local frame. Slight deterministic pitch variation so repeats do not sound identical. */
export const Sfx: React.FC<{name: SfxName; at: number; vol?: number}> = ({name, at, vol}) => {
  const {fps} = useVideoConfig();
  if (!config.sfx) return null;
  const from = Math.max(0, Math.round(at));
  const rate = 1 + ((from * 7) % 5 - 2) * 0.012;
  return (
    <Sequence from={from} durationInFrames={Math.ceil((SFX_LEN[name] * fps) / rate) + 3} layout="none">
      <Audio src={staticFile(`sfx/${name}.wav`)} volume={vol ?? SFX_VOL[name]} playbackRate={rate} />
    </Sequence>
  );
};

/** public/voiceover.mp3 plays only if the file exists; switched by config.voiceover. */
export const PreviewAudio: React.FC = () => {
  const active = config.voiceover.enabled;
  const [handle] = useState(() => (active ? delayRender('voiceover-check') : null));
  const [ok, setOk] = useState(false);
  useEffect(() => {
    if (handle === null) return;
    let alive = true;
    fetch(staticFile('voiceover.mp3'), {method: 'HEAD'})
      .then((r) => {
        const ct = r.headers.get('content-type') || '';
        if (alive && r.ok && !ct.includes('text/html')) setOk(true);
      })
      .catch(() => undefined)
      .finally(() => continueRender(handle));
    return () => { alive = false; };
  }, [handle]);
  if (!active || !ok) return null;
  if (getRemotionEnvironment().isRendering && !config.voiceover.inRender) return null;
  return <Audio src={staticFile('voiceover.mp3')} volume={1} />;
};
