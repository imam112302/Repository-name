import {Easing} from 'remotion';
import {loadFont} from '@remotion/google-fonts/HindSiliguri';

// ---- Font (Bengali conjuncts render correctly; heaviest practical weight = 700) ----
export const font = loadFont('normal', {
  weights: ['400', '500', '600', '700'],
  subsets: ['bengali', 'latin', 'latin-ext'],
});
export const fontFamily = `${font.fontFamily}, "Hind Siliguri", "Noto Sans Bengali", sans-serif`;

// ---- Flat palette: black, cream, red + white. No gradients. ----
export const colors = {
  dark: '#15110D',
  cream: '#F5F1ED',
  red: '#E21A1E',
  white: '#FFFFFF',
  gray: '#B8B4A8',
} as const;

export const alpha = (hex: string, a: number) => {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${a})`;
};

// Per-background palettes. Background order never repeats the same colour twice in a row.
export type Pal = {
  bg: string;
  fg: string;       // text on background
  mute: string;     // small text on background
  card: string;
  cardFg: string;
  cardMute: string;
  accent: string;   // highlight on background / card
  accentFg: string; // text on accent
  shadow: string;
  border: string;
  line: string;
};

export const pals: Record<'dark' | 'cream' | 'red', Pal> = {
  dark: {
    bg: colors.dark, fg: colors.cream, mute: colors.gray,
    card: colors.cream, cardFg: colors.dark, cardMute: alpha(colors.dark, 0.6),
    accent: colors.red, accentFg: colors.white, shadow: colors.red, border: colors.cream,
    line: alpha(colors.cream, 0.16),
  },
  cream: {
    bg: colors.cream, fg: colors.dark, mute: alpha(colors.dark, 0.62),
    card: colors.white, cardFg: colors.dark, cardMute: alpha(colors.dark, 0.6),
    accent: colors.red, accentFg: colors.white, shadow: colors.dark, border: colors.dark,
    line: alpha(colors.dark, 0.14),
  },
  red: {
    bg: colors.red, fg: colors.white, mute: alpha(colors.white, 0.82),
    card: colors.cream, cardFg: colors.dark, cardMute: alpha(colors.dark, 0.6),
    accent: colors.dark, accentFg: colors.cream, shadow: colors.dark, border: colors.dark,
    line: alpha(colors.white, 0.28),
  },
};

// ---- Motion personality ----
export const springs = {
  snappy: {damping: 16, stiffness: 190, mass: 0.6},
  soft: {damping: 22, stiffness: 120, mass: 0.8},
  pop: {damping: 11, stiffness: 240, mass: 0.5},
  slow: {damping: 26, stiffness: 80, mass: 1},
};
export const eases = {
  out: Easing.bezier(0.16, 1, 0.3, 1),
  inOut: Easing.bezier(0.65, 0, 0.35, 1),
  in: Easing.bezier(0.5, 0, 0.75, 0),
};

// ---- Shape / type ----
export const radius = {card: 28, small: 18, pill: 999};
export const fs = {hero: 150, h1: 104, h2: 76, h3: 58, body: 46, small: 36, tiny: 28};
export const hardShadow = (pal: Pal, d = 10) => `${d}px ${d}px 0 ${pal.shadow}`;
