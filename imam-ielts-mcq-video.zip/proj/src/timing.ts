import {cues} from './data/cues';

// SRT is the only timing source: every frame number below is computed from public/subtitles.srt.
export const FPS = 30;
export const LEAD = 5; // visuals enter 4-6 frames before the related speech

export type Anchor = number | readonly [number, string];

const cue = (n: number) => {
  const c = cues[n - 1];
  if (!c || c.i !== n) throw new Error(`cue ${n} not found`);
  return c;
};

/** Seconds at which a cue (or a phrase inside a cue) is spoken. Phrase time = linear position inside the cue (SRT has cue-level timing only). */
export const startSec = (a: Anchor): number => {
  if (typeof a === 'number') return cue(a).start;
  const [n, sub] = a;
  const c = cue(n);
  // The SRT stores য়/ড়/ঢ় precomposed (U+09DF...), typed text uses base+nukta: compare in NFC.
  const text = c.text.normalize('NFC');
  const idx = text.indexOf(sub.normalize('NFC'));
  if (idx < 0) throw new Error(`Anchor not found in cue ${n}: "${sub}"`);
  return c.start + (idx / text.length) * (c.end - c.start);
};

/** Absolute frame for an anchor, shifted LEAD frames earlier than the speech. */
export const T = (a: Anchor) => Math.max(0, Math.round(startSec(a) * FPS) - LEAD);

export const TOTAL_FRAMES = Math.round(cues[cues.length - 1].end * FPS);

// ---- Scenes: boundaries follow cue boundaries ----
export const sceneList = [
  {id: 'hook', first: 1, bg: 'dark'},
  {id: 'pain', first: 3, bg: 'cream'},
  {id: 'why', first: 6, bg: 'red'},
  {id: 'overview', first: 8, bg: 'dark'},
  {id: 'whatis', first: 13, bg: 'cream'},
  {id: 'paraphrase', first: 17, bg: 'red'},
  {id: 'rules', first: 22, bg: 'dark'},
  {id: 'exam', first: 47, bg: 'cream'},
  {id: 'recap', first: 172, bg: 'dark'},
  {id: 'time', first: 177, bg: 'cream'},
  {id: 'tips', first: 182, bg: 'red'},
  {id: 'challenge', first: 189, bg: 'dark'},
  {id: 'practice', first: 192, bg: 'cream'},
  {id: 'outro', first: 197, bg: 'red'},
] as const;

export type SceneId = (typeof sceneList)[number]['id'];

export const sceneFrom = (id: SceneId) => {
  const i = sceneList.findIndex((s) => s.id === id);
  return i === 0 ? 0 : T(sceneList[i].first);
};
export const sceneEnd = (id: SceneId) => {
  const i = sceneList.findIndex((s) => s.id === id);
  return i === sceneList.length - 1 ? TOTAL_FRAMES : T(sceneList[i + 1].first);
};
export const sceneDur = (id: SceneId) => sceneEnd(id) - sceneFrom(id);

/** Scene-local frame of an anchor. */
export const mk = (id: SceneId) => {
  const base = sceneFrom(id);
  return (a: Anchor) => Math.max(0, T(a) - base);
};
