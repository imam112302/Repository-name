import React from 'react';
import {useCurrentFrame} from 'remotion';
import {Card, Chip, CheckIcon, CrossIcon, OptionTile, Pop, Sfx, TextLines, Words, ramp, usePal} from '../components/base';
import {Abs, Pane} from '../components/layout';
import {alpha, colors, springs} from '../theme';
import {mk, sceneDur} from '../timing';

const t = mk('rules');
const R = [t([22, 'প্রথম নিয়ম']), t([27, 'দ্বিতীয় নিয়ম']), t([32, 'তৃতীয় নিয়ম']), t([35, 'চতুর্থ নিয়ম']), t([38, 'পঞ্চম নিয়ম']), t([41, 'ষষ্ঠ নিয়ম'])];
const END = sceneDur('rules');
const TITLES = ['প্রশ্ন বুঝবে', 'Keywords চিহ্নিত করবে', 'অপশন আগে বুঝে নেবে', 'Scanning ব্যবহার করবে', 'Context বুঝবে', 'Elimination Technique'];
const bound = (i: number) => ({from: R[i], to: i < 5 ? R[i + 1] : END});

const Sidebar: React.FC = () => {
  const f = useCurrentFrame();
  const pal = usePal();
  let active = -1;
  R.forEach((s, i) => { if (f >= s) active = i; });
  return (
    <>
      <Abs x={70} y={50} w={600}><Words text="৬টি নিয়ম" size={70} at={0} /></Abs>
      <Abs x={70} y={150} w={580}>
        {TITLES.map((title, i) => {
          const on = active === i;
          const done = i < active;
          return (
            <Pop key={i} at={8 + i * 5} dir="left" dist={60}>
              <div style={{
                display: 'flex', alignItems: 'center', gap: 18, height: 112, marginBottom: 14, padding: '0 22px', boxSizing: 'border-box', borderRadius: 26,
                background: on ? pal.accent : 'transparent', color: on ? pal.accentFg : done ? pal.mute : pal.fg,
                border: `3px solid ${on ? pal.accent : pal.line}`, transform: `translateX(${on ? 14 : 0}px)`,
              }}>
                <div style={{flex: 'none', width: 62, height: 62, borderRadius: '50%', fontSize: 34, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', background: on ? pal.accentFg : done ? pal.accent : 'transparent', color: on ? pal.accent : pal.fg, border: `3px solid ${on ? pal.accentFg : done ? pal.accent : pal.line}`}}>
                  {done ? <CheckIcon size={34} color={pal.accentFg} /> : i + 1}
                </div>
                <div style={{fontSize: 36, fontWeight: 700, lineHeight: 1.15}}>{title}</div>
              </div>
            </Pop>
          );
        })}
      </Abs>
    </>
  );
};

const Line: React.FC<{y: number; at: number; text: string; size?: number; until?: number; hi?: string[]; strike?: string[]; weight?: number}> = ({y, at, text, size = 52, until, hi, strike, weight = 700}) => (
  <Abs x={0} y={y} w={1130}><Words text={text} size={size} at={at} until={until} hi={hi} strike={strike} weight={weight} maxWidth={1130} /></Abs>
);

const KwText: React.FC<{items: {text: string; at: number; kind: 'topic' | 'purpose'}[]}> = ({items}) => {
  const f = useCurrentFrame();
  const q = 'What point does the writer make about primary schools in India in the sixth paragraph?';
  const found = items.map((it) => ({it, idx: q.toLowerCase().indexOf(it.text.toLowerCase())})).sort((a, b) => a.idx - b.idx);
  const out: React.ReactNode[] = [];
  let cur = 0;
  found.forEach(({it, idx}, i) => {
    if (idx > cur) out.push(q.slice(cur, idx));
    const p = ramp(f, it.at, 16);
    const tint = it.kind === 'purpose' ? colors.red : colors.dark;
    out.push(<span key={i} style={{backgroundImage: `linear-gradient(${alpha(tint, 0.22)}, ${alpha(tint, 0.22)})`, backgroundRepeat: 'no-repeat', backgroundSize: `${p * 100}% 100%`, textDecorationLine: 'underline', textDecorationThickness: 5, textUnderlineOffset: 7, textDecorationColor: alpha(tint, p)}}>{q.slice(idx, idx + it.text.length)}</span>);
    cur = idx + it.text.length;
  });
  out.push(q.slice(cur));
  return <>{out}</>;
};

export const RulesScene: React.FC = () => {
  const f = useCurrentFrame();
  const pal = usePal();
  const b = [0, 1, 2, 3, 4, 5].map(bound);
  const kw = {w: t([28, 'Writer']), p: t([28, 'Primary schools']), i: t([28, 'India'])};
  const tileLabels = ['A', 'B', 'C', 'D'];
  const elim = [
    {at: t(43), text: 'Passage-এর তথ্যের বিপরীত', kind: 'no' as const},
    {at: t(44), text: 'Passage-এর বাইরে নতুন তথ্য', kind: 'no' as const},
    {at: t(45), text: 'সত্য তথ্য, কিন্তু প্রশ্নের উত্তর নয়', kind: 'no' as const},
    {at: t(46), text: 'প্রশ্নের সঙ্গে সবচেয়ে ভালো মিল', kind: 'ok' as const},
  ];
  const scan = ramp(f, t(36), t(37) - t(36), (x) => x);
  return (
    <>
      <Sfx name="whoosh" at={0} />
      {R.map((s, i) => <Sfx key={i} name="swish" at={s} />)}
      <Sidebar />
      <Abs x={700} y={100} w={1130} h={900}>
        {/* intro */}
        <Pane from={0} to={R[0]}>
          <Abs x={0} y={230} w={1130}><Words text="MCQ সমাধানের ছয়টি গুরুত্বপূর্ণ নিয়ম" size={96} at={4} until={R[0]} hi={['ছয়টি']} maxWidth={1130} /></Abs>
        </Pane>

        {/* Rule 1: understand the question */}
        <Pane {...b[0]}>
          <Pop at={t(23)} until={b[0].to}>
            <div style={{display: 'flex', alignItems: 'center', gap: 22}}>
              <Chip tone="accent" size={44}>১ · প্রশ্ন আগে</Chip><span style={{fontSize: 56, fontWeight: 700}}>→</span><Chip tone="line" size={44}>২ · তারপর Passage</Chip>
            </div>
          </Pop>
          <Abs x={0} y={130} w={1130}>
            <Pop at={t([24, 'যেমন'])} until={b[0].to}>
              <Card pad={30} style={{height: 210}}>
                <div style={{fontSize: 46, fontWeight: 700}}>What point does the writer make?</div>
                <div style={{marginTop: 20}}><Chip tone="accent" size={40}>→ লেখকের মূল বক্তব্য</Chip></div>
              </Card>
            </Pop>
          </Abs>
          <Abs x={0} y={380} w={1130}>
            <Pop at={t(25)} until={b[0].to}>
              <Card pad={30} style={{height: 210}}>
                <div style={{fontSize: 46, fontWeight: 700}}>What surprised the researchers?</div>
                <div style={{marginTop: 20}}><Chip tone="accent" size={40}>→ গবেষকদের কোন বিষয়টি অবাক করেছে</Chip></div>
              </Card>
            </Pop>
          </Abs>
          <Abs x={0} y={640}><Pop at={t([26, 'অর্থাৎ'])} until={b[0].to}><Chip tone="line" size={44}>প্রতিটি প্রশ্নের উদ্দেশ্য আলাদা</Chip></Pop></Abs>
          <Abs x={0} y={750} w={1130}>
            <Pop at={t([27, 'তাই প্রশ্ন'])} until={b[0].to} cfg={springs.pop}>
              <Card tone="accent" pad={30} style={{boxShadow: 'none', display: 'flex', alignItems: 'center', gap: 24}}>
                <CrossIcon size={64} color={pal.accentFg} p={ramp(f, t([27, 'তাই প্রশ্ন']) + 6, 10)} />
                <div style={{fontSize: 50, fontWeight: 700, lineHeight: 1.2}}>প্রশ্ন না বুঝে Passage পড়তে শুরু করবে না</div>
              </Card>
            </Pop>
          </Abs>
        </Pane>

        {/* Rule 2: keywords */}
        <Pane {...b[1]}>
          <Abs x={0} y={0} w={1130}>
            <Pop at={R[1]} until={b[1].to}>
              <Card pad={30} style={{height: 230}}>
                <div style={{fontSize: 46, fontWeight: 700, lineHeight: 1.3}}>
                  <KwText items={[{text: 'writer', at: kw.w, kind: 'purpose'}, {text: 'primary schools', at: kw.p, kind: 'topic'}, {text: 'India', at: kw.i, kind: 'topic'}]} />
                </div>
              </Card>
            </Pop>
          </Abs>
          <Abs x={0} y={270} w={1130}>
            <div style={{display: 'flex', gap: 18}}>
              <Pop at={kw.p} until={b[1].to}><Chip tone="card" size={42} style={{border: `3px solid ${pal.border}`}}>Primary schools</Chip></Pop>
              <Pop at={kw.i} until={b[1].to}><Chip tone="card" size={42} style={{border: `3px solid ${pal.border}`}}>India</Chip></Pop>
              <Pop at={kw.w} until={b[1].to}><Chip tone="accent" size={42}>Writer</Chip></Pop>
            </div>
          </Abs>
          <Abs x={0} y={390}><Pop at={t(29)} until={b[1].to}><Chip tone="line" size={42}>→ Passage-এর সঠিক জায়গা খুঁজে পাওয়া</Chip></Pop></Abs>
          <Line y={510} at={t([30, 'তবে মনে রাখবে'])} text="সব Keyword সমান গুরুত্বপূর্ণ নয়" size={58} until={b[1].to} hi={['নয়']} />
          <Abs x={0} y={620} w={540}>
            <Pop at={t([30, 'কিছু শব্দ'])} until={b[1].to}>
              <Card pad={26} style={{height: 250}}>
                <div style={{fontSize: 38, fontWeight: 700, color: pal.cardMute}}>প্রশ্নের বিষয়</div>
                <div style={{display: 'flex', flexDirection: 'column', gap: 14, marginTop: 20, alignItems: 'flex-start'}}>
                  <Chip tone="line" size={38} style={{borderColor: pal.cardFg, color: pal.cardFg}}>Primary schools</Chip>
                  <Chip tone="line" size={38} style={{borderColor: pal.cardFg, color: pal.cardFg}}>India</Chip>
                </div>
              </Card>
            </Pop>
          </Abs>
          <Abs x={590} y={620} w={540}>
            <Pop at={t(31)} until={b[1].to}>
              <Card pad={26} style={{height: 250}}>
                <div style={{fontSize: 38, fontWeight: 700, color: pal.cardMute}}>প্রশ্নের মূল উদ্দেশ্য</div>
                <div style={{marginTop: 20}}><Chip tone="accent" size={38}>Writer</Chip></div>
              </Card>
            </Pop>
          </Abs>
        </Pane>

        {/* Rule 3: understand options first */}
        <Pane {...b[2]}>
          <Line y={0} at={t([32, 'চারটি অপশনও'])} text="চারটি অপশনও একবার পড়ে নেবে" size={64} until={b[2].to} />
          <Abs x={0} y={110} w={1130}>
            <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 28}}>
              {tileLabels.map((L, i) => <OptionTile key={L} letter={L} at={t([32, 'চারটি অপশনও']) + 8 + i * 5} w={551} h={170} />)}
            </div>
          </Abs>
          <Abs x={0} y={520}><Pop at={t(33)} until={b[2].to}><Chip tone="line" size={40}>প্রতিটি অপশনে কী বলা হয়েছে, বোঝার চেষ্টা</Chip></Pop></Abs>
          <Abs x={0} y={610}><Pop at={t(34)} until={b[2].to}><Chip tone="line" size={40}>Passage-এ কোন ধরনের তথ্য খুঁজতে হবে, পরিষ্কার হবে</Chip></Pop></Abs>
          <Abs x={0} y={710} w={1130}>
            <Pop at={t([34, 'তবে এখনই'])} until={b[2].to} cfg={springs.pop}>
              <Card tone="accent" pad={26} style={{boxShadow: 'none', display: 'flex', alignItems: 'center', gap: 22}}>
                <CrossIcon size={56} color={pal.accentFg} p={ramp(f, t([34, 'তবে এখনই']) + 6, 10)} />
                <div style={{fontSize: 48, fontWeight: 700}}>এখনই কোনো অপশন নির্বাচন করবে না</div>
              </Card>
            </Pop>
          </Abs>
          <Abs x={0} y={830} w={1130}><Pop at={t([35, 'আগে Passage'])} until={b[2].to}><div style={{fontSize: 50, fontWeight: 700}}>আগে Passage থেকে <span style={{color: pal.accent}}>প্রমাণ</span> খুঁজবে</div></Pop></Abs>
        </Pane>

        {/* Rule 4: scanning */}
        <Pane {...b[3]}>
          <Abs x={0} y={0} w={1130}>
            <Pop at={R[3]} until={b[3].to}>
              <Card pad={34} style={{height: 430, position: 'relative', overflow: 'hidden'}}>
                <div style={{fontSize: 34, fontWeight: 700, color: pal.cardMute, marginBottom: 20}}>Passage</div>
                <TextLines widths={[98, 92, 96, 88, 94, 70, 96, 90, 60]} w={1020} gap={20} barH={18} at={R[3]} hl={{3: ramp(f, t([37, 'প্রশ্নের সঙ্গে']), 14), 4: ramp(f, t([37, 'প্রশ্নের সঙ্গে']) + 4, 14)}} />
                <div style={{position: 'absolute', left: 20, right: 20, top: 84 + scan * 240, height: 44, borderRadius: 22, border: `4px solid ${pal.accent}`, background: alpha(colors.red, 0.1), opacity: scan > 0 && scan < 1 ? 1 : 0.0}} />
              </Card>
            </Pop>
          </Abs>
          <Abs x={0} y={470}><Pop at={t([36, 'Keywords অথবা'])} until={b[3].to}><Chip tone="accent" size={44}>Keywords / Synonyms খুঁজবে</Chip></Pop></Abs>
          <Line y={560} at={t(37)} text="পুরো Passage বারবার পড়ার প্রয়োজন নেই" size={52} strike={['বারবার']} until={b[3].to} />
          <Line y={650} at={t([37, 'প্রশ্নের সঙ্গে'])} text="সম্পর্কিত অংশটি খুঁজে বের করবে" size={52} until={b[3].to} hi={['সম্পর্কিত']} />
          <Abs x={0} y={770}>
            <Pop at={t(38)} until={b[3].to}>
              <div style={{display: 'flex', alignItems: 'center', gap: 20}}>
                <Chip tone="line" size={46}><CrossIcon size={38} color={pal.fg} />Keyword নেই</Chip>
                <span style={{fontSize: 52, fontWeight: 700}}>→</span>
                <Chip tone="accent" size={46}><CheckIcon size={38} color={pal.accentFg} />Synonym খুঁজবে</Chip>
              </div>
            </Pop>
          </Abs>
        </Pane>

        {/* Rule 5: context */}
        <Pane {...b[4]}>
          {[
            {y: 0, label: 'আগের বাক্য', at: R[4], hl: ramp(f, t(40), 14) * 0.45},
            {y: 150, label: 'এই বাক্য', at: R[4] + 6, hl: 1},
            {y: 300, label: 'পরের বাক্য', at: R[4] + 12, hl: ramp(f, t(40) + 6, 14) * 0.45},
          ].map((r, i) => (
            <Abs key={i} x={0} y={r.y} w={1130}>
              <Pop at={r.at} until={b[4].to} dir="left">
                <Card pad={24} style={{height: 126, display: 'flex', alignItems: 'center', gap: 24, boxShadow: 'none', border: i === 1 ? `5px solid ${colors.red}` : `3px solid ${pal.border}`}}>
                  <div style={{flex: 'none', width: 230, fontSize: 38, fontWeight: 700}}>{r.label}</div>
                  <TextLines widths={[100, 72]} w={800} gap={18} barH={20} at={r.at + 4} hl={{0: r.hl, 1: r.hl}} />
                </Card>
              </Pop>
            </Abs>
          ))}
          <Abs x={0} y={470}><Pop at={t([39, 'শুধু একটি'])} until={b[4].to}><Chip tone="line" size={42}><CrossIcon size={36} color={pal.fg} />শুধু একটি বাক্য পড়ে উত্তর নয়</Chip></Pop></Abs>
          <Line y={565} at={t(40)} text="আগের এবং পরের বাক্যও পড়বে" size={56} until={b[4].to} hi={['আগের', 'পরের']} />
          <Line y={660} at={t([40, 'কারণ অনেক'])} text="একটি বাক্য আলাদাভাবে পড়লে ভুল অর্থ হতে পারে" size={42} weight={500} until={b[4].to} />
          <Abs x={0} y={770} w={1130}>
            <Pop at={t(41)} until={b[4].to} cfg={springs.pop}>
              <Card tone="accent" pad={26} style={{boxShadow: 'none', display: 'flex', alignItems: 'center', gap: 22}}>
                <CheckIcon size={58} color={pal.accentFg} p={ramp(f, t(41) + 8, 10)} />
                <div style={{fontSize: 46, fontWeight: 700}}>পুরো Context বুঝলে সঠিক উত্তর পাওয়া যায়</div>
              </Card>
            </Pop>
          </Abs>
        </Pane>

        {/* Rule 6: elimination */}
        <Pane {...b[5]}>
          <Line y={0} at={t([42, 'চারটি অপশনের'])} text="ভুল অপশন একে একে বাদ দেবে" size={62} until={b[5].to} hi={['বাদ']} />
          <Abs x={0} y={110} w={1130}>
            <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '22px 28px'}}>
              {elim.map((e, i) => (
                <div key={i}>
                  <OptionTile letter={tileLabels[i]} at={R[5] + 6 + i * 5} w={551} h={160} state={e.kind} stateAt={e.at} />
                  <Pop at={e.at} dist={20}><div style={{fontSize: 36, fontWeight: 700, lineHeight: 1.2, marginTop: 14, height: 88, color: e.kind === 'ok' ? pal.accent : pal.fg}}>{e.kind === 'ok' ? '✓ ' : '✕ '}{e.text}</div></Pop>
                </div>
              ))}
            </div>
          </Abs>
          <Abs x={0} y={770}><Pop at={t(42)}><Chip tone="accent" size={44}>সবচেয়ে গুরুত্বপূর্ণ কৌশলগুলোর একটি</Chip></Pop></Abs>
        </Pane>
      </Abs>
      {elim.map((e, i) => <Sfx key={i} name={e.kind === 'ok' ? 'chime' : 'click'} at={e.at} />)}
      <Sfx name="pop" at={R[2] + 8} /><Sfx name="pop" at={R[5] + 6} /><Sfx name="click" at={t([34, 'তবে এখনই'])} />
    </>
  );
};
