import React, {useLayoutEffect, useRef, useState} from 'react';
import {continueRender, delayRender, interpolate, useCurrentFrame} from 'remotion';
import {Breathe, Chip, CheckIcon, CrossIcon, Pop, Sfx, clamp01, ramp, usePal} from '../components/base';
import {alpha, colors, eases, hardShadow, radius, springs} from '../theme';
import {mk} from '../timing';
import {instruction, paraLabels, paragraphs, passageTitle, source} from '../data/passage';
import {
  answerBeat, answerRows, answersStart, marks, overviewBeats, overviewBullets, overviewMeaning, questions,
  type Beat, type QData, type Tone,
} from '../data/exam';

const t = mk('exam');

// ---------------------------------------------------------------- layout (1920 x 1080)
const M = 32;
const MAIN_Y = 100;
const MAIN_H = 790;
const PASS_W = 960;
const GAP = 24;
const Q_X = M + PASS_W + GAP;
const Q_W = 1920 - M - Q_X;
const BAR_Y = 906;
const BAR_H = 150;
const PASS_HEAD = 66;
const VIEW_H = MAIN_H - PASS_HEAD - 6;

// ---------------------------------------------------------------- precomputed timeline (all from SRT anchors)
const QF = questions.map((q) => ({
  q,
  start: t(q.start),
  verdicts: q.verdicts.map((v) => ({...v, f: t(v.a)})),
  focus: q.focus.map((e) => ({...e, f: t(e.a)})),
  qmarks: q.qmarks.map((m) => ({...m, f: t(m.a)})),
}));
const ANS_START = t(answersStart);
const qEnd = (i: number) => (i + 1 < QF.length ? QF[i + 1].start : ANS_START);

type Mode = {kind: 'overview' | 'q' | 'answers'; start: number; qi: number};
const MODES: Mode[] = [
  {kind: 'overview', start: 0, qi: -1},
  ...QF.map((x, i): Mode => ({kind: 'q', start: x.start, qi: i})),
  {kind: 'answers', start: ANS_START, qi: -1},
];

const ALL_BEATS = [...overviewBeats, ...questions.flatMap((q) => q.beats), answerBeat]
  .map((b) => ({...b, f: t(b.a)}))
  .sort((a, b) => a.f - b.f);

const SCROLL_KEYS = questions
  .flatMap((q) => q.scroll)
  .map((s) => ({f: t(s.a), to: s.to}))
  .sort((a, b) => a.f - b.f);

// passage segments (marks are static spans so layout never changes)
type Seg = {text: string; mark?: (typeof marks)[number]};
const SEGS: Seg[][] = paragraphs.map((p, pi) => {
  const ms = marks.filter((m) => m.para === pi).map((m) => ({m, idx: p.indexOf(m.text)})).sort((a, b) => a.idx - b.idx);
  const out: Seg[] = [];
  let cur = 0;
  for (const {m, idx} of ms) {
    if (idx > cur) out.push({text: p.slice(cur, idx)});
    out.push({text: m.text, mark: m});
    cur = idx + m.text.length;
  }
  if (cur < p.length) out.push({text: p.slice(cur)});
  return out;
});
const MARK_F = Object.fromEntries(marks.map((m) => [m.id, {f: t(m.a), pulses: (m.pulse ?? []).map((p) => t(p))}]));

const modeIndexAt = (f: number) => {
  let k = 0;
  for (let i = 0; i < MODES.length; i++) if (MODES[i].start <= f) k = i;
  return k;
};

// ---------------------------------------------------------------- passage panel
const PassagePanel: React.FC<{offs: Record<string, number> | null; maxScroll: number; refs: {col: React.RefObject<HTMLDivElement>; paras: React.MutableRefObject<(HTMLDivElement | null)[]>; marks: React.MutableRefObject<Record<string, HTMLSpanElement | null>>}}> = ({offs, maxScroll, refs}) => {
  const f = useCurrentFrame();
  const pal = usePal();

  const targetY = (id: string) => {
    if (!offs || id === 'top') return 0;
    const raw = id.startsWith('p') && /^p\d$/.test(id) ? offs[id] - 70 : offs[id] - VIEW_H * 0.3;
    return Math.max(0, Math.min(maxScroll, raw));
  };
  let y = 0;
  let idx = -1;
  for (let i = 0; i < SCROLL_KEYS.length; i++) if (SCROLL_KEYS[i].f <= f) idx = i;
  if (idx >= 0) {
    const prev = idx > 0 ? targetY(SCROLL_KEYS[idx - 1].to) : 0;
    y = prev + (targetY(SCROLL_KEYS[idx].to) - prev) * ramp(f, SCROLL_KEYS[idx].f, 28, eases.inOut);
  }

  // which question window are we in
  const mi = modeIndexAt(f);
  const qi = MODES[mi].kind === 'q' ? MODES[mi].qi : MODES[mi].kind === 'answers' ? questions.length : -1;

  const markStyle = (m: (typeof marks)[number]): React.CSSProperties => {
    const info = MARK_F[m.id];
    const qs = QF[m.q - 1].start;
    const qe = qEnd(m.q - 1);
    if (f < qs) return {};
    const gate = f < qe ? 1 : 1 - ramp(f, qe, 10);
    const p = ramp(f, info.f, 18) * gate;
    if (p <= 0) return {};
    let bump = 0;
    for (const pf of info.pulses) bump = Math.max(bump, interpolate(f, [pf, pf + 6, pf + 24], [0, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}));
    const tint = m.kind === 'ev' ? colors.red : colors.dark;
    const base = m.kind === 'ev' ? 0.2 : 0.1;
    const a = base + (m.kind === 'ev' ? 0.3 : 0.12) * bump;
    return {
      backgroundImage: `linear-gradient(${alpha(tint, a)}, ${alpha(tint, a)})`,
      backgroundRepeat: 'no-repeat', backgroundSize: `${p * 100}% 100%`, backgroundPosition: 'left center',
      textDecorationLine: 'underline', textDecorationThickness: 4, textUnderlineOffset: 7,
      textDecorationStyle: m.kind === 'ev' ? 'solid' : 'dashed',
      textDecorationColor: alpha(tint, (m.kind === 'ev' ? 1 : 0.55) * p),
    };
  };
  void qi;

  return (
    <div style={{
      position: 'absolute', left: M, top: MAIN_Y, width: PASS_W, height: MAIN_H, boxSizing: 'border-box', background: pal.card,
      border: `3px solid ${pal.border}`, borderRadius: radius.card, boxShadow: hardShadow(pal, 10), overflow: 'hidden',
    }}>
      <div style={{height: PASS_HEAD, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 30px', borderBottom: `3px solid ${pal.border}`, background: colors.cream}}>
        <Chip tone="ink" size={24}>READING PASSAGE</Chip>
        <span style={{fontSize: 24, fontWeight: 600, color: pal.cardMute}}>Part 1 · Questions 1–3</span>
      </div>
      <div style={{position: 'relative', height: VIEW_H, overflow: 'hidden'}}>
        <div ref={refs.col} style={{position: 'absolute', left: 0, right: 0, top: 0, padding: '28px 38px 140px', transform: `translateY(${-y}px)`}}>
          <div style={{fontSize: 38, fontWeight: 700, lineHeight: 1.25, marginBottom: 28, color: pal.cardFg}}>{passageTitle}</div>
          {paragraphs.map((_, pi) => (
            <div key={pi} ref={(el) => { refs.paras.current[pi] = el; }} style={{marginBottom: 36}}>
              <div style={{fontSize: 22, fontWeight: 700, color: pal.accent, marginBottom: 8}}>{paraLabels[pi]}</div>
              <p style={{margin: 0, fontSize: 32, lineHeight: 1.5, fontWeight: 400, color: pal.cardFg}}>
                {SEGS[pi].map((s, si) => s.mark ? (
                  <span key={si} ref={(el) => { refs.marks.current[s.mark!.id] = el; }} style={markStyle(s.mark)}>{s.text}</span>
                ) : (<React.Fragment key={si}>{s.text}</React.Fragment>))}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// ---------------------------------------------------------------- right panel: question
const segmentize = (text: string, items: {text: string}[]) => {
  const found = items.map((it) => ({it, idx: text.toLowerCase().indexOf(it.text.toLowerCase())})).filter((x) => x.idx >= 0).sort((a, b) => a.idx - b.idx);
  const out: {text: string; item?: {text: string}}[] = [];
  let cur = 0;
  for (const {it, idx} of found) {
    if (idx < cur) continue;
    if (idx > cur) out.push({text: text.slice(cur, idx)});
    out.push({text: text.slice(idx, idx + it.text.length), item: it});
    cur = idx + it.text.length;
  }
  if (cur < text.length) out.push({text: text.slice(cur)});
  return out;
};

const QuestionView: React.FC<{qi: number}> = ({qi}) => {
  const f = useCurrentFrame();
  const pal = usePal();
  const {q, start, verdicts, focus, qmarks} = QF[qi];
  let focused = -1;
  for (const e of focus) if (e.f <= f) focused = e.opt;
  const segs = segmentize(q.question, qmarks);
  const qmByText = Object.fromEntries(qmarks.map((m) => [m.text, m]));
  return (
    <div style={{padding: '24px 28px', height: '100%', boxSizing: 'border-box', display: 'flex', flexDirection: 'column'}}>
      <div style={{display: 'flex', alignItems: 'center', gap: 18, marginBottom: 14}}>
        <div style={{width: 56, height: 56, borderRadius: '50%', background: pal.accent, color: pal.accentFg, fontSize: 32, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>{q.n}</div>
        <div style={{fontSize: 26, fontWeight: 600, color: pal.cardMute}}>{instruction}</div>
      </div>
      <div style={{fontSize: 38, fontWeight: 700, lineHeight: 1.3, marginBottom: 20}}>
        {segs.map((s, i) => {
          if (!s.item) return <React.Fragment key={i}>{s.text}</React.Fragment>;
          const m = qmByText[s.item.text];
          const p = ramp(f, m.f, 16);
          const isPurpose = m.kind === 'purpose';
          const tint = isPurpose ? colors.red : colors.dark;
          return (
            <span key={i} style={{
              backgroundImage: `linear-gradient(${alpha(tint, isPurpose ? 0.24 : 0.12)}, ${alpha(tint, isPurpose ? 0.24 : 0.12)})`,
              backgroundRepeat: 'no-repeat', backgroundSize: `${p * 100}% 100%`, backgroundPosition: 'left center',
              textDecorationLine: 'underline', textDecorationThickness: 5, textUnderlineOffset: 7, textDecorationColor: alpha(tint, p),
            }}>{s.text}</span>
          );
        })}
      </div>
      <div style={{display: 'flex', flexDirection: 'column', gap: 12}}>
        {q.options.map((opt, i) => {
          let kind: 'idle' | 'ok' | 'no' | 'trap' = 'idle';
          let at = 0;
          for (const v of verdicts) if (v.opt === i && v.f <= f) { kind = v.kind; at = v.f; }
          const p = kind === 'idle' ? 0 : ramp(f, at, 12);
          const isFocus = focused === i;
          const ok = kind === 'ok';
          const no = kind === 'no' || kind === 'trap';
          const lift = isFocus ? 10 : 0;
          return (
            <Pop key={i} at={start + 12 + i * 5} dir="right" dist={50} cfg={springs.snappy}>
              <div style={{
                display: 'flex', alignItems: 'center', gap: 18, padding: '12px 20px', borderRadius: 20, boxSizing: 'border-box',
                background: ok ? alpha(colors.red, p) : no ? alpha(colors.red, 0.08 * p) : isFocus ? colors.white : colors.cream,
                border: `${isFocus && !ok ? 4 : 3}px solid ${ok ? colors.red : isFocus ? colors.red : no ? alpha(colors.red, 0.35) : alpha(colors.dark, 0.18)}`,
                boxShadow: isFocus && !ok ? `0 0 0 6px ${alpha(colors.red, 0.16)}` : 'none',
                transform: `translateX(${lift}px)`,
                color: ok && p > 0.4 ? colors.white : no ? alpha(colors.dark, 0.58) : colors.dark,
              }}>
                <div style={{
                  flex: 'none', width: 58, height: 58, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 30, fontWeight: 700,
                  background: ok && p > 0.4 ? colors.white : no && p > 0.4 ? colors.red : isFocus ? colors.red : colors.dark,
                  color: ok && p > 0.4 ? colors.red : colors.cream,
                }}>
                  {ok && p > 0.4 ? <CheckIcon size={34} color={colors.red} p={ramp(f, at + 4, 8)} />
                    : no && p > 0.4 ? <CrossIcon size={30} color={colors.white} p={ramp(f, at + 4, 8)} /> : 'ABCD'[i]}
                </div>
                <div style={{fontSize: 32, fontWeight: ok && p > 0.4 ? 700 : 500, lineHeight: 1.28}}>{opt}</div>
              </div>
            </Pop>
          );
        })}
      </div>
    </div>
  );
};

// ---------------------------------------------------------------- right panel: overview + answers
const OverviewView: React.FC = () => {
  const pal = usePal();
  return (
    <div style={{padding: '30px 34px', height: '100%', boxSizing: 'border-box'}}>
      <Pop at={t(47)}><Chip tone="accent" size={28}>Passage-এর মূল বিষয়</Chip></Pop>
      <Pop at={t(overviewMeaning.a)} style={{marginTop: 26}}>
        <div style={{fontSize: 40, fontWeight: 700, lineHeight: 1.3, padding: '22px 26px', borderRadius: 22, background: alpha(colors.red, 0.1), borderLeft: `8px solid ${pal.accent}`}}>{overviewMeaning.text}</div>
      </Pop>
      <div style={{display: 'flex', flexDirection: 'column', gap: 18, marginTop: 34}}>
        {overviewBullets.map((b, i) => (
          <Pop key={i} at={t(b.a)} dir="right">
            <div style={{display: 'flex', alignItems: 'flex-start', gap: 18}}>
              <div style={{flex: 'none', width: 46, height: 46, borderRadius: '50%', background: pal.cardFg, color: pal.card, fontSize: 26, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', marginTop: 4}}>{i + 1}</div>
              <div style={{fontSize: 36, fontWeight: 500, lineHeight: 1.35}}>{b.text}</div>
            </div>
          </Pop>
        ))}
      </div>
    </div>
  );
};

const AnswersView: React.FC = () => {
  const pal = usePal();
  return (
    <div style={{padding: '30px 34px', height: '100%', boxSizing: 'border-box'}}>
      <Pop at={ANS_START}><Chip tone="accent" size={28}>তিনটি প্রশ্নের উত্তর</Chip></Pop>
      <div style={{display: 'flex', flexDirection: 'column', gap: 22, marginTop: 30}}>
        {answerRows.map((r, i) => (
          <Pop key={i} at={t(r.a)} dir="right" dist={60} cfg={springs.pop}>
            <div style={{display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '24px 34px', borderRadius: 26, background: colors.cream, border: `3px solid ${pal.border}`, boxShadow: hardShadow(pal, 8)}}>
              <div style={{fontSize: 50, fontWeight: 700}}>{r.q}</div>
              <div style={{width: 112, height: 112, borderRadius: '50%', background: pal.accent, color: pal.accentFg, fontSize: 68, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>{r.letter}</div>
            </div>
          </Pop>
        ))}
      </div>
    </div>
  );
};

const renderMode = (m: Mode) => (m.kind === 'overview' ? <OverviewView /> : m.kind === 'answers' ? <AnswersView /> : <QuestionView qi={m.qi} />);

const RightPanel: React.FC = () => {
  const f = useCurrentFrame();
  const pal = usePal();
  const mi = modeIndexAt(f);
  const cur = MODES[mi];
  const prev = mi > 0 ? MODES[mi - 1] : null;
  const since = f - cur.start;
  const slot = (key: string, enter: number, exit: number, child: React.ReactNode) => (
    <div key={key} style={{position: 'absolute', inset: 0, opacity: enter * (1 - exit), transform: `translateX(${(1 - enter) * 70 - exit * 70}px)`}}>{child}</div>
  );
  return (
    <div style={{
      position: 'absolute', left: Q_X, top: MAIN_Y, width: Q_W, height: MAIN_H, boxSizing: 'border-box', background: pal.card,
      border: `3px solid ${pal.border}`, borderRadius: radius.card, boxShadow: hardShadow(pal, 10), overflow: 'hidden',
    }}>
      {prev && since < 14 && slot('prev' + mi, 1, ramp(f, cur.start, 12, eases.in), renderMode(prev))}
      {slot('cur' + mi, ramp(f, cur.start, 18), 0, renderMode(cur))}
    </div>
  );
};

// ---------------------------------------------------------------- insight bar (analysis stays on the same screen)
const toneStyle = (tone: Tone | undefined) => {
  switch (tone) {
    case 'good': return {chipBg: colors.cream, chipFg: colors.dark, border: colors.cream};
    case 'bad': return {chipBg: colors.red, chipFg: colors.white, border: alpha(colors.cream, 0.25)};
    case 'trap': return {chipBg: colors.red, chipFg: colors.white, border: colors.red};
    case 'lesson': return {chipBg: colors.cream, chipFg: colors.red, border: alpha(colors.cream, 0.25)};
    default: return {chipBg: alpha(colors.cream, 0.16), chipFg: colors.cream, border: alpha(colors.cream, 0.25)};
  }
};

const BeatView: React.FC<{beat: Beat & {f: number}; enter: number; exit: number}> = ({beat, enter, exit}) => {
  const ts = toneStyle(beat.tone);
  const long = beat.text.length > 88;
  return (
    <div style={{
      position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', gap: 28, padding: '0 36px', boxSizing: 'border-box',
      opacity: enter * (1 - exit), transform: `translateY(${(1 - enter) * 26 - exit * 20}px)`,
    }}>
      <div style={{flex: 'none', maxWidth: 380, fontSize: 30, fontWeight: 700, lineHeight: 1.15, padding: '14px 24px', borderRadius: radius.pill, background: ts.chipBg, color: ts.chipFg, display: 'flex', alignItems: 'center', gap: 10}}>
        {beat.tone === 'good' && <CheckIcon size={30} color={ts.chipFg} p={enter} />}
        {beat.tag}
      </div>
      <div style={{flex: 1, fontSize: long ? 36 : 42, fontWeight: 600, lineHeight: 1.28, color: colors.cream, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden'}}>{beat.text}</div>
    </div>
  );
};

const InsightBar: React.FC = () => {
  const f = useCurrentFrame();
  let k = 0;
  for (let i = 0; i < ALL_BEATS.length; i++) if (ALL_BEATS[i].f <= f) k = i;
  const cur = ALL_BEATS[k];
  const prev = k > 0 ? ALL_BEATS[k - 1] : null;
  const since = f - cur.f;
  const ts = toneStyle(cur.tone);
  return (
    <div style={{
      position: 'absolute', left: M, top: BAR_Y, width: 1920 - 2 * M, height: BAR_H, boxSizing: 'border-box', background: colors.dark,
      border: `3px solid ${ts.border}`, borderRadius: radius.card, overflow: 'hidden',
    }}>
      {prev && since < 7 && <BeatView key={'p' + k} beat={prev} enter={1} exit={ramp(f, cur.f, 6, eases.in)} />}
      <BeatView key={'c' + k} beat={cur} enter={ramp(f, cur.f + 5, 14)} exit={0} />
    </div>
  );
};

// ---------------------------------------------------------------- top bar
const TopBar: React.FC = () => {
  const f = useCurrentFrame();
  const pal = usePal();
  return (
    <div style={{position: 'absolute', left: M, right: M, top: 20, height: 64, display: 'flex', alignItems: 'center', justifyContent: 'space-between'}}>
      <div style={{display: 'flex', alignItems: 'center', gap: 14}}>
        <div style={{width: 18, height: 18, background: pal.accent, borderRadius: 4}} />
        <div style={{fontSize: 34, fontWeight: 700, color: pal.fg}}>Imam IELTS</div>
      </div>
      <div style={{fontSize: 30, fontWeight: 600, color: pal.mute}}>{source}</div>
      <div style={{display: 'flex', gap: 14}}>
        {QF.map((x, i) => {
          const end = qEnd(i);
          const done = x.verdicts.find((v) => v.kind === 'ok' && v.f <= f);
          const current = f >= x.start && f < end;
          return (
            <div key={i} style={{
              width: 64, height: 64, borderRadius: '50%', boxSizing: 'border-box', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 32, fontWeight: 700,
              background: done ? pal.accent : current ? pal.fg : 'transparent', color: done ? pal.accentFg : current ? pal.bg : pal.fg,
              border: `3px solid ${done ? pal.accent : pal.fg}`,
            }}>{done ? 'ABCD'[x.q.answer] : x.q.n}</div>
          );
        })}
      </div>
    </div>
  );
};

// ---------------------------------------------------------------- scene
export const ExamScene: React.FC = () => {
  const f = useCurrentFrame();
  const col = useRef<HTMLDivElement>(null);
  const paras = useRef<(HTMLDivElement | null)[]>([]);
  const markRefs = useRef<Record<string, HTMLSpanElement | null>>({});
  const [offs, setOffs] = useState<Record<string, number> | null>(null);
  const [maxScroll, setMaxScroll] = useState(0);
  const [handle] = useState(() => delayRender('measure passage layout'));

  useLayoutEffect(() => {
    const o: Record<string, number> = {};
    paras.current.forEach((el, i) => { if (el) o['p' + i] = el.offsetTop; });
    Object.entries(markRefs.current).forEach(([id, el]) => { if (el) o[id] = el.offsetTop; });
    setOffs(o);
    if (col.current) setMaxScroll(Math.max(0, col.current.scrollHeight - VIEW_H));
    continueRender(handle);
  }, [handle]);

  const lift = (at: number, dir: 'left' | 'right' | 'down', node: React.ReactNode) => <Pop at={at} dir={dir} dist={70} cfg={springs.soft}>{node}</Pop>;
  void lift; void clamp01; void Breathe;

  return (
    <>
      <Pop at={0} dir="down" dist={30}><TopBar /></Pop>
      <Pop at={4} dir="left" dist={90} cfg={springs.soft}><PassagePanel offs={offs} maxScroll={maxScroll} refs={{col, paras, marks: markRefs}} /></Pop>
      <Pop at={8} dir="right" dist={90} cfg={springs.soft}><RightPanel /></Pop>
      <Pop at={12} dir="up" dist={60} cfg={springs.soft}><InsightBar /></Pop>

      <Sfx name="whoosh" at={0} />
      <Sfx name="pop" at={12} />
      {QF.map((x, i) => (
        <React.Fragment key={i}>
          <Sfx name="swish" at={x.start} />
          <Sfx name="pop" at={x.start + 12} />
          {x.verdicts.map((v, j) => <Sfx key={j} name={v.kind === 'ok' ? 'chime' : 'click'} at={v.f} />)}
        </React.Fragment>
      ))}
      <Sfx name="swish" at={ANS_START} />
      {answerRows.map((r, i) => <Sfx key={i} name="pop" at={t(r.a)} />)}
      <div style={{display: 'none'}}>{f}</div>
    </>
  );
};
