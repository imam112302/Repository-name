import React from 'react';
import {useCurrentFrame} from 'remotion';
import {BellIcon, BubbleIcon, Breathe, Card, Chip, CheckIcon, CrossIcon, LikeIcon, Pop, ShareIcon, Sfx, Words, ramp, usePal} from '../components/base';
import {Abs, Pane} from '../components/layout';
import {alpha, colors, springs} from '../theme';
import {mk, sceneDur} from '../timing';

// =============================================================== Recap (172-176)
export const RecapScene: React.FC = () => {
  const t = mk('recap');
  const f = useCurrentFrame();
  const pal = usePal();
  const items = [
    {a: t([173, 'প্রথম ধাপ']), text: 'প্রশ্ন বোঝা'},
    {a: t([173, 'দ্বিতীয় ধাপ']), text: 'Keywords চিহ্নিত করা'},
    {a: t([174, 'তৃতীয় ধাপ']), text: 'চারটি অপশন বুঝে নেওয়া'},
    {a: t([175, 'চতুর্থ ধাপ']), text: 'Scanning ব্যবহার করে Passage-এর Relevant অংশ খুঁজে বের করা'},
    {a: t([176, 'পঞ্চম ধাপ']), text: 'Context এবং Paraphrasing বোঝা'},
    {a: t([176, 'ষষ্ঠ ধাপ']), text: 'ভুল অপশন বাদ দিয়ে সঠিক উত্তর নির্বাচন করা'},
  ];
  return (
    <>
      <Sfx name="whoosh" at={0} />
      <Abs x={110} y={70} w={1700}><Words text="ছয়টি ধাপ, সংক্ষেপে আবার" size={96} at={0} hi={['ছয়টি']} /></Abs>
      <Abs x={110} y={290} w={1700}>
        <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '36px 36px'}}>
          {items.map((it, i) => (
            <Pop key={i} at={it.a} dist={60} cfg={springs.pop}>
              <Card pad={30} style={{height: 330, display: 'flex', flexDirection: 'column', justifyContent: 'space-between'}}>
                <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
                  <div style={{width: 76, height: 76, borderRadius: '50%', background: pal.cardFg, color: pal.card, fontSize: 44, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>{i + 1}</div>
                  <div style={{width: 76, height: 76, borderRadius: '50%', background: pal.accent, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                    <CheckIcon size={48} color={pal.accentFg} p={ramp(f, it.a + 10, 10)} />
                  </div>
                </div>
                <div style={{fontSize: i === 3 ? 40 : 46, fontWeight: 700, lineHeight: 1.22}}>{it.text}</div>
              </Card>
            </Pop>
          ))}
        </div>
      </Abs>
      {items.map((it, i) => <Sfx key={i} name="click" at={it.a + 10} />)}
    </>
  );
};

// =============================================================== Time management (177-181)
export const TimeScene: React.FC = () => {
  const t = mk('time');
  const f = useCurrentFrame();
  const pal = usePal();
  const steps = [
    {a: t(178), text: 'একটি প্রশ্নের পেছনে অতিরিক্ত সময় ব্যয় করবে না'},
    {a: t([178, 'প্রথমে সহজে']), text: 'প্রথমে সহজ প্রশ্নগুলোর উত্তর দেবে'},
    {a: t(179), text: 'আটকে গেলে পরের প্রশ্নে যাও, সময় থাকলে ফিরে এসো'},
    {a: t(180), text: 'পুরো Passage বারবার নয়, সম্পর্কিত অংশটুকু পড়বে'},
  ];
  const hand = (f / 30) * 60; // seconds-hand style idle motion
  return (
    <>
      <Sfx name="whoosh" at={0} /><Sfx name="chime" at={t(181)} />
      {steps.map((s, i) => <Sfx key={i} name="pop" at={s.a} />)}
      <Abs x={110} y={80} w={700}>
        <Words text="Time Management" size={84} at={0} stagger={6} maxWidth={700} />
        <div style={{height: 14}} />
        <Pop at={t([177, 'IELTS Reading-এ'])}><div style={{fontSize: 40, fontWeight: 500, color: pal.mute, lineHeight: 1.3}}>IELTS Reading-এ সময় খুব গুরুত্বপূর্ণ</div></Pop>
      </Abs>
      <Abs x={110} y={430}>
        <Pop at={4} from={0.7} cfg={springs.soft}>
          <Breathe amp={6}>
            <svg width={520} height={520} viewBox="0 0 100 100">
              <circle cx="50" cy="50" r="46" fill={pal.card} stroke={pal.border} strokeWidth="2.4" />
              {Array.from({length: 12}).map((_, i) => (
                <line key={i} x1="50" y1="8" x2="50" y2={i % 3 === 0 ? 15 : 12} stroke={pal.cardFg} strokeWidth={i % 3 === 0 ? 2.2 : 1.2} strokeLinecap="round" transform={`rotate(${i * 30} 50 50)`} />
              ))}
              <line x1="50" y1="50" x2="50" y2="20" stroke={pal.accent} strokeWidth="2.6" strokeLinecap="round" transform={`rotate(${hand} 50 50)`} />
              <line x1="50" y1="50" x2="50" y2="30" stroke={pal.cardFg} strokeWidth="3" strokeLinecap="round" transform={`rotate(${hand / 12 + 40} 50 50)`} />
              <circle cx="50" cy="50" r="3" fill={pal.cardFg} />
            </svg>
          </Breathe>
        </Pop>
      </Abs>
      <Abs x={860} y={90} w={960}>
        <div style={{display: 'flex', flexDirection: 'column', gap: 18}}>
          {steps.map((s, i) => (
            <Pop key={i} at={s.a} dir="right" dist={80}>
              <Card pad={24} style={{minHeight: 150, display: 'flex', alignItems: 'center', gap: 24}}>
                <div style={{flex: 'none', width: 66, height: 66, borderRadius: '50%', background: pal.accent, color: pal.accentFg, fontSize: 38, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>{i + 1}</div>
                <div style={{fontSize: 46, fontWeight: 700, lineHeight: 1.25}}>{s.text}</div>
              </Card>
            </Pop>
          ))}
          <Pop at={t(181)} dist={60} cfg={springs.pop}>
            <Card tone="accent" pad={28} style={{boxShadow: 'none', display: 'flex', alignItems: 'center', gap: 22}}>
              <CheckIcon size={60} color={pal.accentFg} p={ramp(f, t(181) + 8, 10)} />
              <div style={{fontSize: 50, fontWeight: 700, lineHeight: 1.2}}>দ্রুত উত্তরের চেয়ে সঠিক উত্তর বেশি গুরুত্বপূর্ণ</div>
            </Card>
          </Pop>
        </div>
      </Abs>
    </>
  );
};

// =============================================================== Golden tips (182-188)
export const TipsScene: React.FC = () => {
  const t = mk('tips');
  const pal = usePal();
  const tips = [
    {a: t([182, 'প্রথম টিপস']), text: 'প্রথমে প্রশ্ন পড়বে, তারপর Passage-এর Relevant অংশ খুঁজবে', key: 'প্রশ্ন → Passage'},
    {a: t([183, 'দ্বিতীয় টিপস']), text: 'একই শব্দ নয়, Synonym এবং Paraphrase খুঁজবে', key: 'Synonym ≈ Paraphrase'},
    {a: t([184, 'তৃতীয় টিপস']), text: 'চারটি অপশন ভালোভাবে বিশ্লেষণ করবে', key: 'শুধু একটি শব্দের মিল দেখে উত্তর নয়'},
    {a: t([185, 'চতুর্থ টিপস']), text: 'Passage-এর বাইরে নিজের ধারণা নয়', key: 'উত্তর Passage দিয়ে প্রমাণ করতে হবে'},
    {a: t([186, 'পঞ্চম টিপস']), text: 'প্রশ্নের Exact Demand বুঝবে', key: ''},
  ];
  const demands = [
    {a: t([186, 'প্রশ্ন যদি Main']), q: 'Main Idea', r: 'Main Idea খুঁজবে'},
    {a: t(187), q: 'Phrase-এর অর্থ', r: 'Context বুঝবে'},
    {a: t(188), q: 'Unexpected Finding', r: 'গবেষকদের অপ্রত্যাশিত ফলাফল খুঁজবে'},
  ];
  const f = useCurrentFrame();
  let active = -1;
  tips.forEach((x, i) => { if (f >= x.a) active = i; });
  return (
    <>
      <Sfx name="whoosh" at={0} />
      {tips.map((x, i) => <Sfx key={i} name="pop" at={x.a} />)}
      <Abs x={100} y={60} w={1700}><Words text="৫টি Golden Tips" size={92} at={0} hi={['Golden']} hiColor={colors.dark} /></Abs>
      <Abs x={100} y={230} w={1000}>
        <div style={{display: 'flex', flexDirection: 'column', gap: 16}}>
          {tips.map((x, i) => (
            <Pop key={i} at={x.a} dir="left" dist={90}>
              <Card pad={20} style={{height: 140, display: 'flex', alignItems: 'center', gap: 22, background: active === i ? pal.card : colors.cream, transform: `translateX(${active === i ? 14 : 0}px)`}}>
                <div style={{flex: 'none', width: 72, height: 72, borderRadius: '50%', background: active === i ? colors.red : colors.dark, color: colors.cream, fontSize: 42, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>{i + 1}</div>
                <div style={{fontSize: 42, fontWeight: 700, lineHeight: 1.2}}>{x.text}</div>
              </Card>
            </Pop>
          ))}
        </div>
      </Abs>
      <Abs x={1160} y={230} w={680}>
        {tips.slice(0, 4).map((x, i) => (
          <Pane key={i} from={x.a} to={tips[i + 1].a}>
            <Pop at={x.a + 6} until={tips[i + 1].a} dir="right" dist={80}>
              <Card pad={40} style={{height: 460, display: 'flex', alignItems: 'center', background: colors.dark, color: colors.cream, boxShadow: 'none', border: `3px solid ${colors.cream}`}}>
                <div style={{fontSize: 70, fontWeight: 700, lineHeight: 1.2}}>{x.key}</div>
              </Card>
            </Pop>
          </Pane>
        ))}
        <Pane from={tips[4].a} to={sceneDur('tips')}>
          <div style={{display: 'flex', flexDirection: 'column', gap: 18}}>
            {demands.map((d, i) => (
              <Pop key={i} at={d.a} dir="right" dist={80}>
                <Card pad={26} style={{background: colors.dark, color: colors.cream, boxShadow: 'none', border: `3px solid ${colors.cream}`}}>
                  <div style={{fontSize: 36, fontWeight: 700, color: colors.gray}}>প্রশ্ন যদি</div>
                  <div style={{fontSize: 50, fontWeight: 700, lineHeight: 1.15, marginTop: 4}}>{d.q}</div>
                  <div style={{fontSize: 40, fontWeight: 700, marginTop: 14, color: colors.cream}}>→ {d.r}</div>
                </Card>
              </Pop>
            ))}
          </div>
        </Pane>
      </Abs>
    </>
  );
};

// =============================================================== Challenge (189-191)
export const ChallengeScene: React.FC = () => {
  const t = mk('challenge');
  const pal = usePal();
  const opts = [
    {a: t(191), text: 'প্রথম প্রশ্ন'},
    {a: t([191, 'দ্বিতীয় প্রশ্ন']), text: 'দ্বিতীয় প্রশ্ন'},
    {a: t([191, 'নাকি তৃতীয়']), text: 'তৃতীয় প্রশ্ন'},
  ];
  const cm = t([191, 'কমেন্টে']);
  return (
    <>
      <Sfx name="whoosh" at={0} /><Sfx name="pop" at={opts[0].a} /><Sfx name="pop" at={opts[1].a} /><Sfx name="pop" at={opts[2].a} /><Sfx name="chime" at={cm} />
      <Abs x={110} y={70} w={1700}>
        <Chip tone="accent" size={40}>ছোট Challenge</Chip>
        <div style={{height: 30}} />
        <Words text="কোন প্রশ্নটি সবচেয়ে কঠিন মনে হয়েছে?" size={104} at={t(190)} stagger={5} hi={['কঠিন']} maxWidth={1650} />
      </Abs>
      <Abs x={110} y={520}>
        <div style={{display: 'flex', gap: 40}}>
          {opts.map((o, i) => (
            <Pop key={i} at={o.a} dist={60} cfg={springs.pop}>
              <Breathe amp={5} phase={i * 1.5}>
                <Card pad={30} style={{width: 520, height: 190, display: 'flex', alignItems: 'center', gap: 26}}>
                  <div style={{width: 96, height: 96, borderRadius: '50%', background: pal.accent, color: pal.accentFg, fontSize: 56, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>{i + 1}</div>
                  <div style={{fontSize: 52, fontWeight: 700}}>{o.text}</div>
                </Card>
              </Breathe>
            </Pop>
          ))}
        </div>
      </Abs>
      <Abs x={110} y={810}>
        <Pop at={cm} dist={50}>
          <div style={{display: 'flex', alignItems: 'center', gap: 26, padding: '22px 34px', borderRadius: 999, border: `4px solid ${pal.fg}`, width: 1240, boxSizing: 'border-box'}}>
            <BubbleIcon size={64} color={pal.accent} />
            <div style={{fontSize: 48, fontWeight: 600}}>কমেন্টে তোমার উত্তর জানাও</div>
          </div>
        </Pop>
      </Abs>
    </>
  );
};

// =============================================================== Practice (192-196)
export const PracticeScene: React.FC = () => {
  const t = mk('practice');
  const pal = usePal();
  const f = useCurrentFrame();
  const a195 = t(195);
  const steps = [
    {a: t([193, 'নিয়মগুলো বুঝতে']), text: 'নিয়মগুলো বুঝতে হবে'},
    {a: t([194, 'নিয়মগুলো অনুশীলন']), text: 'নিয়মগুলো অনুশীলন করতে হবে'},
    {a: t([194, 'তারপর']), text: 'নিজের ভুল বিশ্লেষণ করতে হবে'},
  ];
  const rel = t([196, 'আর দুটির']);
  return (
    <>
      <Sfx name="whoosh" at={0} /><Sfx name="swish" at={a195} />
      {steps.map((s, i) => <Sfx key={i} name="pop" at={s.a} />)}<Sfx name="chime" at={rel} />
      <Pane from={0} to={a195}>
        <Abs x={110} y={80} w={1700}><Words text="ছয়টি নিয়ম দিয়ে নিজে আরও MCQ সমাধান করো" size={88} at={0} until={a195} hi={['MCQ']} maxWidth={1650} /></Abs>
        <Abs x={110} y={390}>
          <Pop at={t([193, 'কারণ'])} until={a195}>
            <Chip tone="line" size={46}><CrossIcon size={40} color={pal.fg} />শুধু ভিডিও দেখলে ভালো করা সম্ভব নয়</Chip>
          </Pop>
        </Abs>
        <Abs x={110} y={540} w={1700}>
          <div style={{display: 'flex', gap: 36, alignItems: 'stretch'}}>
            {steps.map((s, i) => (
              <Pop key={i} at={s.a} until={a195} dir="up" dist={70} cfg={springs.pop}>
                <Card pad={32} style={{width: 520, height: 300, display: 'flex', flexDirection: 'column', justifyContent: 'space-between'}}>
                  <div style={{width: 84, height: 84, borderRadius: '50%', background: pal.accent, color: pal.accentFg, fontSize: 50, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>{i + 1}</div>
                  <div style={{fontSize: 52, fontWeight: 700, lineHeight: 1.2}}>{s.text}</div>
                </Card>
              </Pop>
            ))}
          </div>
        </Abs>
      </Pane>
      <Pane from={a195} to={sceneDur('practice')}>
        <Abs x={110} y={80} w={1700}><Words text="দ্রুত পড়া নয়, সঠিকভাবে বুঝতে হবে" size={96} at={a195} hi={['সঠিকভাবে']} maxWidth={1650} /></Abs>
        <Abs x={110} y={400}>
          <Pop at={t(196)} dir="left" dist={80}><Card pad={36} style={{width: 640, height: 280, display: 'flex', alignItems: 'center', justifyContent: 'center'}}><div style={{fontSize: 62, fontWeight: 700, textAlign: 'center', lineHeight: 1.2}}>প্রশ্নের ভাষা</div></Card></Pop>
        </Abs>
        <Abs x={1170} y={400}>
          <Pop at={t([196, 'Passage-এর ভাষা'])} dir="right" dist={80}><Card pad={36} style={{width: 640, height: 280, display: 'flex', alignItems: 'center', justifyContent: 'center'}}><div style={{fontSize: 62, fontWeight: 700, textAlign: 'center', lineHeight: 1.2}}>Passage-এর ভাষা</div></Card></Pop>
        </Abs>
        <Abs x={780} y={470}>
          <Pop at={rel} cfg={springs.pop} from={0.4}>
            <div style={{width: 360, height: 140, borderRadius: 70, background: pal.fg, color: pal.bg, fontSize: 48, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `rotate(${Math.sin(f / 14) * 1.5}deg)`}}>সম্পর্ক খুঁজো</div>
          </Pop>
        </Abs>
      </Pane>
    </>
  );
};

// =============================================================== Outro (197-199)
export const OutroScene: React.FC = () => {
  const t = mk('outro');
  const pal = usePal();
  const final = t([198, 'This is']);
  const btn = (at: number, icon: React.ReactNode, label: string, dark = false) => (
    <Pop at={at} until={final} dist={70} cfg={springs.pop}>
      <div style={{display: 'flex', alignItems: 'center', gap: 22, padding: '26px 40px', borderRadius: 40, background: dark ? colors.dark : colors.cream, color: dark ? colors.cream : colors.dark, border: `3px solid ${colors.dark}`, boxShadow: `8px 8px 0 ${colors.dark}`}}>
        {icon}<div style={{fontSize: 56, fontWeight: 700}}>{label}</div>
      </div>
    </Pop>
  );
  return (
    <>
      <Sfx name="whoosh" at={0} /><Sfx name="pop" at={t([197, 'Like'])} /><Sfx name="pop" at={t(198)} /><Sfx name="pop" at={t([198, 'Subscribe'])} />
      <Sfx name="swish" at={final} /><Sfx name="chime" at={final + 6} />
      <Abs x={110} y={110} w={1700}>
        <Words text="IELTS-এর প্রতিটি Question Type সহজভাবে শিখতে" size={90} at={0} until={final} hi={['সহজভাবে']} hiColor={colors.dark} maxWidth={1650} />
        <div style={{height: 26}} />
        <Pop at={t([197, 'সঙ্গে থাকো'])} until={final}><div style={{fontSize: 64, fontWeight: 700}}>সঙ্গে থাকো Imam IELTS-এর</div></Pop>
      </Abs>
      <Abs x={110} y={640} w={1700}>
        <div style={{display: 'flex', gap: 34}}>
          {btn(t([197, 'Like']), <LikeIcon size={70} color={colors.red} />, 'Like')}
          {btn(t(198), <ShareIcon size={70} color={colors.red} />, 'Share')}
          {btn(t([198, 'Subscribe']), <BellIcon size={70} color={colors.cream} />, 'Subscribe', true)}
        </div>
      </Abs>
      <Abs x={0} y={290} w={1920}>
        <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 26}}>
          <Pop at={final} dist={0} from={0.8} cfg={springs.pop}><div style={{fontSize: 190, fontWeight: 700, lineHeight: 1}}>Imam IELTS</div></Pop>
          <div style={{display: 'flex', gap: 40}}>
            {[['Learn Smart.', t([199, 'Learn'])], ['Read Smart.', t([199, 'Read'])], ['Score Higher.', t([199, 'Score'])]].map(([w, a], i) => (
              <Pop key={i} at={a as number} dist={40}><div style={{fontSize: 76, fontWeight: 700, color: i === 2 ? colors.dark : pal.fg}}>{w}</div></Pop>
            ))}
          </div>
        </div>
      </Abs>
    </>
  );
};
