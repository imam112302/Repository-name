import React from 'react';
import {useCurrentFrame} from 'remotion';
import {Breathe, Card, Chip, CheckIcon, CrossIcon, OptionTile, Pop, Sfx, SwapIcon, TargetIcon, TextLines, Words, ramp, usePal} from '../components/base';
import {Abs, Pane} from '../components/layout';
import {alpha, colors, springs} from '../theme';
import {mk, sceneDur} from '../timing';

// =============================================================== 1. Hook (cues 1-2)
export const HookScene: React.FC = () => {
  const t = mk('hook');
  const pal = usePal();
  const at2 = t([2, 'Multiple']);
  const stampAt = t([2, 'বারবার']);
  return (
    <>
      <Sfx name="thud" at={0} />
      <Sfx name="swish" at={t(2)} />
      <Abs x={0} y={330} w={1920} style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10}}>
        <Pop at={0} until={t(2) - 4}><div style={{fontSize: 64, fontWeight: 500, color: pal.mute}}>Welcome to</div></Pop>
        <Words text="Imam IELTS" size={210} at={6} until={t(2) - 4} hi={['IELTS']} align="center" />
      </Abs>
      <Abs x={110} y={250} w={880}>
        <Pop at={at2 - 6}><Chip tone="accent" size={32}>IELTS Reading</Chip></Pop>
        <div style={{height: 26}} />
        <Words text="Multiple Choice Questions" size={92} at={at2} stagger={5} />
        <div style={{height: 36}} />
        <Words text="বারবার ভুল করছ?" size={140} at={stampAt} stagger={7} hi={['ভুল']} />
      </Abs>
      <Abs x={1010} y={250} w={820}>
        <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 34}}>
          {['A', 'B', 'C', 'D'].map((L, i) => (
            <Breathe key={L} amp={5} phase={i * 1.3}>
              <OptionTile letter={L} at={at2 + i * 5} w={390} h={220} state="no" stateAt={stampAt + 6 + i * 10} dir="left" />
            </Breathe>
          ))}
        </div>
      </Abs>
      {[0, 1, 2, 3].map((i) => <Sfx key={i} name="click" at={stampAt + 6 + i * 10} />)}
    </>
  );
};

// =============================================================== 2. Pain (cues 3-5)
const LinkDiagram: React.FC<{from: number; to: number; linked: boolean; at: number}> = ({from, to, linked, at}) => {
  const f = useCurrentFrame();
  const pal = usePal();
  const p = ramp(f, at, 16);
  return (
    <>
      <Abs x={120} y={420}>
        <Pop at={from} dir="left" until={to}>
          <Card pad={34} style={{width: 700, height: 380}}>
            <div style={{fontSize: 30, fontWeight: 700, color: pal.cardMute, marginBottom: 24}}>Passage</div>
            <TextLines widths={[96, 90, 94, 70, 92, 84]} w={630} gap={22} barH={20} hl={{2: ramp(f, from + 12, 18), 3: ramp(f, from + 18, 18)}} at={from + 4} />
          </Card>
        </Pop>
      </Abs>
      <Abs x={1100} y={500}>
        <OptionTile letter="C" at={from + 8} w={700} h={220} dir="right" state={linked ? 'idle' : 'idle'} />
      </Abs>
      <Abs x={830} y={600} w={270} h={8}>
        <div style={{height: 0, borderTop: `8px ${linked ? 'solid' : 'dashed'} ${pal.fg}`, width: `${p * 100}%`, opacity: f > to ? 0 : 1}} />
      </Abs>
      <Abs x={920} y={560}>
        <Pop at={at + 10} cfg={springs.pop} until={to}>
          <div style={{width: 96, height: 96, borderRadius: '50%', background: linked ? pal.card : pal.accent, border: `4px solid ${pal.border}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 64, fontWeight: 700, color: linked ? pal.cardFg : pal.accentFg}}>
            {linked ? '=' : <CrossIcon size={56} color={pal.accentFg} p={ramp(f, at + 14, 8)} />}
          </div>
        </Pop>
      </Abs>
    </>
  );
};

export const PainScene: React.FC = () => {
  const t = mk('pain');
  const pal = usePal();
  const a3 = t(3), a4 = t(4), a5 = t(5);
  return (
    <>
      <Sfx name="whoosh" at={0} /><Sfx name="swish" at={a4} /><Sfx name="swish" at={a5} />
      <Pane from={a3} to={a4}>
        <Abs x={120} y={110} w={1680}><Words text="চারটি অপশন, চারটিই সঠিক মনে হয়" size={92} at={a3} hi={['সঠিক']} until={a4} /></Abs>
        <Abs x={120} y={400} w={1700}>
          <div style={{display: 'flex', gap: 40}}>
            {['A', 'B', 'C', 'D'].map((L, i) => <OptionTile key={L} letter={L} at={a3 + 10 + i * 5} w={400} h={200} />)}
          </div>
        </Abs>
        <Abs x={120} y={700} w={1700}>
          <Words text="কোনটি আসল উত্তর?" size={130} at={t([3, 'কিন্তু কোনটি'])} hi={['আসল']} until={a4} />
        </Abs>
        <Sfx name="pop" at={a3 + 10} />
      </Pane>
      <Pane from={a4} to={a5}>
        <Abs x={120} y={110} w={1680}><Words text="Passage-এ উত্তর পাও, কিন্তু অপশনের সঙ্গে মেলাতে পারো না" size={76} at={a4} hi={['মেলাতে']} until={a5} maxWidth={1600} /></Abs>
        <LinkDiagram from={a4} to={a5} linked={false} at={t([4, 'কিন্তু অপশনের'])} />
        <Sfx name="pop" at={a4 + 8} /><Sfx name="click" at={t([4, 'কিন্তু অপশনের']) + 10} />
      </Pane>
      <Pane from={a5} to={sceneDur('pain')}>
        <Abs x={120} y={110} w={1680}><Words text="একটি অপশন Passage-এর সঙ্গে মিলে যায়, কিন্তু সঠিক নয়" size={76} at={a5} hi={['সঠিক']} maxWidth={1600} /></Abs>
        <LinkDiagram from={a5} to={9999} linked at={t([5, 'মিলে যায়'])} />
        <Abs x={1300} y={800}>
          <Pop at={t([5, 'কিন্তু সেটি'])} cfg={springs.pop} dist={0} from={1.6} style={{transform: 'rotate(-6deg)'}}>
            <Chip tone="accent" size={58} style={{transform: 'rotate(-6deg)'}}>ভুল উত্তর</Chip>
          </Pop>
        </Abs>
        <Sfx name="pop" at={a5 + 8} /><Sfx name="click" at={t([5, 'কিন্তু সেটি'])} />
      </Pane>
      <div style={{display: 'none', color: pal.fg}} />
    </>
  );
};

// =============================================================== 3. Why (cues 6-7)
export const WhyScene: React.FC = () => {
  const t = mk('why');
  const pal = usePal();
  const f = useCurrentFrame();
  const strike = ramp(f, t([6, 'কারণ']) + 14, 14);
  const cards = [
    {at: t([6, 'বুঝতে হয় প্রশ্নের']), title: 'প্রশ্নের আসল উদ্দেশ্য', icon: <TargetIcon size={110} color={pal.cardFg} />},
    {at: t([7, 'Paraphrasing']), title: 'Paraphrasing', icon: <SwapIcon size={110} color={pal.cardFg} />},
    {at: t([7, 'কীভাবে ভুল']), title: 'ভুল অপশন বাদ দেওয়া', icon: <CrossIcon size={100} color={pal.cardFg} stroke={2.4} />},
  ];
  return (
    <>
      <Sfx name="whoosh" at={0} /><Sfx name="pop" at={cards[0].at} /><Sfx name="pop" at={cards[1].at} /><Sfx name="pop" at={cards[2].at} />
      <Abs x={120} y={90} w={1680}>
        <Words text="কেন এমন হয়?" size={72} at={0} color={pal.mute} />
        <div style={{height: 18}} />
        <div style={{position: 'relative', display: 'inline-block'}}>
          <Words text="শুধু তথ্য খুঁজলেই হয় না" size={112} at={t([6, 'কারণ'])} stagger={5} />
          <div style={{position: 'absolute', left: 0, top: 70, height: 10, width: `${strike * 62}%`, background: pal.fg, opacity: strike > 0 ? 1 : 0}} />
        </div>
      </Abs>
      <Abs x={120} y={500} w={1700}>
        <div style={{display: 'flex', gap: 44}}>
          {cards.map((c, i) => (
            <Pop key={i} at={c.at} dist={70} cfg={springs.pop}>
              <Breathe amp={5} phase={i * 1.7}>
                <Card pad={40} style={{width: 530, height: 400, display: 'flex', flexDirection: 'column', justifyContent: 'space-between'}}>
                  <div>{c.icon}</div>
                  <div style={{fontSize: 56, fontWeight: 700, lineHeight: 1.2}}>{c.title}</div>
                </Card>
              </Breathe>
            </Pop>
          ))}
        </div>
      </Abs>
    </>
  );
};

// =============================================================== 4. Overview (cues 8-12)
export const OverviewScene: React.FC = () => {
  const t = mk('overview');
  const pal = usePal();
  const row = (y: number, at: number, big: string, title: string, sub?: string) => (
    <Abs x={120} y={y} w={1680}>
      <Pop at={at} dir="left" dist={90}>
        <div style={{display: 'flex', alignItems: 'center', gap: 40}}>
          <div style={{width: 170, height: 170, borderRadius: 34, background: pal.accent, color: pal.accentFg, fontSize: 120, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', flex: 'none'}}>{big}</div>
          <div>
            <div style={{fontSize: 84, fontWeight: 700, lineHeight: 1.1}}>{title}</div>
            {sub && <div style={{fontSize: 40, fontWeight: 500, color: pal.mute, marginTop: 8}}>{sub}</div>}
          </div>
        </div>
      </Pop>
    </Abs>
  );
  const chips = [
    {at: t(10), text: 'কীভাবে উত্তর খুঁজতে হয়'},
    {at: t([10, 'কেন একটি']), text: 'কেন একটি অপশন সঠিক'},
    {at: t(11), text: 'বাকি ৩টি কেন ভুল'},
  ];
  return (
    <>
      <Sfx name="whoosh" at={0} />
      <Sfx name="pop" at={t(8)} /><Sfx name="pop" at={t(9)} /><Sfx name="pop" at={chips[0].at} /><Sfx name="chime" at={t(12)} />
      {row(70, t(8), '৬', 'টি কার্যকর নিয়ম', 'MCQ সমাধানের')}
      {row(290, t(9), '৩', 'টি বাস্তব প্রশ্ন', 'Cambridge IELTS 21 · Academic Reading · Test 4')}
      <Abs x={120} y={520} w={1700}>
        <div style={{display: 'flex', gap: 22, flexWrap: 'wrap'}}>
          {chips.map((c, i) => <Pop key={i} at={c.at} dir="left"><Chip tone="card" size={44} style={{border: `3px solid ${pal.border}`}}><CheckIcon size={40} color={pal.accent} p={1} />{c.text}</Chip></Pop>)}
          <Pop at={t([11, 'তাই ভিডিওটি'])} dir="left"><Chip tone="line" size={44}>শেষ পর্যন্ত দেখো</Chip></Pop>
        </div>
      </Abs>
      <Abs x={120} y={720} w={1680}>
        <Pop at={t(12)} dist={60} cfg={springs.pop}>
          <Card tone="accent" pad={36} style={{boxShadow: 'none'}}>
            <div style={{fontSize: 70, fontWeight: 700, lineHeight: 1.2}}>শুধু ৩টি উত্তর নয়, MCQ সমাধান করতে শেখা</div>
          </Card>
        </Pop>
      </Abs>
    </>
  );
};

// =============================================================== 5. What is MCQ (cues 13-16)
export const WhatIsScene: React.FC = () => {
  const t = mk('whatis');
  const pal = usePal();
  const acr = [
    {L: 'M', w: 'Multiple', at: t([14, 'MCQ-এর'])},
    {L: 'C', w: 'Choice', at: t([14, 'MCQ-এর']) + 14},
    {L: 'Q', w: 'Questions', at: t([14, 'MCQ-এর']) + 28},
  ];
  const optAt = t([15, 'এর নিচে']);
  const pickAt = t(16);
  return (
    <>
      <Sfx name="whoosh" at={0} /><Sfx name="pop" at={acr[0].at} /><Sfx name="pop" at={t([14, 'এখানে একটি'])} /><Sfx name="pop" at={optAt} /><Sfx name="chime" at={pickAt + 20} />
      <Abs x={100} y={90} w={760}>
        <Words text="Multiple Choice Questions কী?" size={78} at={0} stagger={5} hi={['কী?']} maxWidth={760} />
      </Abs>
      <Abs x={100} y={380} w={760}>
        {acr.map((a, i) => (
          <Pop key={i} at={a.at} dir="left" dist={70} style={{marginBottom: 22}}>
            <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
              <div style={{width: 130, height: 130, borderRadius: 30, background: pal.accent, color: pal.accentFg, fontSize: 90, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>{a.L}</div>
              <div style={{fontSize: 72, fontWeight: 700}}>{a.w}</div>
            </div>
          </Pop>
        ))}
      </Abs>
      <Abs x={960} y={110} w={860}>
        <Pop at={t([14, 'এখানে একটি'])} dir="right" dist={80}>
          <Card pad={36} style={{height: 250}}>
            <div style={{fontSize: 38, fontWeight: 700, color: pal.accent, marginBottom: 20}}>একটি প্রশ্ন</div>
            <TextLines widths={[96, 70]} w={740} gap={22} barH={24} at={t([14, 'এখানে একটি']) + 6} />
          </Card>
        </Pop>
      </Abs>
      <Abs x={960} y={410} w={880}>
        <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 30}}>
          {['A', 'B', 'C', 'D'].map((L, i) => (
            <OptionTile key={L} letter={L} at={optAt + i * 6} w={425} h={190} dir="right" state={i === 2 ? 'ok' : 'idle'} stateAt={pickAt + 20} />
          ))}
        </div>
      </Abs>
      <Abs x={960} y={880} w={880}>
        <Pop at={pickAt}><Chip tone="line" size={40}>সবচেয়ে সঠিক উত্তরটি নির্বাচন করো</Chip></Pop>
      </Abs>
    </>
  );
};

// =============================================================== 6. Paraphrasing (cues 17-21)
export const ParaphraseScene: React.FC = () => {
  const t = mk('paraphrase');
  const pal = usePal();
  const f = useCurrentFrame();
  const a18 = t(18), exA = t([19, 'Do not lag']), exB = t([20, 'Are not lower']), eqAt = t([20, 'কিন্তু অর্থ']);
  const box = (label: string, hint: string, ex: string, at: number, exAt: number, dir: 'left' | 'right') => (
    <Pop at={at} dir={dir} dist={90}>
      <Card pad={36} style={{width: 790, height: 380, display: 'flex', flexDirection: 'column'}}>
        <div style={{fontSize: 42, fontWeight: 700, color: pal.cardMute}}>{label}</div>
        <div style={{fontSize: 38, fontWeight: 500, color: pal.cardMute, marginTop: 6}}>{hint}</div>
        <div style={{flex: 1, display: 'flex', alignItems: 'center'}}>
          <Pop at={exAt} dist={30}><div style={{fontSize: 74, fontWeight: 700, lineHeight: 1.1}}>{ex}</div></Pop>
        </div>
      </Card>
    </Pop>
  );
  return (
    <>
      <Sfx name="whoosh" at={0} /><Sfx name="pop" at={a18} /><Sfx name="pop" at={t([19, 'Paraphrasing'])} /><Sfx name="click" at={eqAt} /><Sfx name="chime" at={t(21)} />
      <Abs x={120} y={80} w={1680}><Words text="সঠিক উত্তর অনেক সময় একই শব্দে লেখা থাকে না" size={80} at={0} hi={['একই']} maxWidth={1600} /></Abs>
      <Abs x={90} y={330}>{box('Passage', 'এক ধরনের শব্দ', 'Do not lag behind', a18, exA, 'left')}</Abs>
      <Abs x={1040} y={330}>{box('প্রশ্ন / অপশন', 'অন্য শব্দ', 'Are not lower than', a18 + 8, exB, 'right')}</Abs>
      <Abs x={856} y={450}>
        <Pop at={eqAt} cfg={springs.pop} from={0.4}>
          <div style={{width: 208, height: 140, borderRadius: 70, background: pal.fg, color: pal.bg, fontSize: 92, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `rotate(${Math.sin(f / 14) * 2}deg)`}}>≈</div>
        </Pop>
      </Abs>
      <Abs x={120} y={750} w={1700}>
        <div style={{display: 'flex', gap: 24, alignItems: 'center', flexWrap: 'wrap'}}>
          <Pop at={t([19, 'এটিকে বলা'])}><Chip tone="card" size={46} style={{border: `3px solid ${pal.border}`}}>Paraphrasing</Chip></Pop>
          <Pop at={t([20, 'দুটি বাক্যের'])}><Chip tone="line" size={46}>শব্দ আলাদা</Chip></Pop>
          <Pop at={eqAt}><Chip tone="line" size={46}>অর্থ প্রায় একই</Chip></Pop>
        </div>
        <div style={{height: 30}} />
        <Words text="শুধু শব্দ নয়, অর্থ খুঁজবে" size={96} at={t(21)} stagger={6} />
      </Abs>
    </>
  );
};
void alpha; void colors;
