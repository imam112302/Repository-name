// Switches for preview / render behaviour.
export const config = {
  // SFX layer (Studio preview + render)
  sfx: true,
  // public/voiceover.mp3 is played only if the file exists.
  voiceover: {
    enabled: true,   // play in Remotion Studio preview
    inRender: false, // set true to bake the voiceover into the rendered MP4 (sync check)
  },
};
