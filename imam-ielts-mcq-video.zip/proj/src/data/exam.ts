import type {Anchor} from '../timing';
import {optionTexts, questionTexts} from './passage';

export type Tone = 'info' | 'good' | 'bad' | 'trap' | 'lesson';
export type Beat = {a: Anchor; tag: string; text: string; tone?: Tone};
export type PMark = {id: string; para: number; text: string; a: Anchor; kind: 'ev' | 'alt'; pulse?: Anchor[]};
export type QMark = {text: string; a: Anchor; kind: 'topic' | 'purpose'};
export type Focus = {a: Anchor; opt: number}; // -1 = none
export type Verdict = {a: Anchor; opt: number; kind: 'ok' | 'no' | 'trap'};
export type Scroll = {a: Anchor; to: string};
export type QData = {
  n: number;
  question: string;
  options: string[];
  answer: number;
  start: Anchor;
  beats: Beat[];
  qmarks: QMark[];
  focus: Focus[];
  verdicts: Verdict[];
  scroll: Scroll[];
};

// ---------------- Before Q1: passage overview (cues 47-53) ----------------
export const overviewBeats: Beat[] = [
  {a: 47, tag: 'Passage', text: 'এবার নিয়মগুলো বাস্তবে প্রয়োগ করি'},
  {a: 48, tag: 'Passage', text: 'How could multilingualism benefit India’s poorest schoolchildren?'},
  {a: 49, tag: 'অর্থ', text: 'বহুভাষিকতা কীভাবে ভারতের দরিদ্রতম শিক্ষার্থীদের উপকার করতে পারে?'},
  {a: 50, tag: 'মূল বিষয়', text: 'ভারতের দরিদ্র পরিবারের শিশুদের শিক্ষা'},
  {a: 51, tag: 'মূল বিষয়', text: 'ইংরেজি ভাষাকে শিক্ষার মাধ্যম হিসেবে ব্যবহার করার বিষয়'},
  {a: 52, tag: 'গবেষকদের মত', text: 'যেসব শিশু স্কুলে আসার আগে ইংরেজির সঙ্গে পরিচিত নয়, তাদের জন্য শুরু থেকেই ইংরেজিতে সব বিষয় শেখা কঠিন হতে পারে'},
  {a: 53, tag: 'পরামর্শ', text: 'প্রাথমিক শিক্ষায় শিশুদের পরিচিত ভাষা ব্যবহার করা'},
];
export const overviewBullets: {a: Anchor; text: string}[] = [
  {a: 50, text: 'ভারতের দরিদ্র পরিবারের শিশুদের শিক্ষা'},
  {a: 51, text: 'ইংরেজি ভাষা: শিক্ষার মাধ্যম'},
  {a: 52, text: 'ইংরেজির সঙ্গে অপরিচিত শিশুদের জন্য শুরু থেকেই ইংরেজিতে শেখা কঠিন'},
  {a: 53, text: 'প্রাথমিক শিক্ষায় পরিচিত ভাষা ব্যবহারের পরামর্শ'},
];
export const overviewMeaning = {a: 49 as Anchor, text: 'বহুভাষিকতা কীভাবে ভারতের দরিদ্রতম শিক্ষার্থীদের উপকার করতে পারে?'};

// ---------------- Passage highlight marks (static spans, state driven by time) ----------------
export const marks: (PMark & {q: number})[] = [
  // Q1 (sixth paragraph = index 0, quote paragraph = index 1)
  {q: 1, id: 'q1ev', para: 0, kind: 'ev', a: 69,
    text: 'English instruction for children from low socio-economic areas might not be the best way for them to learn, at least in the first three years of primary education',
    pulse: [80, 81, 91]},
  {q: 1, id: 'q1alt', para: 0, kind: 'alt', a: 74,
    text: 'little familiarity with, or exposure to, the language before starting school and outside of school life'},
  {q: 1, id: 'q1uni', para: 1, kind: 'alt', a: 85,
    text: 'too much uniformity in teaching and less tailoring to the children’s language abilities and needs'},
  // Q2
  {q: 2, id: 'q2ev', para: 1, kind: 'ev', a: 99,
    text: 'We are not suggesting that English be withdrawn - that ship has sailed',
    pulse: [115, 124]},
  {q: 2, id: 'q2need', para: 1, kind: 'alt', a: 105,
    text: 'but we perhaps have to think more about learner needs'},
  // Q3
  {q: 3, id: 'q3unant', para: 2, kind: 'ev', a: 133, text: 'unanticipated', pulse: [167]},
  {q: 3, id: 'q3ev', para: 2, kind: 'ev', a: 136,
    text: 'finding has been that children from slum backgrounds do not seem to lag behind children from other urban poor backgrounds',
    pulse: [145, 161, 162]},
  {q: 3, id: 'q3ev2', para: 2, kind: 'ev', a: [163, 'এরপর বলা হয়েছে'],
    text: 'and in some cases outperform them (e.g. in numeracy and literacy tasks)'},
  {q: 3, id: 'q3int', para: 2, kind: 'alt', a: 142,
    text: 'there is no difference in general intelligence among boys and girls from slum areas versus those from urban poor backgrounds'},
  {q: 3, id: 'q3mature', para: 2, kind: 'alt', a: 156,
    text: 'They are likely to mature faster and come into closer contact with the numeracy skills essential for day-to-day survival'},
];

// ---------------- Question 1 ----------------
const Q1: QData = {
  n: 1, question: questionTexts[0], options: optionTexts[0], answer: 2, start: 54,
  beats: [
    {a: 54, tag: 'প্রশ্ন ১', text: 'প্রশ্ন নম্বর এক'},
    {a: 55, tag: 'Question 1', text: 'ষষ্ঠ Paragraph, ভারতের প্রাথমিক বিদ্যালয়'},
    {a: 56, tag: 'অর্থ', text: 'ষষ্ঠ Paragraph-এ ভারতের প্রাথমিক বিদ্যালয় সম্পর্কে লেখক কোন বিষয়টি তুলে ধরেছেন?'},
    {a: 57, tag: 'Keywords', text: 'Writer · Primary schools · India'},
    {a: [58, 'এখানে প্রশ্নের'], tag: 'উদ্দেশ্য', text: 'লেখকের বক্তব্য খুঁজে বের করা'},
    {a: 59, tag: 'Option A', text: 'Exposure to English outside of school is of limited benefit.'},
    {a: 60, tag: 'Option A', text: 'স্কুলের বাইরে ইংরেজির সংস্পর্শে আসার উপকারিতা সীমিত।'},
    {a: [60, 'Option B'], tag: 'Option B', text: 'Children learn English more easily when they are well motivated.'},
    {a: 62, tag: 'Option B', text: 'শিশুরা বেশি আগ্রহী হলে সহজে ইংরেজি শিখতে পারে।'},
    {a: [62, 'Option C'], tag: 'Option C', text: 'Poor children may be disadvantaged further by being instructed in English.'},
    {a: 64, tag: 'Option C', text: 'ইংরেজিতে শিক্ষা দেওয়ার কারণে দরিদ্র শিশুরা আরও বেশি অসুবিধার মধ্যে পড়তে পারে।'},
    {a: 65, tag: 'Option D', text: 'There is little consistency across schools with regard to instruction in English.'},
    {a: 66, tag: 'Option D', text: 'ইংরেজিতে শিক্ষাদানের ক্ষেত্রে বিভিন্ন স্কুলের মধ্যে খুব বেশি সামঞ্জস্য নেই।'},
    {a: 67, tag: 'Scanning', text: 'এবার Passage-এর সংশ্লিষ্ট অংশ খুঁজি'},
    {a: 70, tag: 'বাক্যটির অর্থ', text: 'এবার বাক্যটির অর্থ বুঝি'},
    {a: 71, tag: 'অর্থ', text: 'নিম্ন আর্থসামাজিক পরিবেশের শিশুদের জন্য প্রথম তিন বছর ইংরেজিতে শিক্ষা দেওয়া শেখার সবচেয়ে ভালো পদ্ধতি নাও হতে পারে।'},
    {a: 72, tag: 'Option A', text: 'স্কুলের বাইরে ইংরেজির সংস্পর্শে আসার উপকারিতা সীমিত', tone: 'info'},
    {a: 73, tag: 'Option A', text: 'Passage-এ এমন কোনো কথা বলা হয়নি', tone: 'bad'},
    {a: 74, tag: 'Passage', text: 'স্কুলের বাইরে ইংরেজির সঙ্গে পরিচিত নয়, এমন শিশুদের ইংরেজিতে শিক্ষা গ্রহণে সমস্যা হতে পারে'},
    {a: 75, tag: 'Option A ✕', text: 'Passage-এর মূল বক্তব্য প্রকাশ করছে না', tone: 'bad'},
    {a: 76, tag: 'Option B', text: 'শিশুরা বেশি আগ্রহী হলে সহজে ইংরেজি শিখতে পারে'},
    {a: 77, tag: 'Option B ✕', text: 'Passage-এ Motivation বা শিশুদের আগ্রহের বিষয়ে কিছু বলা হয়নি', tone: 'bad'},
    {a: 79, tag: 'Option C', text: 'ইংরেজিতে শিক্ষা দেওয়ার কারণে দরিদ্র শিশুরা আরও বেশি অসুবিধার মধ্যে পড়তে পারে'},
    {a: 81, tag: 'Passage বলছে', text: 'ইংরেজিতে শিক্ষা দেওয়া তাদের শেখার জন্য সবচেয়ে ভালো পদ্ধতি নাও হতে পারে'},
    {a: 82, tag: 'অর্থ এক', text: 'ইংরেজি তাদের শেখার ক্ষেত্রে বাধা তৈরি করতে পারে: দুটি বক্তব্যের মূল অর্থ একই', tone: 'good'},
    {a: 83, tag: 'Option C ✓', text: 'Option C সঠিক', tone: 'good'},
    {a: 84, tag: 'Option D', text: 'বিভিন্ন স্কুলে ইংরেজিতে শিক্ষাদানের ক্ষেত্রে সামঞ্জস্যের অভাব রয়েছে'},
    {a: 85, tag: 'Passage', text: 'Teaching-এর মধ্যে Too much uniformity থাকার কথা বলা হয়েছে'},
    {a: 86, tag: 'লেখক বলতে চেয়েছেন', text: 'শিশুদের ভাষাগত দক্ষতা এবং প্রয়োজন অনুযায়ী শিক্ষাদান করা হচ্ছে না'},
    {a: 87, tag: 'Option D', text: 'বিভিন্ন স্কুলের মধ্যে সামঞ্জস্যের অভাব রয়েছে'},
    {a: 88, tag: 'Option D ✕', text: 'Passage-এর বক্তব্যের সঙ্গে এক নয়', tone: 'bad'},
    {a: [88, 'তাহলে প্রথম প্রশ্নের'], tag: 'উত্তর', text: 'প্রথম প্রশ্নের সঠিক উত্তর: C', tone: 'good'},
    {a: 89, tag: 'শিক্ষা', text: 'প্রথম প্রশ্ন থেকে একটি গুরুত্বপূর্ণ শিক্ষা', tone: 'lesson'},
    {a: 90, tag: 'শিক্ষা', text: 'Passage-এর একই শব্দ অপশনে ব্যবহার করা হয়নি', tone: 'lesson'},
    {a: 91, tag: 'Paraphrase', text: 'might not be the best way for them to learn  ≈  Option C-তে অন্যভাবে প্রকাশ', tone: 'lesson'},
    {a: 92, tag: 'মনে রাখবে', text: 'শব্দের মিলের চেয়ে অর্থের মিল বেশি গুরুত্বপূর্ণ', tone: 'lesson'},
  ],
  qmarks: [
    {text: 'writer', a: [57, 'Writer'], kind: 'purpose'},
    {text: 'primary schools', a: [57, 'Primary schools'], kind: 'topic'},
    {text: 'India', a: 58, kind: 'topic'},
  ],
  focus: [
    {a: 59, opt: 0}, {a: [60, 'Option B'], opt: 1}, {a: [62, 'Option C'], opt: 2}, {a: 65, opt: 3},
    {a: 67, opt: -1}, {a: [72, 'Option A'], opt: 0}, {a: [76, 'Option B'], opt: 1},
    {a: [78, 'এবার Option C'], opt: 2}, {a: 84, opt: 3}, {a: 89, opt: -1}, {a: 91, opt: 2},
  ],
  verdicts: [
    {a: [75, 'তাই Option A'], opt: 0, kind: 'no'},
    {a: [77, 'তাই Option B'], opt: 1, kind: 'no'},
    {a: [83, 'তাই Option C'], opt: 2, kind: 'ok'},
    {a: [88, 'তাই Option D'], opt: 3, kind: 'no'},
  ],
  scroll: [
    {a: 54, to: 'p0'}, {a: 69, to: 'q1ev'}, {a: 74, to: 'q1alt'}, {a: 80, to: 'q1ev'},
    {a: 85, to: 'q1uni'}, {a: 89, to: 'q1ev'},
  ],
};

// ---------------- Question 2 ----------------
const Q2: QData = {
  n: 2, question: questionTexts[1], options: optionTexts[1], answer: 3, start: 93,
  beats: [
    {a: 93, tag: 'প্রশ্ন ২', text: 'প্রশ্ন নম্বর দুই'},
    {a: 94, tag: 'Question 2', text: 'Tsimpli · ‘that ship has sailed’'},
    {a: 95, tag: 'অর্থ', text: 'Tsimpli যখন That ship has sailed কথাটি ব্যবহার করেছেন, তখন তিনি কী বোঝাতে চেয়েছেন?'},
    {a: 96, tag: 'Keyword', text: 'That ship has sailed'},
    {a: 97, tag: 'Scanning', text: 'Passage-এ Phrase-টি খুঁজে বের করো'},
    {a: 100, tag: 'Idiom', text: 'That ship has sailed একটি Idiom'},
    {a: 101, tag: 'অর্থ', text: 'কোনো কিছু পরিবর্তন করার সুযোগ ইতোমধ্যে চলে গেছে'},
    {a: 102, tag: 'অর্থ', text: 'এখন আর আগের অবস্থায় ফিরে যাওয়া সম্ভব নয়'},
    {a: 103, tag: 'Tsimpli বলছেন', text: 'ইংরেজি ভাষাকে পুরোপুরি শিক্ষাব্যবস্থা থেকে সরিয়ে দেওয়ার কথা তারা বলছেন না'},
    {a: 104, tag: 'কারণ', text: 'ইংরেজি ইতোমধ্যে শিক্ষাব্যবস্থার একটি গুরুত্বপূর্ণ অংশ'},
    {a: 105, tag: 'তবে', text: 'শিক্ষার্থীদের প্রয়োজন অনুযায়ী শিক্ষাদানের পদ্ধতি পরিবর্তন করা প্রয়োজন'},
    {a: 106, tag: 'Option A', text: 'The findings of the report may be of little help to some Indian schoolchildren.'},
    {a: 108, tag: 'Option A', text: 'গবেষণার ফলাফল কিছু ভারতীয় শিশুর খুব বেশি উপকারে আসবে না।'},
    {a: 109, tag: 'Option A', text: 'এই Phrase-এর মাধ্যমে গবেষণার ফলাফল উপকারী হবে কি না, সে বিষয়ে কিছু বলা হয়নি', tone: 'bad'},
    {a: [110, 'Option B'], tag: 'Option B', text: 'Instruction in English could be better adapted to the needs of schoolchildren.'},
    {a: 112, tag: 'Option B', text: 'শিশুদের প্রয়োজন অনুযায়ী ইংরেজিতে শিক্ষাদানের পদ্ধতি আরও ভালোভাবে সাজানো যেতে পারে।'},
    {a: 113, tag: 'মিল আছে, কিন্তু…', text: 'এই কথাটি Passage-এর পরবর্তী বক্তব্যের সঙ্গে মিলে যায়'},
    {a: 114, tag: 'Tsimpli', text: 'শিক্ষার্থীদের প্রয়োজন অনুযায়ী শিক্ষাদান করা উচিত'},
    {a: 115, tag: 'প্রশ্ন কী চায়?', text: 'That ship has sailed দিয়ে তিনি কী বোঝাতে চেয়েছেন'},
    {a: 116, tag: 'Option B ✕', text: 'এই Phrase-এর অর্থ Option B নয়', tone: 'trap'},
    {a: [116, 'এটি একটি'], tag: 'MCQ Trap', text: 'গুরুত্বপূর্ণ MCQ Trap', tone: 'trap'},
    {a: 117, tag: 'MCQ Trap', text: 'কোনো অপশন Passage-এর অন্য একটি বাক্যের সঙ্গে মিললেই সেটি সঠিক উত্তর হয়ে যায় না', tone: 'trap'},
    {a: 118, tag: 'Option C', text: 'Schools have had limited success in teaching English as a separate subject.'},
    {a: 119, tag: 'Option C', text: 'আলাদা বিষয় হিসেবে ইংরেজি শেখানোর ক্ষেত্রে স্কুলগুলোর সফলতা সীমিত।'},
    {a: 120, tag: 'Option C', text: 'স্কুলগুলো ইংরেজি শেখাতে কতটা সফল, সে বিষয়ে Passage-এ কোনো তথ্য নেই', tone: 'bad'},
    {a: [121, 'এবার Option D'], tag: 'Option D', text: 'It is too late to remove English completely as a language of instruction in schools.'},
    {a: 123, tag: 'Option D', text: 'স্কুলে শিক্ষার মাধ্যম হিসেবে ইংরেজিকে পুরোপুরি সরিয়ে দেওয়ার সময় ইতোমধ্যে চলে গেছে।'},
    {a: 124, tag: 'Passage', text: 'That ship has sailed'},
    {a: 125, tag: 'অর্থ এক', text: 'ইংরেজিকে পুরোপুরি সরিয়ে দেওয়ার সুযোগ ইতোমধ্যে চলে গেছে: দুটি বক্তব্য একই অর্থ প্রকাশ করছে', tone: 'good'},
    {a: [126, 'দ্বিতীয় প্রশ্নের উত্তর'], tag: 'উত্তর', text: 'দ্বিতীয় প্রশ্নের উত্তর: D', tone: 'good'},
    {a: [126, 'এখানে একটি গুরুত্বপূর্ণ'], tag: 'কৌশল', text: 'একটি গুরুত্বপূর্ণ কৌশল মনে রাখবে', tone: 'lesson'},
    {a: 127, tag: 'কৌশল', text: 'প্রশ্নে Idiom, Phrase অথবা Quotation থাকলে Passage-এ সেটি খুঁজে বের করবে', tone: 'lesson'},
    {a: 128, tag: 'কৌশল', text: 'শুধু শব্দের অর্থ নয়, পুরো Context বুঝবে', tone: 'lesson'},
    {a: 129, tag: 'কেন?', text: 'অনেক সময় Idiom-এর অর্থ তার প্রতিটি শব্দের অর্থ থেকে আলাদা হয়', tone: 'lesson'},
  ],
  qmarks: [{text: 'that ship has sailed', a: [96, 'That ship has sailed'], kind: 'purpose'}],
  focus: [
    {a: 96, opt: -1}, {a: [106, 'Option A'], opt: 0}, {a: [110, 'Option B'], opt: 1}, {a: 118, opt: 2},
    {a: [121, 'এবার Option D'], opt: 3}, {a: [126, 'এখানে একটি গুরুত্বপূর্ণ'], opt: -1},
  ],
  verdicts: [
    {a: [110, 'তাই Option A'], opt: 0, kind: 'no'},
    {a: [116, 'তাই Option B'], opt: 1, kind: 'trap'},
    {a: [121, 'তাই Option C'], opt: 2, kind: 'no'},
    {a: [126, 'তাই Option D'], opt: 3, kind: 'ok'},
  ],
  scroll: [{a: 93, to: 'p1'}, {a: 97, to: 'q2ev'}],
};

// ---------------- Question 3 ----------------
const Q3: QData = {
  n: 3, question: questionTexts[2], options: optionTexts[2], answer: 3, start: [129, 'এবার চলে যাই'],
  beats: [
    {a: [129, 'এবার চলে যাই'], tag: 'প্রশ্ন ৩', text: 'এবার তৃতীয় প্রশ্ন'},
    {a: 130, tag: 'Question 3', text: 'অষ্টম Paragraph, গবেষকদের অবাক করা বিষয়'},
    {a: 131, tag: 'অর্থ', text: 'অষ্টম Paragraph-এ গবেষকদের কোন বিষয়টি অবাক করেছে?'},
    {a: 132, tag: 'Keyword', text: 'Surprised researchers'},
    {a: 133, tag: 'Synonym', text: 'Surprised  ≈  Unanticipated (অপ্রত্যাশিত)'},
    {a: 134, tag: 'Paraphrase', text: 'শব্দ আলাদা, কিন্তু অর্থের মধ্যে সম্পর্ক রয়েছে'},
    {a: 135, tag: 'Scanning', text: 'সংশ্লিষ্ট অংশটি খুঁজে পাওয়া গেছে'},
    {a: 137, tag: 'সহজ বাংলায়', text: 'একটি অপ্রত্যাশিত ফলাফল'},
    {a: 138, tag: 'অপ্রত্যাশিত ফলাফল', text: 'বস্তির শিশুরা শহরের অন্যান্য দরিদ্র পরিবারের শিশুদের তুলনায় পিছিয়ে নেই'},
    {a: 139, tag: 'সংযোজন', text: 'কিছু ক্ষেত্রে তারা বরং ভালো ফলাফল করছে'},
    {a: [139, 'এখন অপশনগুলো'], tag: 'Option A', text: 'Boys and girls from low socio-economic groups have similar general intelligence levels.'},
    {a: 141, tag: 'Option A', text: 'নিম্ন আর্থসামাজিক পরিবেশের ছেলে এবং মেয়েদের সাধারণ বুদ্ধিমত্তার মাত্রা প্রায় একই।'},
    {a: 142, tag: 'Passage', text: 'বস্তি এলাকার ছেলে ও মেয়েদের সাধারণ বুদ্ধিমত্তায় কোনো পার্থক্য পাওয়া যায়নি'},
    {a: 143, tag: 'তাহলে কি A সঠিক?', text: 'না। প্রশ্নে শুধু জানতে চাওয়া হয়নি, Passage-এ কোন তথ্য রয়েছে', tone: 'trap'},
    {a: 144, tag: 'প্রশ্ন চায়', text: 'গবেষকদের কোন বিষয়টি অবাক করেছে', tone: 'info'},
    {a: 145, tag: 'Passage', text: 'সাধারণ বুদ্ধিমত্তার পার্থক্য না থাকার পর আলাদাভাবে একটি Unanticipated finding'},
    {a: 146, tag: 'Unanticipated finding', text: 'বস্তির শিশুরা অন্যান্য শহুরে দরিদ্র শিশুদের তুলনায় পিছিয়ে নেই'},
    {a: 147, tag: 'Option A ✕', text: 'সত্য তথ্য, কিন্তু প্রশ্নের উত্তর নয়', tone: 'trap'},
    {a: 148, tag: 'Trap', text: 'কোনো তথ্য সত্য হলেই সেটি উত্তর নয়; প্রশ্নের চাহিদাও পূরণ করতে হবে', tone: 'trap'},
    {a: [149, 'Option B'], tag: 'Option B', text: 'The age at which children move into a slum does not affect their academic performance.'},
    {a: 150, tag: 'Option B', text: 'শিশুরা কোন বয়সে বস্তিতে আসে, তা তাদের পড়াশোনার ফলাফলে কোনো প্রভাব ফেলে না।'},
    {a: 151, tag: 'Option B', text: 'বস্তিতে আসার বয়স আর Academic Performance নিয়ে Passage-এ কোনো তথ্য নেই', tone: 'bad'},
    {a: [152, 'এবার Option C'], tag: 'Option C', text: 'Slum children and children from other urban poor backgrounds have similar life experiences.'},
    {a: 154, tag: 'Option C', text: 'বস্তির শিশু এবং অন্যান্য শহুরে দরিদ্র শিশুদের জীবনযাপনের অভিজ্ঞতা একই রকম।'},
    {a: 155, tag: 'Option C', text: 'Passage-এ এমন কোনো কথা বলা হয়নি', tone: 'bad'},
    {a: 156, tag: 'Passage', text: 'বস্তিতে বেড়ে ওঠা শিশুদের জীবনযাপনের অভিজ্ঞতা তাদের দ্রুত পরিণত হতে সাহায্য করতে পারে'},
    {a: 157, tag: 'Option C ✕', text: 'দৈনন্দিন জীবনে গণিতের দক্ষতার সঙ্গে বেশি পরিচিত হতে হয়, তাই Option C সঠিক নয়', tone: 'bad'},
    {a: [158, 'এবার Option D'], tag: 'Option D', text: 'The literacy and numeracy skills of slum children are not lower than those of children from other urban poor backgrounds.'},
    {a: 160, tag: 'Option D', text: 'বস্তির শিশুদের পড়া এবং গণিতের দক্ষতা অন্যান্য শহুরে দরিদ্র শিশুদের তুলনায় কম নয়।'},
    {a: 161, tag: 'Passage', text: 'Do not seem to lag behind'},
    {a: 163, tag: 'Paraphrase', text: 'Do not lag behind  =  পিছিয়ে নেই'},
    {a: 164, tag: 'Passage', text: 'Numeracy এবং Literacy tasks-এ কিছু ক্ষেত্রে আরও ভালো ফলাফল'},
    {a: 165, tag: 'মিল', text: 'Option D: Literacy ও Numeracy skills কম নয়'},
    {a: [166, 'তৃতীয় প্রশ্নের উত্তর'], tag: 'উত্তর: D', text: 'Passage-এর তথ্যও একই বিষয় প্রকাশ করছে', tone: 'good'},
    {a: 167, tag: 'শিক্ষা', text: 'প্রশ্নে Surprised, Passage-এ Unanticipated', tone: 'lesson'},
    {a: 168, tag: 'শিক্ষা', text: 'দুটি শব্দের অর্থের সম্পর্ক বুঝতে পারায় সঠিক উত্তর পাওয়া গেছে', tone: 'lesson'},
    {a: 169, tag: 'Trap', text: 'Option A সত্য তথ্য হলেও প্রশ্নের উত্তর নয়', tone: 'trap'},
    {a: 170, tag: 'MCQ Trap', text: 'IELTS Reading MCQ-এর অন্যতম গুরুত্বপূর্ণ Trap', tone: 'trap'},
  ],
  qmarks: [{text: 'surprised researchers', a: 132, kind: 'purpose'}],
  focus: [
    {a: 132, opt: -1}, {a: [139, 'Option A'], opt: 0}, {a: [149, 'Option B'], opt: 1},
    {a: [152, 'এবার Option C'], opt: 2}, {a: [158, 'এবার Option D'], opt: 3}, {a: 169, opt: 0},
  ],
  verdicts: [
    {a: [147, 'তাই Option A'], opt: 0, kind: 'trap'},
    {a: [152, 'তাই Option B'], opt: 1, kind: 'no'},
    {a: [157, 'তাই Option C'], opt: 2, kind: 'no'},
    {a: [166, 'তাই Option D'], opt: 3, kind: 'ok'},
  ],
  scroll: [
    {a: [129, 'এবার চলে যাই'], to: 'p2'}, {a: 133, to: 'q3unant'}, {a: 136, to: 'q3ev'}, {a: 142, to: 'q3int'},
    {a: 145, to: 'q3ev'}, {a: 156, to: 'q3mature'}, {a: 161, to: 'q3ev'}, {a: 167, to: 'q3unant'},
  ],
};

export const questions: QData[] = [Q1, Q2, Q3];

// ---------------- After Q3: answers table ----------------
export const answersStart: Anchor = [170, 'তাহলে তিনটি'];
export const answerRows: {a: Anchor; q: string; letter: string}[] = [
  {a: [171, 'Question One'], q: 'Question 1', letter: 'C'},
  {a: [171, 'Question Two'], q: 'Question 2', letter: 'D'},
  {a: [171, 'Question Three'], q: 'Question 3', letter: 'D'},
];
export const answerBeat: Beat = {a: answersStart, tag: 'উত্তর', text: 'Question 1: C   ·   Question 2: D   ·   Question 3: D', tone: 'good'};
