// Exact text from the user's message (Cambridge IELTS 21 Academic Reading Test 4, Part 1, Questions 1-3).
export const source = 'Cambridge IELTS 21 · Academic Reading · Test 4';
export const passageTitle = 'How could multilingualism benefit India’s poorest schoolchildren?';

export const paragraphs: string[] = [
  'Although the findings are at a preliminary stage, Tsimpli and her team have found that the medium of instruction used in schools, especially English, may hold back those children who have little familiarity with, or exposure to, the language before starting school and outside of school life. According to Tsimpli, most of the evidence from this and other projects shows that English instruction for children from low socio-economic areas might not be the best way for them to learn, at least in the first three years of primary education.',
  '‘What we would recommend for everyone, not just low socio-economic status children, would be to start learning in the language they feel comfortable learning in ... English can still be used, but perhaps not as the medium of instruction in primary schools. It could, for example, be one of the subjects that are being taught alongside other subjects. We are not suggesting that English be withdrawn - that ship has sailed - but we perhaps have to think more about learner needs. There is perhaps too much uniformity in teaching and less tailoring to the children’s language abilities and needs,’ says Tsimpli.',
  'While the preliminary results show there is no difference in general intelligence among boys and girls from slum areas versus those from urban poor backgrounds, an unanticipated finding has been that children from slum backgrounds do not seem to lag behind children from other urban poor backgrounds - and in some cases outperform them (e.g. in numeracy and literacy tasks). According to the researchers, this unexpected finding may be down to the life experiences of children growing up in slums. They are likely to mature faster and come into closer contact with the numeracy skills essential for day-to-day survival.',
];

// The question texts refer to the sixth and eighth paragraph; the middle one follows in sequence.
export const paraLabels = ['Paragraph 6', 'Paragraph 7', 'Paragraph 8'];

export const instruction = 'Choose the correct letter, A, B, C or D.';

export const questionTexts = [
  'What point does the writer make about primary schools in India in the sixth paragraph?',
  'What is Tsimpli suggesting when she uses the phrase ‘that ship has sailed’?',
  'In the eighth paragraph, what do we learn has surprised researchers?',
];

export const optionTexts: string[][] = [
  [
    'Exposure to English outside of school is of limited benefit.',
    'Children learn English more easily when they are well motivated.',
    'Poor children may be disadvantaged further by being instructed in English.',
    'There is little consistency across schools with regard to instruction in English.',
  ],
  [
    'The findings of the report may be of little help to some Indian schoolchildren.',
    'Instruction in English could be better adapted to the needs of schoolchildren.',
    'Schools have had limited success in teaching English as a separate subject.',
    'It is too late to remove English completely as a language of instruction in schools.',
  ],
  [
    'Boys and girls from low socio-economic groups have similar general intelligence levels.',
    'The age at which children move into a slum does not affect their academic performance.',
    'Slum children and children from other urban poor backgrounds have similar life experiences.',
    'The literacy and numeracy skills of slum children are not lower than those of children from other urban poor backgrounds.',
  ],
];
